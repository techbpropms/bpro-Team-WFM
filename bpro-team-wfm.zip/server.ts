import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import 'dotenv/config';
import { GoogleGenAI } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: '10mb' }));

// Healthcheck endpoint
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Gemini Multi-turn Chat API
// Handles:
// - gemini-3.1-pro-preview for complex tasks
// - gemini-3.5-flash for general operational tasks
// - gemini-3.1-flash-lite for rapid speed tasks
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ 
        error: 'GEMINI_API_KEY is not configured in the server environment.' 
      });
    }

    const { messages, model = 'gemini-3.5-flash', systemInstruction } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'messages array is required' });
    }

    // Validate supported models
    const validModels = [
      'gemini-3.5-flash',
      'gemini-3.1-pro-preview',
      'gemini-3.1-flash-lite',
      'gemini-3.8-flash'
    ];
    const selectedModel = validModels.includes(model) ? model : 'gemini-3.5-flash';

    const ai = new GoogleGenAI({ apiKey });

    // Format history contents for @google/genai
    const contents = messages.map((m: any) => ({
      role: m.role === 'assistant' || m.role === 'model' ? 'model' : 'user',
      parts: [{ text: m.text || m.content || '' }]
    }));

    const response = await ai.models.generateContent({
      model: selectedModel,
      contents,
      config: {
        systemInstruction: systemInstruction || 'You are an intelligent ERP and business copilot for Bpro PMS enterprise management.',
      }
    });

    return res.json({
      text: response.text || '',
      model: selectedModel,
    });
  } catch (error: any) {
    console.error('[API /api/chat error]:', error);
    return res.status(500).json({
      error: error.message || 'Failed to generate response from Gemini API.'
    });
  }
});

// Google Maps Grounding API with gemini-3.5-flash
// Uses the googleMaps tool per guidelines to retrieve real-time geographical data,
// local client sites, partner vendor offices, travel distances, and places of interest.
app.post('/api/maps-grounding', async (req: Request, res: Response) => {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ 
        error: 'GEMINI_API_KEY is not configured in the server environment.' 
      });
    }

    const { prompt, latLng } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'prompt is required' });
    }

    const ai = new GoogleGenAI({ apiKey });

    const toolConfig = latLng && latLng.latitude && latLng.longitude ? {
      retrievalConfig: {
        latLng: {
          latitude: Number(latLng.latitude),
          longitude: Number(latLng.longitude),
        }
      }
    } : undefined;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        tools: [{ googleMaps: {} }],
        toolConfig
      }
    });

    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

    // Extract all structured map links and place recommendations
    const mapLinks: Array<{ title: string; uri: string; address?: string; snippet?: string }> = [];

    for (const chunk of groundingChunks as any[]) {
      if (chunk.maps?.uri) {
        mapLinks.push({
          title: chunk.maps.title || 'Google Maps Location',
          uri: chunk.maps.uri,
          address: chunk.maps.formattedAddress,
          snippet: chunk.maps.placeAnswerSources?.reviewSnippets?.[0]?.content
        });
      }
    }

    return res.json({
      text: response.text || '',
      groundingChunks,
      mapLinks
    });
  } catch (error: any) {
    console.error('[API /api/maps-grounding error]:', error);
    return res.status(500).json({
      error: error.message || 'Failed to retrieve Maps Grounding data from Gemini.'
    });
  }
});

// Git Push Endpoint using GitHub Token
app.post('/api/git-push', async (req: Request, res: Response) => {
  try {
    const { token, repoUrl = 'https://github.com/techbpropms/bpro-Team-WFM.git', branch = 'main' } = req.body;
    if (!token || typeof token !== 'string') {
      return res.status(400).json({ 
        error: 'GitHub Personal Access Token is required to authenticate with GitHub.' 
      });
    }

    const cleanToken = token.trim();
    const cleanUrl = repoUrl.replace(/^https?:\/\//, '').replace(/^git@github\.com:/, 'github.com/');
    const authenticatedUrl = `https://${cleanToken}@${cleanUrl}`;

    const { execSync } = await import('child_process');

    try {
      execSync('git add . && git commit -m "chore: Sync updates before push" || true', { stdio: 'pipe' });
    } catch {
      // already up to date
    }

    const pushOutput = execSync(`git push ${authenticatedUrl} ${branch}`, { stdio: 'pipe' }).toString();
    return res.json({ 
      success: true, 
      message: `Successfully pushed branch ${branch} to ${repoUrl}!`,
      output: pushOutput 
    });
  } catch (error: any) {
    console.error('[API /api/git-push error]:', error);
    const errOutput = error.stderr ? error.stderr.toString() : (error.stdout ? error.stdout.toString() : error.message);
    const sanitized = req.body.token ? errOutput.replace(new RegExp(req.body.token.trim(), 'g'), '***') : errOutput;
    return res.status(500).json({ 
      error: 'Git push failed. Please verify your GitHub Personal Access Token permissions.',
      details: sanitized 
    });
  }
});

// Download full ZIP archive endpoint
app.get('/api/download-zip', async (_req: Request, res: Response) => {
  try {
    const zipPath = path.resolve(__dirname, 'public', 'bpro-team-wfm.zip');
    res.download(zipPath, 'bpro-team-wfm.zip');
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to download zip file' });
  }
});

// Mount Vite middleware in dev or static files in production
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const PORT = Number(process.env.PORT) || 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
