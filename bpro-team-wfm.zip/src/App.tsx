import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { MobileNav } from './components/layout/MobileNav';
import { ExecutiveDashboard } from './components/dashboard/ExecutiveDashboard';
import { TaskManager } from './components/tasks/TaskManager';
import { ClientManager } from './components/clients/ClientManager';
import { ProjectManager } from './components/projects/ProjectManager';
import { InvoiceManager } from './components/invoices/InvoiceManager';
import { ExpenseManager } from './components/expenses/ExpenseManager';
import { CalendarMeetScheduler } from './components/calendar/CalendarMeetScheduler';
import { TeamManager } from './components/team/TeamManager';
import { ReportsManager } from './components/reports/ReportsManager';
import { AuditLogManager } from './components/audit/AuditLogManager';
import { SettingsManager } from './components/settings/SettingsManager';
import { GamificationManager } from './components/gamification/GamificationManager';
import { StickyNotesManager } from './components/sticky/StickyNotesManager';
import { StickyQuickDrawer } from './components/sticky/StickyQuickDrawer';
import { FormatUploadModal } from './components/upload/FormatUploadModal';
import { IntegrationsModal } from './components/integrations/IntegrationsModal';
import { GeminiCopilot } from './components/gemini/GeminiCopilot';
import { NotificationCenter } from './components/notifications/NotificationCenter';
import { Tooltip } from './components/common/Tooltip';
import { 
  X, 
  Layers, 
  Users, 
  FolderKanban, 
  CheckSquare, 
  Receipt, 
  CreditCard, 
  Calendar, 
  UserCheck, 
  FileBarChart2, 
  ShieldCheck, 
  Sliders, 
  Crown,
  Trophy,
  Pin,
  Upload,
  Bot,
  Bell
} from 'lucide-react';

const MainLayout: React.FC = () => {
  const { 
    activeTab, 
    setActiveTab,
    isUploadModalOpen,
    setIsUploadModalOpen,
    isStickyDrawerOpen,
    setIsStickyDrawerOpen,
    isNotificationCenterOpen,
    setIsNotificationCenterOpen,
    stickyNotes,
    gamificationProfiles,
    currentUser
  } = useApp();

  const [isIntegrationsOpen, setIsIntegrationsOpen] = useState(false);
  const [isMobileMoreOpen, setIsMobileMoreOpen] = useState(false);

  // Quick action modal triggers
  const handleNewTask = () => setActiveTab('tasks');
  const handleNewInvoice = () => setActiveTab('invoices');
  const handleNewMeeting = () => setActiveTab('calendar');
  const handleNewExpense = () => setActiveTab('expenses');

  const userProfile = gamificationProfiles.find(p => p.userId === currentUser.id);
  const pinnedStickyCount = stickyNotes.filter(n => n.isPinned).length;

  const MORE_NAV_ITEMS = [
    { id: 'notifications', label: 'Notification Center (Real-time)', icon: Bell, color: 'text-indigo-400' },
    { id: 'gemini', label: 'Gemini AI Copilot & Maps', icon: Bot, color: 'text-indigo-400' },
    { id: 'clients', label: 'Clients & CRM', icon: Users },
    { id: 'expenses', label: 'Expenses & Budget', icon: CreditCard },
    { id: 'gamification', label: `Merit & Gamification (Lvl ${userProfile?.level || 1})`, icon: Trophy, color: 'text-amber-400' },
    { id: 'sticky', label: `Sticky Notes & Scratchpad (${stickyNotes.length})`, icon: Pin, color: 'text-amber-400' },
    { id: 'team', label: 'Team & Consultants (RBAC)', icon: UserCheck },
    { id: 'reports', label: 'Reports & Analytics', icon: FileBarChart2 },
    { id: 'audit', label: 'Audit Log & Security', icon: ShieldCheck },
    { id: 'settings', label: 'Super Admin & Admin Settings', icon: Sliders },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-600 selection:text-white relative">
      {/* Top Navbar */}
      <Navbar onOpenIntegrations={() => setIsIntegrationsOpen(true)} />

      {/* Main Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Desktop Sidebar */}
        <div className="hidden md:block">
          <Sidebar onOpenIntegrations={() => setIsIntegrationsOpen(true)} />
        </div>

        {/* Content Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full pb-24 md:pb-8">
          {activeTab === 'dashboard' && (
            <ExecutiveDashboard
              onNewTask={handleNewTask}
              onNewInvoice={handleNewInvoice}
              onNewMeeting={handleNewMeeting}
              onNewExpense={handleNewExpense}
            />
          )}
          {activeTab === 'notifications' && <NotificationCenter mode="page" />}
          {activeTab === 'clients' && <ClientManager />}
          {activeTab === 'projects' && <ProjectManager />}
          {activeTab === 'tasks' && <TaskManager />}
          {activeTab === 'invoices' && <InvoiceManager />}
          {activeTab === 'expenses' && <ExpenseManager />}
          {activeTab === 'calendar' && <CalendarMeetScheduler />}
          {activeTab === 'team' && <TeamManager />}
          {activeTab === 'reports' && <ReportsManager />}
          {activeTab === 'audit' && <AuditLogManager />}
          {activeTab === 'settings' && <SettingsManager />}
          {activeTab === 'gamification' && <GamificationManager />}
          {activeTab === 'sticky' && <StickyNotesManager />}
          {activeTab === 'gemini' && <GeminiCopilot />}
        </main>
      </div>

      {/* Slide-over Notification Center Drawer */}
      <NotificationCenter
        mode="drawer"
        isOpen={isNotificationCenterOpen}
        onClose={() => setIsNotificationCenterOpen(false)}
      />

      {/* Floating Quick Sticky Notes Dock Trigger */}
      <div className="fixed bottom-16 md:bottom-6 right-4 md:right-6 z-40">
        <Tooltip content="Quick Sticky Notes Scratchpad" position="left">
          <button
            onClick={() => setIsStickyDrawerOpen(true)}
            className="p-3 bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-xl shadow-amber-950/40 border border-amber-400 flex items-center gap-2 group transition-all duration-200 hover:scale-105"
            aria-label="Open Scratchpad"
          >
            <Pin className="w-5 h-5 shrink-0 text-slate-950" />
            <span className="hidden sm:inline font-mono font-bold text-xs uppercase tracking-wider">
              Notes
            </span>
            {stickyNotes.length > 0 && (
              <span className="w-5 h-5 rounded-full bg-slate-950 text-amber-300 text-[10px] font-mono font-bold flex items-center justify-center">
                {stickyNotes.length}
              </span>
            )}
          </button>
        </Tooltip>
      </div>

      {/* Sticky Notes Quick Slide Drawer */}
      <StickyQuickDrawer />

      {/* Format Ingest & Upload Modal */}
      <FormatUploadModal
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
      />

      {/* Mobile Bottom Dock */}
      <MobileNav onOpenMore={() => setIsMobileMoreOpen(true)} />

      {/* Mobile 'More' Drawer */}
      {isMobileMoreOpen && (
        <div className="fixed inset-0 z-50 md:hidden flex flex-col justify-end bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border-t border-slate-700 p-5 space-y-4 max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                More Operations Modules
              </span>
              <button onClick={() => setIsMobileMoreOpen(false)} className="text-slate-400 p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-1">
              {MORE_NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      setIsMobileMoreOpen(false);
                    }}
                    className="w-full flex items-center gap-3 p-3 text-xs text-slate-200 hover:bg-slate-800 transition-colors text-left"
                  >
                    <Icon className={`w-4 h-4 ${item.color || 'text-indigo-400'}`} />
                    <span className="font-medium">{item.label}</span>
                  </button>
                );
              })}

              <button
                onClick={() => {
                  setIsUploadModalOpen(true);
                  setIsMobileMoreOpen(false);
                }}
                className="w-full flex items-center gap-3 p-3 text-xs text-emerald-300 hover:bg-slate-800 transition-colors text-left"
              >
                <Upload className="w-4 h-4 text-emerald-400" />
                <span className="font-medium">Ingest Files / CSV / JSON Vault</span>
              </button>

              <button
                onClick={() => {
                  setIsIntegrationsOpen(true);
                  setIsMobileMoreOpen(false);
                }}
                className="w-full flex items-center gap-3 p-3 text-xs text-indigo-300 hover:bg-slate-800 transition-colors text-left"
              >
                <Layers className="w-4 h-4 text-indigo-400" />
                <span className="font-medium">Third-Party Integrations (Slack/Google/API)</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Integrations Modal */}
      <IntegrationsModal
        isOpen={isIntegrationsOpen}
        onClose={() => setIsIntegrationsOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
