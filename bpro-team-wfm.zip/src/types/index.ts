export type UserRole = 'super_admin' | 'admin' | 'project_manager' | 'team_member' | 'external_consultant' | 'client_stakeholder';

export interface UserPermissions {
  canManageClients: boolean;
  canManageProjects: boolean;
  canAssignTasks: boolean;
  canEditDeadlines: boolean;
  canViewFinancials: boolean;
  canCreateInvoices: boolean;
  canApproveExpenses: boolean;
  canManageTeam: boolean;
  canManageIntegrations: boolean;
  canExportReports: boolean;
  canManageSettings?: boolean;
}

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  avatarUrl: string;
  role: UserRole;
  isExternal: boolean;
  designation?: string;
  department?: string;
  phone?: string;
  location?: string;
  bio?: string;
  // Social Logins & Profiles
  linkedIn?: string;
  github?: string;
  twitter?: string;
  portfolio?: string;
  // Professional Details
  certifications?: string[];
  skills?: string[];
  hourlyRate?: number;
  consultantOrg?: string;
  panNumber?: string;
  emergencyContact?: string;
  permissions: UserPermissions;
  activeStatus: 'active' | 'invited' | 'inactive';
  joinedDate: string;
  assignedProjectIds: string[];
}

export interface OrgSettings {
  companyName: string;
  tagline: string;
  legalEntity: string;
  gstin: string;
  pan: string;
  officialEmail: string;
  phone: string;
  registeredAddress: string;
  baseCurrency: string; // 'INR'
  invoicePrefix: string;
  defaultGstRate: number; // e.g. 18%
  hsnSacCode: string;
  // Banking & UPI
  bankName: string;
  accountNumber: string;
  ifscCode: string;
  branch: string;
  upiId: string;
  // Governance
  superAdminEmails: string[];
  enforceMfa: boolean;
  requireApprovalOverAmount: number;
  restrictConsultants: boolean;
  sessionTimeoutMinutes: number;
  auditRetentionDays: number;
}

export interface Client {
  id: string;
  name: string;
  company: string;
  email: string;
  phone: string;
  address: string;
  taxId?: string;
  currency: string;
  defaultHourlyRate: number;
  status: 'active' | 'lead' | 'on_hold' | 'archived';
  notes?: string;
  createdAt: string;
}

export interface Project {
  id: string;
  clientId: string;
  title: string;
  code: string;
  description: string;
  budget: number;
  hourlyRate: number;
  startDate: string;
  targetDeadline: string;
  status: 'planning' | 'in_progress' | 'review' | 'completed' | 'on_hold';
  healthScore: 'healthy' | 'at_risk' | 'critical';
  assignedMemberIds: string[];
  totalLoggedHours: number;
  billingType: 'hourly' | 'fixed' | 'retainer';
}

export type TaskStatus = 'backlog' | 'in_progress' | 'in_review' | 'blocked' | 'completed';
export type TaskPriority = 'low' | 'medium' | 'high' | 'urgent';

export interface DeadlineAmendment {
  id: string;
  taskId: string;
  previousDeadline: string;
  newDeadline: string;
  reason: string;
  amendedBy: string;
  amendedByName: string;
  timestamp: string;
  pushedDays: number;
}

export interface Task {
  id: string;
  projectId: string;
  clientId: string;
  title: string;
  description: string;
  status: TaskStatus;
  priority: TaskPriority;
  assignedToId: string;
  createdBy: string;
  dueDate: string;
  estimatedHours: number;
  actualHours: number;
  completedAt?: string;
  tags: string[];
  googleCalendarEventId?: string;
  googleMeetLink?: string;
  amendments: DeadlineAmendment[];
  createdAt: string;
  updatedAt: string;
}

export type InvoiceStatus = 'draft' | 'sent' | 'paid' | 'overdue' | 'cancelled';

export interface InvoiceLineItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  amount: number;
  type: 'hours' | 'fixed_milestone' | 'expense' | 'retainer';
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  clientId: string;
  projectId?: string;
  issueDate: string;
  dueDate: string;
  status: InvoiceStatus;
  currency: string;
  items: InvoiceLineItem[];
  subtotal: number;
  taxRate: number;
  taxAmount: number;
  discountRate: number;
  discountAmount: number;
  total: number;
  notes: string;
  paymentTerms: string;
  bankDetails: string;
  paidAt?: string;
  createdAt: string;
}

export type ExpenseCategory = 
  | 'travel'
  | 'software_licenses'
  | 'equipment'
  | 'subcontractor'
  | 'meals_entertainment'
  | 'cloud_hosting'
  | 'office_supplies'
  | 'other';

export type ExpenseStatus = 'pending' | 'approved' | 'rejected' | 'reimbursed';

export interface Expense {
  id: string;
  projectId: string;
  clientId: string;
  submittedById: string;
  submittedByName: string;
  date: string;
  category: ExpenseCategory;
  description: string;
  amount: number;
  currency: string;
  isBillable: boolean;
  status: ExpenseStatus;
  approvedById?: string;
  approvalDate?: string;
  rejectionReason?: string;
  receiptFileName?: string;
  invoicedInId?: string;
  createdAt: string;
}

export interface MeetingSchedule {
  id: string;
  title: string;
  description: string;
  clientId: string;
  projectId?: string;
  startTime: string;
  endTime: string;
  attendeeEmails: string[];
  googleMeetLink: string;
  googleCalendarEventId?: string;
  scheduledBy: string;
  createdAt: string;
}

export interface SlackWebhookConfig {
  webhookUrl: string;
  channelName: string;
  isEnabled: boolean;
  notifyOnTaskComplete: boolean;
  notifyOnDeadlinePush: boolean;
  notifyOnInvoiceCreated: boolean;
  notifyOnExpenseSubmitted: boolean;
  lastTestedAt?: string;
}

export type NotificationCategory = 'deadline' | 'task' | 'invoice' | 'system';
export type NotificationUrgency = 'critical' | 'high' | 'medium' | 'normal';

export interface SystemNotification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'success' | 'alert';
  category?: NotificationCategory;
  urgency?: NotificationUrgency;
  entityId?: string;
  source?: 'firebase' | 'local';
  meta?: {
    dueDate?: string;
    amount?: number;
    invoiceNumber?: string;
    taskTitle?: string;
    clientName?: string;
    assigneeName?: string;
    daysRemaining?: number;
  };
  timestamp: string;
  isRead: boolean;
  linkAction?: string;
}

export interface AuditLogEntry {
  id: string;
  actorId: string;
  actorName: string;
  action: string;
  entityType: 'task' | 'invoice' | 'expense' | 'project' | 'client' | 'integration' | 'team';
  entityId: string;
  details: string;
  timestamp: string;
  severity?: 'info' | 'warning' | 'critical' | 'security';
  ipAddress?: string;
  hash?: string;
  metadata?: Record<string, any>;
}

export type StickyNoteColor = 'amber' | 'emerald' | 'sky' | 'rose' | 'violet' | 'indigo';

export interface StickyChecklistItem {
  id: string;
  text: string;
  completed: boolean;
}

export interface StickyNote {
  id: string;
  title: string;
  content: string;
  color: StickyNoteColor;
  isPinned: boolean;
  checklist: StickyChecklistItem[];
  clientId?: string;
  projectId?: string;
  authorId: string;
  authorName: string;
  authorAvatar?: string;
  createdAt: string;
  updatedAt: string;
}

export interface UserAchievement {
  id: string;
  badgeCode: string;
  title: string;
  description: string;
  category: 'delivery' | 'revenue' | 'quality' | 'leadership' | 'streak';
  icon: string;
  awardedAt: string;
  xpValue: number;
}

export interface KudosEntry {
  id: string;
  fromId: string;
  fromName: string;
  toUserId: string;
  reason: string;
  stars: number;
  date: string;
}

export interface GamificationProfile {
  userId: string;
  currentXp: number;
  level: number;
  levelTitle: string;
  streakDays: number;
  achievements: UserAchievement[];
  kudosReceived: KudosEntry[];
}

export interface UploadedDocument {
  id: string;
  name: string;
  size: number;
  type: string;
  category: 'receipt' | 'contract' | 'specification' | 'statement' | 'other';
  uploadedBy: string;
  uploadedByName: string;
  uploadedAt: string;
  dataPreview?: string;
  associatedEntity?: {
    type: 'expense' | 'invoice' | 'project' | 'client';
    id: string;
  };
}
