import { getAccessToken } from './firebaseAuth';

export interface CalendarEventPayload {
  title: string;
  description: string;
  startDate: string; // ISO string or YYYY-MM-DD
  endDate: string;
  attendees?: string[];
  createMeetLink?: boolean;
}

export interface CreatedCalendarEvent {
  id: string;
  htmlLink: string;
  meetLink?: string;
  summary: string;
}

// Generate an enterprise Google Meet style room code (e.g. omn-team-sync or xyz-pqrs-uvw)
export const generateMeetCode = (prefix: string = 'omn'): string => {
  const chars = 'abcdefghijklmnopqrstuvwxyz';
  const rand = (len: number) => Array.from({ length: len }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  return `https://meet.google.com/${prefix}-${rand(4)}-${rand(3)}`;
};

// Direct Web Intent link for Google Calendar (works 100% anytime, anywhere)
export const createGoogleCalendarWebIntent = (payload: {
  title: string;
  description: string;
  startDate: string;
  endDate?: string;
  location?: string;
  addEmails?: string[];
}): string => {
  const baseUrl = 'https://calendar.google.com/calendar/render?action=TEMPLATE';
  
  // Format dates: YYYYMMDDTHHMMSSZ or YYYYMMDD
  const formatGCalDate = (dateStr: string) => {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return new Date().toISOString().replace(/-|:|\.\d\d\d/g, '');
    return d.toISOString().replace(/-|:|\.\d\d\d/g, '');
  };

  const start = formatGCalDate(payload.startDate);
  const end = payload.endDate ? formatGCalDate(payload.endDate) : formatGCalDate(new Date(new Date(payload.startDate).getTime() + 60 * 60 * 1000).toISOString());

  const params = new URLSearchParams({
    text: payload.title,
    dates: `${start}/${end}`,
    details: payload.description,
  });

  if (payload.location) {
    params.set('location', payload.location);
  }
  if (payload.addEmails && payload.addEmails.length > 0) {
    params.set('add', payload.addEmails.join(','));
  }

  return `${baseUrl}&${params.toString()}`;
};

// Generates an .ics file download for standard calendar import
export const downloadIcsFile = (payload: {
  title: string;
  description: string;
  startDate: string;
  endDate?: string;
  filename?: string;
}) => {
  const formatIcsDate = (dateStr: string) => {
    const d = new Date(dateStr);
    return isNaN(d.getTime()) 
      ? new Date().toISOString().replace(/-|:|\.\d\d\d/g, '') 
      : d.toISOString().replace(/-|:|\.\d\d\d/g, '');
  };

  const start = formatIcsDate(payload.startDate);
  const end = payload.endDate ? formatIcsDate(payload.endDate) : formatIcsDate(new Date(new Date(payload.startDate).getTime() + 60 * 60 * 1000).toISOString());

  const icsContent = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Bpro PMS//Calendar Integration//EN',
    'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH',
    'BEGIN:VEVENT',
    `UID:${Date.now()}@bropms.com`,
    `DTSTAMP:${formatIcsDate(new Date().toISOString())}`,
    `DTSTART:${start}`,
    `DTEND:${end}`,
    `SUMMARY:${payload.title}`,
    `DESCRIPTION:${payload.description.replace(/\n/g, '\\n')}`,
    'STATUS:CONFIRMED',
    'END:VEVENT',
    'END:VCALENDAR'
  ].join('\r\n');

  const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', `${payload.filename || 'meeting-event'}.ics`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

// Official Google Calendar REST API Call (Requires OAuth Access Token)
export const createGoogleCalendarEventViaApi = async (
  payload: CalendarEventPayload
): Promise<CreatedCalendarEvent> => {
  const token = await getAccessToken();
  if (!token) {
    throw new Error('Not authenticated with Google Workspace. Please sign in with Google first.');
  }

  const startDateObj = new Date(payload.startDate);
  const endDateObj = payload.endDate ? new Date(payload.endDate) : new Date(startDateObj.getTime() + 60 * 60 * 1000);

  const requestBody: Record<string, any> = {
    summary: payload.title,
    description: payload.description,
    start: {
      dateTime: startDateObj.toISOString(),
      timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    },
    end: {
      dateTime: endDateObj.toISOString(),
      timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    },
  };

  if (payload.attendees && payload.attendees.length > 0) {
    requestBody.attendees = payload.attendees.map(email => ({ email }));
  }

  if (payload.createMeetLink) {
    requestBody.conferenceData = {
      createRequest: {
        requestId: `omni-${Date.now()}`,
        conferenceSolutionKey: { type: 'hangoutsMeet' },
      },
    };
  }

  const endpoint = `https://www.googleapis.com/calendar/v3/calendars/primary/events?conferenceDataVersion=1`;
  const response = await fetch(endpoint, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(requestBody),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error?.message || `Failed to create calendar event (${response.status})`);
  }

  const data = await response.json();
  const meetUri = data.conferenceData?.entryPoints?.find((ep: any) => ep.entryPointType === 'video')?.uri 
    || data.hangoutLink 
    || undefined;

  return {
    id: data.id,
    htmlLink: data.htmlLink,
    meetLink: meetUri,
    summary: data.summary,
  };
};

export const listUpcomingCalendarEvents = async (maxResults: number = 10): Promise<any[]> => {
  const token = await getAccessToken();
  if (!token) return [];

  const now = new Date().toISOString();
  const url = `https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=${encodeURIComponent(now)}&maxResults=${maxResults}&singleEvents=true&orderBy=startTime`;

  try {
    const res = await fetch(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.items || [];
  } catch (err) {
    console.error('Error fetching Google Calendar events:', err);
    return [];
  }
};
