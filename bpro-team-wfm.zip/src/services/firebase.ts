import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getFirestore, 
  doc, 
  getDocFromServer, 
  collection, 
  getDocs, 
  setDoc, 
  deleteDoc,
  writeBatch,
  onSnapshot,
  query,
  orderBy,
  limit,
  Unsubscribe
} from 'firebase/firestore';
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut as firebaseSignOut, 
  onAuthStateChanged,
  User as FirebaseUser
} from 'firebase/auth';

import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase App
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Initialize Firestore with specific database ID if provided
export const db = firebaseConfig.firestoreDatabaseId
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

// Initialize Firebase Auth
export const auth = getAuth(app);
export const googleAuthProvider = new GoogleAuthProvider();
googleAuthProvider.setCustomParameters({
  prompt: 'select_account'
});

// Test connection on boot per Firebase skill guidelines
export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log('[Firebase] Connection to Firestore verified.');
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('[Firebase] Client is offline or Firestore is unreachable.', error.message);
    } else {
      console.log('[Firebase] Connection test acknowledged:', error);
    }
    return false;
  }
}

// Auth helpers
export async function signInWithGoogleFirebase(): Promise<FirebaseUser> {
  const result = await signInWithPopup(auth, googleAuthProvider);
  return result.user;
}

export async function signOutFirebase(): Promise<void> {
  await firebaseSignOut(auth);
}

// Firestore Persistence helpers
export const firestoreService = {
  async saveCollection<T extends { id: string }>(collectionName: string, items: T[]): Promise<void> {
    try {
      const batch = writeBatch(db);
      for (const item of items) {
        const docRef = doc(db, collectionName, item.id);
        batch.set(docRef, item, { merge: true });
      }
      await batch.commit();
    } catch (err) {
      console.error(`[Firebase] Error saving to ${collectionName}:`, err);
    }
  },

  async loadCollection<T>(collectionName: string): Promise<T[]> {
    try {
      const colRef = collection(db, collectionName);
      const snapshot = await getDocs(colRef);
      return snapshot.docs.map(d => d.data() as T);
    } catch (err) {
      console.error(`[Firebase] Error loading from ${collectionName}:`, err);
      return [];
    }
  },

  async setDocument<T extends Record<string, any>>(collectionName: string, docId: string, data: T): Promise<void> {
    try {
      const docRef = doc(db, collectionName, docId);
      await setDoc(docRef, data, { merge: true });
    } catch (err) {
      console.error(`[Firebase] Error saving document ${collectionName}/${docId}:`, err);
    }
  },

  async deleteDocument(collectionName: string, docId: string): Promise<void> {
    try {
      const docRef = doc(db, collectionName, docId);
      await deleteDoc(docRef);
    } catch (err) {
      console.error(`[Firebase] Error deleting document ${collectionName}/${docId}:`, err);
    }
  },

  // Real-time Firestore Subscriptions
  subscribeToCollection<T>(
    collectionName: string, 
    onData: (items: T[]) => void, 
    onError?: (err: any) => void
  ): Unsubscribe {
    const colRef = collection(db, collectionName);
    return onSnapshot(
      colRef,
      (snapshot) => {
        const items = snapshot.docs.map(d => ({ ...d.data(), id: d.id } as T));
        onData(items);
      },
      (err) => {
        if (onError) onError(err);
        else console.warn(`[Firebase Realtime] Listener error on ${collectionName}:`, err);
      }
    );
  },

  subscribeToNotifications(
    onData: (notifications: any[]) => void,
    onError?: (err: any) => void
  ): Unsubscribe {
    const colRef = collection(db, 'notifications');
    const q = query(colRef, limit(50));
    return onSnapshot(
      q,
      (snapshot) => {
        const items = snapshot.docs.map(d => ({ ...d.data(), id: d.id }));
        onData(items);
      },
      (err) => {
        if (onError) onError(err);
        else console.warn('[Firebase Realtime] Notifications listener error:', err);
      }
    );
  },

  async pushNotification(notification: any): Promise<void> {
    try {
      const docRef = doc(db, 'notifications', notification.id);
      await setDoc(docRef, notification, { merge: true });
    } catch (err) {
      console.error('[Firebase] Failed to push notification:', err);
    }
  },

  async markNotificationRead(id: string): Promise<void> {
    try {
      const docRef = doc(db, 'notifications', id);
      await setDoc(docRef, { isRead: true }, { merge: true });
    } catch (err) {
      console.error('[Firebase] Failed to mark notification read:', err);
    }
  },

  async clearNotifications(): Promise<void> {
    try {
      const colRef = collection(db, 'notifications');
      const snapshot = await getDocs(colRef);
      const batch = writeBatch(db);
      snapshot.docs.forEach(d => {
        batch.delete(d.ref);
      });
      await batch.commit();
    } catch (err) {
      console.error('[Firebase] Failed to clear notifications:', err);
    }
  }
};
