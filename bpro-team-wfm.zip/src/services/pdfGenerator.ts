import { jsPDF } from 'jspdf';
import { Invoice, Client, Project, Expense, Task, TeamMember } from '../types';

export const generateInvoicePdf = (invoice: Invoice, client: Client, project?: Project) => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 18;

  // Background / Header Accent Bar
  doc.setFillColor(15, 23, 42); // slate-900
  doc.rect(0, 0, pageWidth, 28, 'F');

  // Accent Line
  doc.setFillColor(99, 102, 241); // indigo-500
  doc.rect(0, 26.5, pageWidth, 1.5, 'F');

  // Brand Header
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text('BPRO PMS GLOBAL', margin, 14);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(199, 210, 254);
  doc.text('ENTERPRISE CLIENT MANAGEMENT & BILLING PLATFORM', margin, 20);

  // Invoice Title on Right
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.setTextColor(255, 255, 255);
  doc.text('INVOICE', pageWidth - margin, 14, { align: 'right' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(226, 232, 240);
  doc.text(`#${invoice.invoiceNumber}`, pageWidth - margin, 20, { align: 'right' });

  // Metadata Row below header
  let y = 38;
  doc.setTextColor(71, 85, 105);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.text('ISSUE DATE', margin, y);
  doc.text('DUE DATE', margin + 45, y);
  doc.text('PAYMENT TERMS', margin + 90, y);
  doc.text('STATUS', pageWidth - margin, y, { align: 'right' });

  y += 5;
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text(invoice.issueDate, margin, y);
  doc.text(invoice.dueDate, margin + 45, y);
  doc.text(invoice.paymentTerms || 'Net 30', margin + 90, y);

  // Status Badge
  const statusColors: Record<string, [number, number, number]> = {
    paid: [16, 185, 129],
    sent: [99, 102, 241],
    draft: [100, 116, 139],
    overdue: [239, 68, 68],
  };
  const color = statusColors[invoice.status] || [100, 116, 139];
  doc.setTextColor(color[0], color[1], color[2]);
  doc.setFont('helvetica', 'bold');
  doc.text(invoice.status.toUpperCase(), pageWidth - margin, y, { align: 'right' });

  // Divider
  y += 8;
  doc.setDrawColor(226, 232, 240);
  doc.line(margin, y, pageWidth - margin, y);

  // Billed By & Billed To
  y += 8;
  doc.setTextColor(100, 116, 139);
  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'bold');
  doc.text('BILLED FROM', margin, y);
  doc.text('BILLED TO', pageWidth / 2 + 5, y);

  y += 5;
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.text('Bpro PMS Global Solutions Pvt Ltd', margin, y);
  doc.text(client.company || client.name, pageWidth / 2 + 5, y);

  y += 4.5;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105);
  doc.text('GSTIN: 32AABCB1234F1Z8 | PAN: AABCB1234F', margin, y);
  doc.text(`Attn: ${client.name}`, pageWidth / 2 + 5, y);

  y += 4;
  doc.text('Infopark T3, Silicon Corridor, Kochi & Bangalore', margin, y);
  doc.text(client.address || 'Corporate Billing Address, India', pageWidth / 2 + 5, y);

  y += 4;
  doc.text('tech@bropms.com | +91 98470 12345', margin, y);
  doc.text(`${client.email} | ${client.phone || ''}`, pageWidth / 2 + 5, y);

  if (client.taxId) {
    y += 4;
    doc.text(`Tax / VAT ID: ${client.taxId}`, pageWidth / 2 + 5, y);
  }

  if (project) {
    y += 6;
    doc.setFillColor(241, 245, 249);
    doc.roundedRect(margin, y, pageWidth - margin * 2, 8, 1, 1, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(71, 85, 105);
    doc.text(`PROJECT REFERENCE: ${project.title} (${project.code})`, margin + 4, y + 5.5);
    y += 8;
  }

  // Table Headers
  y += 10;
  doc.setFillColor(15, 23, 42);
  doc.rect(margin, y, pageWidth - margin * 2, 7, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('ITEM DESCRIPTION', margin + 4, y + 4.8);
  doc.text('TYPE', margin + 85, y + 4.8);
  doc.text('QTY / HRS', margin + 115, y + 4.8, { align: 'right' });
  doc.text('UNIT PRICE', margin + 145, y + 4.8, { align: 'right' });
  doc.text('TOTAL', pageWidth - margin - 4, y + 4.8, { align: 'right' });

  // Table Rows
  y += 7;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(30, 41, 59);

  invoice.items.forEach((item, index) => {
    const isEven = index % 2 === 0;
    if (isEven) {
      doc.setFillColor(248, 250, 252);
      doc.rect(margin, y, pageWidth - margin * 2, 7, 'F');
    }

    doc.text(item.description, margin + 4, y + 4.8);
    doc.text(item.type.replace('_', ' ').toUpperCase(), margin + 85, y + 4.8);
    doc.text(item.quantity.toString(), margin + 115, y + 4.8, { align: 'right' });
    doc.text(`${invoice.currency} ${item.unitPrice.toFixed(2)}`, margin + 145, y + 4.8, { align: 'right' });
    doc.text(`${invoice.currency} ${item.amount.toFixed(2)}`, pageWidth - margin - 4, y + 4.8, { align: 'right' });

    y += 7;
  });

  // Table bottom line
  doc.setDrawColor(203, 213, 225);
  doc.line(margin, y, pageWidth - margin, y);

  // Financial Breakdown (Right-aligned)
  y += 6;
  const summaryX = pageWidth - margin - 60;
  const valueX = pageWidth - margin - 4;

  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105);
  doc.text('Subtotal:', summaryX, y);
  doc.text(`${invoice.currency} ${invoice.subtotal.toFixed(2)}`, valueX, y, { align: 'right' });

  if (invoice.discountAmount > 0) {
    y += 5;
    doc.text(`Discount (${invoice.discountRate}%):`, summaryX, y);
    doc.setTextColor(239, 68, 68);
    doc.text(`-${invoice.currency} ${invoice.discountAmount.toFixed(2)}`, valueX, y, { align: 'right' });
    doc.setTextColor(71, 85, 105);
  }

  y += 5;
  doc.text(`Tax (${invoice.taxRate}%):`, summaryX, y);
  doc.text(`${invoice.currency} ${invoice.taxAmount.toFixed(2)}`, valueX, y, { align: 'right' });

  y += 6;
  doc.setFillColor(241, 245, 249);
  doc.rect(summaryX - 5, y - 4, 65, 8, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);
  doc.text('TOTAL DUE:', summaryX, y + 1.5);
  doc.text(`${invoice.currency} ${invoice.total.toFixed(2)}`, valueX, y + 1.5, { align: 'right' });

  // Notes & Wire Info (Bottom Left)
  let notesY = y + 12;
  if (invoice.notes) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(71, 85, 105);
    doc.text('NOTES & SPECIAL INSTRUCTIONS:', margin, notesY);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    doc.text(invoice.notes, margin, notesY + 4, { maxWidth: 100 });
    notesY += 14;
  }

  if (invoice.bankDetails) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(71, 85, 105);
    doc.text('REMITTANCE / WIRE DETAILS:', margin, notesY);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    doc.text(invoice.bankDetails, margin, notesY + 4, { maxWidth: 100 });
  }

  // Footer / Security Hash
  doc.setDrawColor(226, 232, 240);
  doc.line(margin, pageHeight - 14, pageWidth - margin, pageHeight - 14);

  doc.setFontSize(7);
  doc.setTextColor(148, 163, 184);
  doc.text('Generated via Bpro PMS Enterprise. Secure cryptographic hash: SHA256-' + btoa(invoice.id).substring(0, 16), margin, pageHeight - 9);
  doc.text('Page 1 of 1', pageWidth - margin, pageHeight - 9, { align: 'right' });

  // Trigger download
  doc.save(`Invoice_${invoice.invoiceNumber}_${client.company || client.name}.pdf`);
};

export const generateMonthlyReportPdf = (data: {
  monthName: string;
  year: number;
  totalRevenue: number;
  totalExpenses: number;
  netMargin: number;
  billableHours: number;
  completedTasks: number;
  totalTasks: number;
  onTimeRate: number;
  postponedCount: number;
  clientBreakdown: Array<{ name: string; hours: number; revenue: number; projects: number }>;
  teamBreakdown: Array<{ name: string; role: string; hours: number; rate: number }>;
}) => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 18;

  // Header Banner
  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, pageWidth, 28, 'F');
  doc.setFillColor(16, 185, 129); // emerald accent
  doc.rect(0, 26.5, pageWidth, 1.5, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text('BPRO PMS // OPERATIONS AUDIT', margin, 14);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(209, 250, 229);
  doc.text(`EXECUTIVE MONTHLY REPORT - ${data.monthName.toUpperCase()} ${data.year}`, margin, 20);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(255, 255, 255);
  doc.text('CONFIDENTIAL', pageWidth - margin, 16, { align: 'right' });

  let y = 38;

  // KPI Metric Cards Row
  const cardW = (pageWidth - margin * 2 - 9) / 4;
  const metrics = [
    { label: 'BILLED REVENUE', value: `INR ${Math.round(data.totalRevenue).toLocaleString('en-IN')}`, color: [99, 102, 241] },
    { label: 'EXPENSES', value: `INR ${Math.round(data.totalExpenses).toLocaleString('en-IN')}`, color: [239, 68, 68] },
    { label: 'NET MARGIN', value: `INR ${Math.round(data.netMargin).toLocaleString('en-IN')}`, color: [16, 185, 129] },
    { label: 'ON-TIME DELIVERY', value: `${data.onTimeRate}%`, color: [14, 165, 233] },
  ];

  metrics.forEach((m, idx) => {
    const cx = margin + idx * (cardW + 3);
    doc.setFillColor(248, 250, 252);
    doc.roundedRect(cx, y, cardW, 16, 1, 1, 'F');
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(cx, y, cardW, 16, 1, 1, 'S');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(6.5);
    doc.setTextColor(100, 116, 139);
    doc.text(m.label, cx + 3, y + 5);

    doc.setFontSize(10.5);
    doc.setTextColor(m.color[0], m.color[1], m.color[2]);
    doc.text(m.value, cx + 3, y + 12);
  });

  y += 24;

  // Section 1: Productivity & Work Velocity Summary
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.setTextColor(15, 23, 42);
  doc.text('1. Work Execution & Deadline Adherence', margin, y);

  y += 5;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(71, 85, 105);
  doc.text(`During this cycle, a total of ${data.totalTasks} operational tasks were active, with ${data.completedTasks} successfully fulfilled.`, margin, y);
  y += 4;
  doc.text(`Total billable productivity clocked in at ${data.billableHours} hours. Tasks amended or pushed to the next day: ${data.postponedCount} incidents (fully logged with valid business justifications).`, margin, y);

  y += 10;
  // Section 2: Client Breakdown Table
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.setTextColor(15, 23, 42);
  doc.text('2. Client Portfolio & Productivity Breakdown', margin, y);

  y += 4;
  doc.setFillColor(15, 23, 42);
  doc.rect(margin, y, pageWidth - margin * 2, 6, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(7.5);
  doc.text('CLIENT / ORGANIZATION', margin + 4, y + 4.2);
  doc.text('PROJECTS', margin + 75, y + 4.2);
  doc.text('BILLABLE HOURS', margin + 115, y + 4.2, { align: 'right' });
  doc.text('REVENUE PRODUCED', pageWidth - margin - 4, y + 4.2, { align: 'right' });

  y += 6;
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(30, 41, 59);

  data.clientBreakdown.forEach((client, idx) => {
    if (idx % 2 === 0) {
      doc.setFillColor(248, 250, 252);
      doc.rect(margin, y, pageWidth - margin * 2, 6, 'F');
    }
    doc.text(client.name, margin + 4, y + 4.2);
    doc.text(client.projects.toString(), margin + 75, y + 4.2);
    doc.text(`${client.hours} hrs`, margin + 115, y + 4.2, { align: 'right' });
    doc.text(`INR ${client.revenue.toLocaleString('en-IN')}`, pageWidth - margin - 4, y + 4.2, { align: 'right' });
    y += 6;
  });

  y += 8;
  // Section 3: Team & External Consultants Utilization
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.setTextColor(15, 23, 42);
  doc.text('3. Team & Consultant Resource Allocation', margin, y);

  y += 4;
  doc.setFillColor(15, 23, 42);
  doc.rect(margin, y, pageWidth - margin * 2, 6, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(7.5);
  doc.text('NAME', margin + 4, y + 4.2);
  doc.text('ROLE / DESIGNATION', margin + 65, y + 4.2);
  doc.text('LOGGED HOURS', margin + 120, y + 4.2, { align: 'right' });
  doc.text('HOURLY RATE', pageWidth - margin - 4, y + 4.2, { align: 'right' });

  y += 6;
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(30, 41, 59);

  data.teamBreakdown.forEach((tm, idx) => {
    if (idx % 2 === 0) {
      doc.setFillColor(248, 250, 252);
      doc.rect(margin, y, pageWidth - margin * 2, 6, 'F');
    }
    doc.text(tm.name, margin + 4, y + 4.2);
    doc.text(tm.role, margin + 65, y + 4.2);
    doc.text(`${tm.hours} hrs`, margin + 120, y + 4.2, { align: 'right' });
    doc.text(`INR ${tm.rate.toLocaleString('en-IN')}/hr`, pageWidth - margin - 4, y + 4.2, { align: 'right' });
    y += 6;
  });

  // Footer
  doc.setDrawColor(226, 232, 240);
  doc.line(margin, pageHeight - 14, pageWidth - margin, pageHeight - 14);

  doc.setFontSize(7);
  doc.setTextColor(148, 163, 184);
  doc.text(`Bpro PMS Executive Monthly Summary | Generated on ${new Date().toLocaleDateString()}`, margin, pageHeight - 9);
  doc.text('Enterprise Operations Certified', pageWidth - margin, pageHeight - 9, { align: 'right' });

  doc.save(`Monthly_Operations_Report_${data.monthName}_${data.year}.pdf`);
};

export const generateExpenseAuditPdf = (expenses: Expense[], projects: Project[], clients: Client[]) => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 18;

  // Header Banner
  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, pageWidth, 28, 'F');
  doc.setFillColor(245, 158, 11); // amber accent
  doc.rect(0, 26.5, pageWidth, 1.5, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text('BPRO PMS // EXPENSE AUDIT', margin, 14);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(254, 243, 199);
  doc.text('FINANCIAL ACCOUNTING & EXPENSE RECONCILIATION STATEMENT', margin, 20);

  let y = 38;
  const totalAmount = expenses.reduce((acc, e) => acc + e.amount, 0);
  const billableAmount = expenses.filter(e => e.isBillable).reduce((acc, e) => acc + e.amount, 0);
  const approvedCount = expenses.filter(e => e.status === 'approved' || e.status === 'reimbursed').length;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(15, 23, 42);
  doc.text(`Total Records: ${expenses.length} | Gross Total: INR ${totalAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })} | Billable: INR ${billableAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })} | Approved: ${approvedCount}`, margin, y);

  y += 8;
  doc.setFillColor(15, 23, 42);
  doc.rect(margin, y, pageWidth - margin * 2, 6, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(7.5);
  doc.text('DATE', margin + 4, y + 4.2);
  doc.text('CATEGORY', margin + 25, y + 4.2);
  doc.text('SUBMITTED BY', margin + 65, y + 4.2);
  doc.text('PROJECT', margin + 105, y + 4.2);
  doc.text('STATUS', margin + 140, y + 4.2);
  doc.text('AMOUNT', pageWidth - margin - 4, y + 4.2, { align: 'right' });

  y += 6;
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(30, 41, 59);

  expenses.forEach((e, idx) => {
    const proj = projects.find(p => p.id === e.projectId);
    if (idx % 2 === 0) {
      doc.setFillColor(248, 250, 252);
      doc.rect(margin, y, pageWidth - margin * 2, 6, 'F');
    }
    doc.text(e.date, margin + 4, y + 4.2);
    doc.text(e.category.replace('_', ' ').substring(0, 15), margin + 25, y + 4.2);
    doc.text(e.submittedByName.substring(0, 18), margin + 65, y + 4.2);
    doc.text(proj ? proj.code : '-', margin + 105, y + 4.2);
    doc.text(e.status.toUpperCase(), margin + 140, y + 4.2);
    doc.text(`INR ${e.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`, pageWidth - margin - 4, y + 4.2, { align: 'right' });
    y += 6;

    if (y > pageHeight - 20) {
      doc.addPage();
      y = 20;
    }
  });

  doc.save(`Expense_Accounting_Audit_${new Date().toISOString().substring(0, 10)}.pdf`);
};

export const generateAuditLogPdf = (logs: any[]) => {
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 14;

  // Header Banner
  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, pageWidth, 26, 'F');
  doc.setFillColor(99, 102, 241); // indigo accent
  doc.rect(0, 24.5, pageWidth, 1.5, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text('BPRO PMS // ENTERPRISE SECURITY & AUDIT TRAIL CERTIFICATE', margin, 12);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(199, 210, 254);
  doc.text(`IMMUTABLE OPERATIONS LEDGER & COMPLIANCE RECORD | AUDIT TIMESTAMP: ${new Date().toISOString()}`, margin, 18);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(255, 255, 255);
  doc.text('SOC-2 / HIPAA CERTIFIED', pageWidth - margin, 15, { align: 'right' });

  let y = 34;

  // Table header
  doc.setFillColor(15, 23, 42);
  doc.rect(margin, y, pageWidth - margin * 2, 6, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(7.5);
  doc.text('TIMESTAMP', margin + 3, y + 4.2);
  doc.text('ACTOR / USER', margin + 35, y + 4.2);
  doc.text('ACTION EVENT', margin + 75, y + 4.2);
  doc.text('ENTITY', margin + 115, y + 4.2);
  doc.text('DETAILS & BUSINESS JUSTIFICATION', margin + 140, y + 4.2);
  doc.text('VERIFICATION HASH', pageWidth - margin - 3, y + 4.2, { align: 'right' });

  y += 6;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(30, 41, 59);

  logs.forEach((log, idx) => {
    if (idx % 2 === 0) {
      doc.setFillColor(248, 250, 252);
      doc.rect(margin, y, pageWidth - margin * 2, 6, 'F');
    }
    const shortDate = log.timestamp ? log.timestamp.replace('T', ' ').substring(0, 19) : '-';
    doc.text(shortDate, margin + 3, y + 4.2);
    doc.text((log.actorName || 'System').substring(0, 22), margin + 35, y + 4.2);
    doc.text((log.action || '').substring(0, 24), margin + 75, y + 4.2);
    doc.text((log.entityType || '').toUpperCase(), margin + 115, y + 4.2);
    doc.text((log.details || '').substring(0, 68), margin + 140, y + 4.2);
    const hash = log.hash || `SHA-${(log.id || 'x').substring(0, 8)}`;
    doc.text(hash, pageWidth - margin - 3, y + 4.2, { align: 'right' });

    y += 6;
    if (y > pageHeight - 16) {
      doc.addPage();
      y = 16;
    }
  });

  doc.save(`Audit_Log_Compliance_Certificate_${new Date().toISOString().substring(0, 10)}.pdf`);
};
