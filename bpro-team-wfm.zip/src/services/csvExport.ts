export const exportToCsv = (filename: string, rows: Array<Record<string, any>>) => {
  if (!rows || rows.length === 0) return;

  const headers = Object.keys(rows[0]);
  const csvContent = [
    headers.join(','),
    ...rows.map(row => 
      headers.map(field => {
        let val = row[field];
        if (val === null || val === undefined) val = '';
        if (typeof val === 'string') {
          // Escape quotes and commas
          const escaped = val.replace(/"/g, '""');
          return `"${escaped}"`;
        }
        return val;
      }).join(',')
    )
  ].join('\r\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${filename}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};
