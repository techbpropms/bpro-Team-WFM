import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Expense, ExpenseCategory, ExpenseStatus } from '../../types';
import { 
  CreditCard, 
  Plus, 
  Download, 
  FileSpreadsheet, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  DollarSign, 
  Receipt, 
  Paperclip, 
  Filter, 
  AlertCircle,
  X 
} from 'lucide-react';
import { generateExpenseAuditPdf } from '../../services/pdfGenerator';
import { exportToCsv } from '../../services/csvExport';

export const ExpenseManager: React.FC = () => {
  const { 
    expenses, 
    projects, 
    clients, 
    currentUser, 
    submitExpense, 
    approveExpense, 
    rejectExpense,
    searchQuery,
    formatCurrency
  } = useApp();

  const [isSubmitOpen, setIsSubmitOpen] = useState(false);
  const [rejectingExpenseId, setRejectingExpenseId] = useState<string | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');

  // Form State
  const [projectId, setProjectId] = useState(projects[0]?.id || '');
  const [category, setCategory] = useState<ExpenseCategory>('cloud_hosting');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState<number>(12500);
  const [currency, setCurrency] = useState('INR');
  const [isBillable, setIsBillable] = useState(true);
  const [receiptFileName, setReceiptFileName] = useState('receipt_oct_2026.pdf');

  // Filters
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const filteredExpenses = expenses.filter(e => {
    if (filterCategory !== 'all' && e.category !== filterCategory) return false;
    if (filterStatus !== 'all' && e.status !== filterStatus) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        e.description.toLowerCase().includes(q) ||
        e.submittedByName.toLowerCase().includes(q) ||
        e.category.toLowerCase().includes(q)
      );
    }
    return true;
  });

  // Analytics
  const totalGross = expenses.reduce((acc, e) => acc + e.amount, 0);
  const totalBillable = expenses.filter(e => e.isBillable).reduce((acc, e) => acc + e.amount, 0);
  const totalApproved = expenses.filter(e => e.status === 'approved' || e.status === 'reimbursed').reduce((acc, e) => acc + e.amount, 0);
  const pendingCount = expenses.filter(e => e.status === 'pending').length;

  const handleSubmitExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim() || !projectId || amount <= 0) return;

    const proj = projects.find(p => p.id === projectId);

    submitExpense({
      projectId,
      clientId: proj?.clientId || clients[0]?.id || '',
      submittedById: currentUser.id,
      submittedByName: currentUser.name,
      date: new Date().toISOString().substring(0, 10),
      category,
      description: description.trim(),
      amount: Number(amount),
      currency,
      isBillable,
      receiptFileName: receiptFileName || 'receipt_attached.pdf',
    });

    setIsSubmitOpen(false);
    setDescription('');
    setAmount(100);
  };

  const handleExportCsv = () => {
    const rows = expenses.map(e => {
      const proj = projects.find(p => p.id === e.projectId);
      return {
        'Date': e.date,
        'Project': proj?.code || '',
        'Category': e.category,
        'Description': e.description,
        'Amount': e.amount,
        'Currency': e.currency,
        'Billable': e.isBillable ? 'YES' : 'NO',
        'Status': e.status.toUpperCase(),
        'Submitted By': e.submittedByName,
        'Receipt Attached': e.receiptFileName || 'None',
      };
    });
    exportToCsv(`BproPMS_Expenses_Audit_${new Date().toISOString().substring(0, 10)}`, rows);
  };

  const statusBadges: Record<ExpenseStatus, string> = {
    pending: 'bg-amber-950/60 text-amber-400 border-amber-800/60',
    approved: 'bg-emerald-950/60 text-emerald-400 border-emerald-800/60',
    rejected: 'bg-rose-950/60 text-rose-400 border-rose-800/60',
    reimbursed: 'bg-indigo-950/60 text-indigo-400 border-indigo-800/60',
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-slate-900 border border-slate-800">
        <div>
          <h1 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-amber-400" />
            <span>Expenses Tracking & Fiscal Approvals</span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Submit out-of-pocket costs, track billable project client allocations & generate compliance audits
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => generateExpenseAuditPdf(expenses, projects, clients)}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
            <span>Audit PDF</span>
          </button>

          <button
            onClick={handleExportCsv}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={() => setIsSubmitOpen(true)}
            className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Submit Expense</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-slate-900 border border-slate-800 space-y-1">
          <span className="text-[11px] font-mono uppercase text-slate-400">Gross Submitted</span>
          <div className="text-xl font-bold font-mono text-slate-100">{formatCurrency(totalGross, true)}</div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 space-y-1">
          <span className="text-[11px] font-mono uppercase text-indigo-400">Billable to Clients</span>
          <div className="text-xl font-bold font-mono text-indigo-400">{formatCurrency(totalBillable, true)}</div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 space-y-1">
          <span className="text-[11px] font-mono uppercase text-emerald-400">Approved for Payout</span>
          <div className="text-xl font-bold font-mono text-emerald-400">{formatCurrency(totalApproved, true)}</div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 space-y-1">
          <span className="text-[11px] font-mono uppercase text-amber-400">Awaiting Manager Review</span>
          <div className="text-xl font-bold font-mono text-amber-400">{pendingCount} items</div>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="p-3 bg-slate-900/60 border border-slate-800 flex flex-wrap items-center gap-3 text-xs">
        <div className="flex items-center gap-1.5 text-slate-400">
          <Filter className="w-3.5 h-3.5 text-amber-400" />
          <span>Category Filter:</span>
        </div>
        <select
          value={filterCategory}
          onChange={(e) => setFilterCategory(e.target.value)}
          className="bg-slate-950 border border-slate-800 text-slate-300 px-2.5 py-1 focus:outline-none focus:border-indigo-500 font-medium"
        >
          <option value="all">All Categories</option>
          <option value="cloud_hosting">Cloud Hosting</option>
          <option value="software_licenses">Software Licenses</option>
          <option value="subcontractor">Subcontractor</option>
          <option value="travel">Travel</option>
          <option value="equipment">Equipment</option>
          <option value="meals_entertainment">Meals & Client Entertainment</option>
        </select>

        <span className="text-slate-400 ml-2">Status:</span>
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="bg-slate-950 border border-slate-800 text-slate-300 px-2.5 py-1 focus:outline-none focus:border-indigo-500 font-medium"
        >
          <option value="all">All Statuses</option>
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
          <option value="reimbursed">Reimbursed</option>
        </select>

        <span className="text-slate-500 ml-auto font-mono text-[11px]">
          Showing {filteredExpenses.length} entries
        </span>
      </div>

      {/* Expense Table */}
      <div className="bg-slate-900 border border-slate-800 overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-slate-950 border-b border-slate-800 text-slate-400 font-mono text-[11px]">
              <th className="p-3.5">DATE</th>
              <th className="p-3.5">CATEGORY & DESCRIPTION</th>
              <th className="p-3.5">SUBMITTED BY</th>
              <th className="p-3.5">PROJECT</th>
              <th className="p-3.5">BILLABLE</th>
              <th className="p-3.5">RECEIPT</th>
              <th className="p-3.5">STATUS</th>
              <th className="p-3.5 text-right">AMOUNT</th>
              <th className="p-3.5 text-right">ACTIONS</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-slate-200">
            {filteredExpenses.map((exp) => {
              const proj = projects.find(p => p.id === exp.projectId);

              return (
                <tr key={exp.id} className="hover:bg-slate-850/50 transition-colors">
                  <td className="p-3.5 font-mono text-slate-400">{exp.date}</td>
                  <td className="p-3.5">
                    <div className="font-semibold text-slate-100">{exp.description}</div>
                    <div className="text-[11px] text-slate-400 font-mono capitalize mt-0.5">
                      {exp.category.replace('_', ' ')}
                    </div>
                    {exp.rejectionReason && (
                      <div className="text-[11px] text-rose-400 mt-1 bg-rose-950/40 p-1.5 border border-rose-900/40">
                        Rejected: {exp.rejectionReason}
                      </div>
                    )}
                  </td>
                  <td className="p-3.5 font-medium text-slate-300">{exp.submittedByName}</td>
                  <td className="p-3.5 font-mono text-slate-400">{proj?.code || '-'}</td>
                  <td className="p-3.5">
                    <span className={`px-1.5 py-0.2 font-mono text-[10px] uppercase ${exp.isBillable ? 'text-emerald-400 bg-emerald-950 border border-emerald-800' : 'text-slate-500 bg-slate-900 border border-slate-800'}`}>
                      {exp.isBillable ? 'Billable' : 'Internal'}
                    </span>
                  </td>
                  <td className="p-3.5 font-mono text-[11px] text-slate-400">
                    {exp.receiptFileName ? (
                      <span className="flex items-center gap-1 text-slate-300">
                        <Paperclip className="w-3 h-3 text-slate-500" />
                        <span className="truncate max-w-[120px]">{exp.receiptFileName}</span>
                      </span>
                    ) : (
                      'None'
                    )}
                  </td>
                  <td className="p-3.5">
                    <span className={`px-2 py-0.5 border text-[10px] uppercase font-mono font-bold ${statusBadges[exp.status]}`}>
                      {exp.status}
                    </span>
                  </td>
                  <td className="p-3.5 text-right font-mono font-bold text-slate-100 text-sm">
                    {formatCurrency(exp.amount, true)}
                  </td>
                  <td className="p-3.5 text-right">
                    {currentUser.permissions.canApproveExpenses && exp.status === 'pending' ? (
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => approveExpense(exp.id)}
                          className="px-2.5 py-1 bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border border-emerald-700/60 text-xs font-semibold flex items-center gap-1 transition-colors"
                        >
                          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                          <span>Approve</span>
                        </button>
                        <button
                          onClick={() => setRejectingExpenseId(exp.id)}
                          className="px-2 py-1 bg-rose-950/60 hover:bg-rose-900 text-rose-300 border border-rose-800 text-xs font-medium transition-colors"
                        >
                          <XCircle className="w-3 h-3 text-rose-400" />
                          <span>Reject</span>
                        </button>
                      </div>
                    ) : (
                      <span className="text-[11px] text-slate-500 font-mono">
                        {exp.approvalDate ? `Approved on ${exp.approvalDate}` : 'Processed'}
                      </span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Submit Expense Modal */}
      {isSubmitOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-lg shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-amber-400" />
                <span>Submit Expense for Reimbursement</span>
              </h2>
              <button onClick={() => setIsSubmitOpen(false)} className="text-slate-400 hover:text-slate-200">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitExpense} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Expense Description *</label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="e.g. AWS c6i benchmark instances for Kafka load test"
                  className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 focus:outline-none focus:border-indigo-500"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Project Code *</label>
                  <select
                    value={projectId}
                    onChange={(e) => setProjectId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    {projects.map(p => (
                      <option key={p.id} value={p.id}>{p.code} - {p.title}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Expense Category *</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as ExpenseCategory)}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500 capitalize"
                  >
                    <option value="cloud_hosting">Cloud Hosting</option>
                    <option value="software_licenses">Software Licenses</option>
                    <option value="subcontractor">Subcontractor</option>
                    <option value="travel">Travel</option>
                    <option value="equipment">Equipment</option>
                    <option value="meals_entertainment">Meals & Entertainment</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Amount ($) *</label>
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(Number(e.target.value))}
                    step="0.01"
                    min="0.01"
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200 font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Receipt Attachment File</label>
                  <input
                    type="text"
                    value={receiptFileName}
                    onChange={(e) => setReceiptFileName(e.target.value)}
                    placeholder="e.g. invoice_aws_oct2026.pdf"
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200 font-mono"
                  />
                </div>
              </div>

              <div className="p-3 bg-slate-950 border border-slate-800 flex items-center gap-2">
                <input
                  type="checkbox"
                  id="billableCheck"
                  checked={isBillable}
                  onChange={(e) => setIsBillable(e.target.checked)}
                  className="rounded-none bg-slate-900 border-slate-700 text-indigo-600 focus:ring-0"
                />
                <label htmlFor="billableCheck" className="text-slate-300 text-xs cursor-pointer">
                  Mark as Billable to Client (Automatically eligible to pull into Client Billing Invoices)
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsSubmitOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-600 hover:bg-amber-500 text-white font-semibold transition-colors shadow-sm"
                >
                  Submit for Approval
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reject Modal */}
      {rejectingExpenseId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-md shadow-2xl p-6 space-y-4">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400" />
              <span>Reject Expense Submission</span>
            </h3>
            <p className="text-xs text-slate-400">
              Please specify the audit reason for rejecting this reimbursement request:
            </p>
            <textarea
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              placeholder="e.g. Receipt itemization missing, or non-approved budget category..."
              rows={3}
              className="w-full bg-slate-950 border border-slate-700 p-2.5 text-xs text-slate-200 focus:outline-none focus:border-rose-500"
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setRejectingExpenseId(null)}
                className="px-4 py-2 text-xs text-slate-400 hover:text-slate-200"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  if (rejectingExpenseId) {
                    rejectExpense(rejectingExpenseId, rejectionReason || 'Manager audit rejected');
                    setRejectingExpenseId(null);
                    setRejectionReason('');
                  }
                }}
                className="px-4 py-2 text-xs bg-rose-600 hover:bg-rose-500 text-white font-semibold"
              >
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
