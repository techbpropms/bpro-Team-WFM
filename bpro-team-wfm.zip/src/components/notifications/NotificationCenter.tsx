import React, { useState, useMemo, useEffect, useRef } from 'react';
import { 
  Bell, 
  CheckCheck, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  X, 
  Calendar, 
  Check, 
  Trash2, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  RefreshCw, 
  Layers, 
  Radio, 
  Download, 
  ArrowUpRight, 
  Filter, 
  Search, 
  ShieldAlert,
  Flame,
  Zap,
  Building,
  User,
  ExternalLink
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { SystemNotification, NotificationCategory, NotificationUrgency, Task, Invoice } from '../../types';
import { soundManager } from '../../utils/sound';
import { generateInvoicePdf } from '../../services/pdfGenerator';
import { triggerConfetti } from '../../utils/confetti';
import { Tooltip } from '../common/Tooltip';

interface NotificationCenterProps {
  isOpen?: boolean;
  onClose?: () => void;
  mode?: 'drawer' | 'page' | 'dropdown';
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({
  isOpen = true,
  onClose,
  mode = 'drawer',
}) => {
  const {
    tasks,
    invoices,
    clients,
    notifications,
    markNotificationRead,
    clearAllNotifications,
    setActiveTab,
    updateTaskStatus,
    pushTaskDeadline,
    updateInvoice,
    formatCurrency,
    isFirestoreConnected,
    syncWithFirestore,
    currentUser,
    isSuperAdmin,
  } = useApp();

  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [soundMuted, setSoundMuted] = useState(() => soundManager.getMuted());
  const [desktopEnabled, setDesktopEnabled] = useState(false);
  const [isSimulating, setIsSimulating] = useState(false);
  const [lastSyncedTime, setLastSyncedTime] = useState<string>(() => new Date().toLocaleTimeString());
  
  // Reschedule deadline quick-action state
  const [rescheduleTask, setRescheduleTask] = useState<Task | null>(null);
  const [newDueDate, setNewDueDate] = useState('');
  const [rescheduleReason, setRescheduleReason] = useState('');

  // Handle sound toggle
  const toggleSound = () => {
    const muted = soundManager.toggleMute();
    setSoundMuted(muted);
  };

  // Browser desktop notification permission check
  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setDesktopEnabled(Notification.permission === 'granted');
    }
  }, []);

  const requestDesktopPermission = async () => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      const perm = await Notification.requestPermission();
      setDesktopEnabled(perm === 'granted');
      if (perm === 'granted') {
        new Notification('Bpro PMS Real-time Notifications Enabled', {
          body: 'You will receive instant alerts for deadlines, tasks, and invoice payments.',
          icon: '/favicon.ico',
        });
      }
    }
  };

  // Update sync timestamp when firestore syncs or tasks/invoices change
  useEffect(() => {
    setLastSyncedTime(new Date().toLocaleTimeString());
  }, [tasks, invoices, notifications]);

  // Real-time calculated notifications derived from live Firebase data
  const realTimeDerivedNotifications = useMemo(() => {
    const alerts: SystemNotification[] = [];
    const now = new Date();
    const todayStr = now.toISOString().substring(0, 10);
    const todayTime = new Date(todayStr).getTime();

    // 1. APPROACHING DEADLINES & OVERDUE TASKS
    tasks.forEach(t => {
      if (t.status === 'completed') return;

      const dueTime = new Date(t.dueDate).getTime();
      const diffDays = Math.round((dueTime - todayTime) / (1000 * 60 * 60 * 24));
      const client = clients.find(c => c.id === t.clientId);

      if (diffDays < 0) {
        // Overdue deadline
        alerts.push({
          id: `derived_overdue_${t.id}`,
          title: `Deadline Passed: ${t.title}`,
          message: `Overdue by ${Math.abs(diffDays)} day(s). Original target was ${t.dueDate}. Urgency: ${t.priority.toUpperCase()}.`,
          type: 'alert',
          category: 'deadline',
          urgency: 'critical',
          entityId: t.id,
          source: 'firebase',
          timestamp: t.updatedAt || t.createdAt,
          isRead: false,
          linkAction: 'tasks',
          meta: {
            dueDate: t.dueDate,
            taskTitle: t.title,
            clientName: client?.company || client?.name || 'Corporate Client',
            daysRemaining: diffDays,
          },
        });
      } else if (diffDays === 0) {
        // Due today
        alerts.push({
          id: `derived_today_${t.id}`,
          title: `Deadline Today: ${t.title}`,
          message: `Due by end-of-day today! Sprint work in progress. Assigned team: ${t.assignedToId}.`,
          type: 'alert',
          category: 'deadline',
          urgency: 'critical',
          entityId: t.id,
          source: 'firebase',
          timestamp: t.updatedAt || t.createdAt,
          isRead: false,
          linkAction: 'tasks',
          meta: {
            dueDate: t.dueDate,
            taskTitle: t.title,
            clientName: client?.company || client?.name || 'Corporate Client',
            daysRemaining: 0,
          },
        });
      } else if (diffDays <= 3) {
        // Approaching deadline within 72 hours
        alerts.push({
          id: `derived_approaching_${t.id}`,
          title: `Approaching Deadline: ${t.title}`,
          message: `Due in ${diffDays} day(s) on ${t.dueDate}. Deliverable review pending.`,
          type: 'warning',
          category: 'deadline',
          urgency: diffDays === 1 ? 'high' : 'medium',
          entityId: t.id,
          source: 'firebase',
          timestamp: t.updatedAt || t.createdAt,
          isRead: false,
          linkAction: 'tasks',
          meta: {
            dueDate: t.dueDate,
            taskTitle: t.title,
            clientName: client?.company || client?.name || 'Corporate Client',
            daysRemaining: diffDays,
          },
        });
      }

      // Deadline amendments
      if (t.amendments && t.amendments.length > 0) {
        const latestAmend = t.amendments[0];
        alerts.push({
          id: `derived_amend_${latestAmend.id}`,
          title: `Deadline Rescheduled: ${t.title}`,
          message: `Pushed from ${latestAmend.previousDeadline} to ${latestAmend.newDeadline} by ${latestAmend.amendedByName}: "${latestAmend.reason}"`,
          type: 'warning',
          category: 'deadline',
          urgency: 'medium',
          entityId: t.id,
          source: 'firebase',
          timestamp: latestAmend.timestamp,
          isRead: false,
          linkAction: 'tasks',
          meta: {
            dueDate: latestAmend.newDeadline,
            taskTitle: t.title,
            clientName: client?.company || client?.name,
          },
        });
      }
    });

    // 2. NEW TASKS (Created recently or high-priority items)
    tasks.forEach(t => {
      const client = clients.find(c => c.id === t.clientId);
      if (t.priority === 'urgent' || t.priority === 'high') {
        alerts.push({
          id: `derived_task_prio_${t.id}`,
          title: `High Priority Sprint Item: ${t.title}`,
          message: `${t.priority.toUpperCase()} priority task in ${t.status.toUpperCase()}. Est: ${t.estimatedHours}h. Client: ${client?.company || client?.name || 'Bpro Client'}`,
          type: t.priority === 'urgent' ? 'alert' : 'info',
          category: 'task',
          urgency: t.priority === 'urgent' ? 'critical' : 'high',
          entityId: t.id,
          source: 'firebase',
          timestamp: t.createdAt,
          isRead: false,
          linkAction: 'tasks',
          meta: {
            taskTitle: t.title,
            clientName: client?.company || client?.name,
            dueDate: t.dueDate,
          },
        });
      }
    });

    // 3. INVOICE PAYMENTS & OVERDUE INVOICES
    invoices.forEach(inv => {
      const client = clients.find(c => c.id === inv.clientId);
      if (inv.status === 'paid') {
        alerts.push({
          id: `derived_inv_paid_${inv.id}`,
          title: `Invoice Payment Settled: #${inv.invoiceNumber}`,
          message: `Received ₹${Math.round(inv.total).toLocaleString('en-IN')} from ${client?.company || client?.name || 'Enterprise Client'} in full.`,
          type: 'success',
          category: 'invoice',
          urgency: 'normal',
          entityId: inv.id,
          source: 'firebase',
          timestamp: inv.paidAt || inv.issueDate,
          isRead: false,
          linkAction: 'invoices',
          meta: {
            amount: inv.total,
            invoiceNumber: inv.invoiceNumber,
            clientName: client?.company || client?.name,
          },
        });
      } else if (inv.status === 'overdue' || (new Date(inv.dueDate).getTime() < todayTime && inv.status !== 'cancelled')) {
        alerts.push({
          id: `derived_inv_overdue_${inv.id}`,
          title: `Invoice Payment Overdue: #${inv.invoiceNumber}`,
          message: `₹${Math.round(inv.total).toLocaleString('en-IN')} due on ${inv.dueDate} is pending settlement from ${client?.company || client?.name || 'Client'}.`,
          type: 'alert',
          category: 'invoice',
          urgency: 'critical',
          entityId: inv.id,
          source: 'firebase',
          timestamp: inv.dueDate,
          isRead: false,
          linkAction: 'invoices',
          meta: {
            amount: inv.total,
            invoiceNumber: inv.invoiceNumber,
            clientName: client?.company || client?.name,
            dueDate: inv.dueDate,
          },
        });
      } else if (inv.status === 'sent') {
        alerts.push({
          id: `derived_inv_sent_${inv.id}`,
          title: `Invoice Awaiting Settlement: #${inv.invoiceNumber}`,
          message: `Issued ₹${Math.round(inv.total).toLocaleString('en-IN')}, payment terms: ${inv.paymentTerms}. Due on ${inv.dueDate}.`,
          type: 'info',
          category: 'invoice',
          urgency: 'medium',
          entityId: inv.id,
          source: 'firebase',
          timestamp: inv.issueDate,
          isRead: false,
          linkAction: 'invoices',
          meta: {
            amount: inv.total,
            invoiceNumber: inv.invoiceNumber,
            clientName: client?.company || client?.name,
            dueDate: inv.dueDate,
          },
        });
      }
    });

    return alerts;
  }, [tasks, invoices, clients]);

  // Combine standard notifications with real-time derived alerts (avoiding duplicate IDs)
  const allNotifications = useMemo(() => {
    const map = new Map<string, SystemNotification>();

    // Add stored notifications
    notifications.forEach(n => {
      // Auto-assign category if missing based on title/linkAction
      let cat: NotificationCategory = n.category || 'system';
      if (!n.category) {
        const lower = (n.title + ' ' + n.message).toLowerCase();
        if (lower.includes('deadline') || lower.includes('due') || lower.includes('postpone')) cat = 'deadline';
        else if (lower.includes('task') || lower.includes('sprint')) cat = 'task';
        else if (lower.includes('invoice') || lower.includes('payment') || lower.includes('settled')) cat = 'invoice';
      }
      map.set(n.id, { ...n, category: cat });
    });

    // Merge real-time derived alerts
    realTimeDerivedNotifications.forEach(a => {
      if (!map.has(a.id)) {
        map.set(a.id, a);
      }
    });

    // Sort: unread first, then by timestamp descending
    return Array.from(map.values()).sort((a, b) => {
      if (a.isRead !== b.isRead) return a.isRead ? 1 : -1;
      return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
    });
  }, [notifications, realTimeDerivedNotifications]);

  // Counts per category
  const counts = useMemo(() => {
    const total = allNotifications.length;
    const unread = allNotifications.filter(n => !n.isRead).length;
    const deadline = allNotifications.filter(n => n.category === 'deadline').length;
    const task = allNotifications.filter(n => n.category === 'task').length;
    const invoice = allNotifications.filter(n => n.category === 'invoice').length;
    return { total, unread, deadline, task, invoice };
  }, [allNotifications]);

  // Filtered list
  const filteredNotifications = useMemo(() => {
    return allNotifications.filter(n => {
      // Category filter
      if (activeCategory === 'unread' && n.isRead) return false;
      if (activeCategory === 'deadline' && n.category !== 'deadline') return false;
      if (activeCategory === 'task' && n.category !== 'task') return false;
      if (activeCategory === 'invoice' && n.category !== 'invoice') return false;

      // Search query filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const text = `${n.title} ${n.message} ${n.category || ''} ${n.meta?.taskTitle || ''} ${n.meta?.clientName || ''} ${n.meta?.invoiceNumber || ''}`.toLowerCase();
        return text.includes(q);
      }

      return true;
    });
  }, [allNotifications, activeCategory, searchQuery]);

  // Handle Mark Task Completed from alert card
  const handleCompleteTask = (taskId: string) => {
    updateTaskStatus(taskId, 'completed');
    soundManager.playChime('task');
    triggerConfetti(0.5, 0.4);
  };

  // Open reschedule dialog
  const handleStartReschedule = (taskId: string) => {
    const t = tasks.find(item => item.id === taskId);
    if (t) {
      setRescheduleTask(t);
      // Pre-fill tomorrow
      const d = new Date(t.dueDate);
      d.setDate(d.getDate() + 1);
      setNewDueDate(d.toISOString().substring(0, 10));
      setRescheduleReason('');
    }
  };

  const handleConfirmReschedule = () => {
    if (rescheduleTask && newDueDate && rescheduleReason.trim()) {
      pushTaskDeadline(rescheduleTask.id, newDueDate, rescheduleReason.trim());
      soundManager.playChime('deadline');
      setRescheduleTask(null);
    }
  };

  // Handle Invoice Mark as Paid
  const handleMarkInvoicePaid = (invoiceId: string) => {
    updateInvoice(invoiceId, { status: 'paid', paidAt: new Date().toISOString() });
    soundManager.playChime('invoice');
    triggerConfetti(0.5, 0.4);
  };

  // Handle Download Invoice PDF
  const handleDownloadInvoicePdf = (invoiceId: string) => {
    const inv = invoices.find(i => i.id === invoiceId);
    const client = clients.find(c => c.id === inv?.clientId);
    if (inv && client) {
      generateInvoicePdf(inv, client);
      soundManager.playChime('default');
    }
  };

  // Simulation test event generator (for live testing approaching deadlines, new tasks, invoice payments)
  const handleSimulateEvent = async (type: 'deadline' | 'task' | 'invoice') => {
    setIsSimulating(true);
    try {
      if (type === 'deadline') {
        soundManager.playChime('deadline');
        const randomTask = tasks[0] || { id: 'test_task', title: 'High-throughput Gateway' };
        setRescheduleTask(randomTask);
        const nextDay = new Date();
        nextDay.setDate(nextDay.getDate() + 2);
        setNewDueDate(nextDay.toISOString().substring(0, 10));
        setRescheduleReason('Simulated live Firebase deadline alert');
      } else if (type === 'task') {
        soundManager.playChime('task');
        triggerConfetti(0.3, 0.3);
      } else if (type === 'invoice') {
        soundManager.playChime('invoice');
        triggerConfetti(0.5, 0.4);
      }
    } finally {
      setTimeout(() => setIsSimulating(false), 500);
    }
  };

  if (!isOpen && mode === 'drawer') return null;

  const content = (
    <div className={`flex flex-col h-full bg-slate-950 text-slate-100 ${mode === 'page' ? 'border border-slate-800' : ''}`}>
      {/* Header */}
      <div className="p-4 sm:p-5 bg-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-indigo-600/20 border border-indigo-500/40 text-indigo-400">
            <Bell className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-100 tracking-wide font-sans">
                Notification Center
              </h2>
              {/* Live Firebase badge */}
              <div className="flex items-center gap-1.5 px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/30 text-[10px] font-mono text-emerald-400">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>{isFirestoreConnected ? 'FIREBASE LIVE' : 'SYNCED LOCAL'}</span>
              </div>
            </div>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              Real-time updates for approaching deadlines, sprint tasks & invoice payments
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Audio Chime Mute/Unmute */}
          <Tooltip content={soundMuted ? 'Unmute Audio Chimes' : 'Mute Audio Chimes'}>
            <button
              onClick={toggleSound}
              className={`p-2 border transition-colors ${
                soundMuted 
                  ? 'bg-slate-800 border-slate-700 text-slate-500 hover:text-slate-300' 
                  : 'bg-indigo-600/20 border-indigo-500/40 text-indigo-300 hover:bg-indigo-600/30'
              }`}
              aria-label="Toggle notification sounds"
            >
              {soundMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
          </Tooltip>

          {/* Cloud Firestore Sync button */}
          <Tooltip content="Sync with Firebase Cloud Firestore">
            <button
              onClick={() => syncWithFirestore()}
              className="p-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 transition-colors"
              aria-label="Sync with Firebase"
            >
              <RefreshCw className="w-4 h-4 text-emerald-400" />
            </button>
          </Tooltip>

          {/* Close button in drawer mode */}
          {mode === 'drawer' && onClose && (
            <button
              onClick={onClose}
              className="p-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-400 hover:text-slate-100 transition-colors"
              aria-label="Close notification center"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Control Bar: Categories & Search */}
      <div className="p-3 sm:p-4 bg-slate-900/60 border-b border-slate-800/80 space-y-3 shrink-0">
        {/* Category Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs font-mono scrollbar-none">
          <button
            onClick={() => setActiveCategory('all')}
            className={`px-3 py-1.5 border transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeCategory === 'all'
                ? 'bg-indigo-600 text-white border-indigo-500 font-bold shadow-sm'
                : 'bg-slate-900 text-slate-400 hover:text-slate-200 border-slate-800 hover:bg-slate-850'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>ALL</span>
            <span className="px-1.5 py-0.2 bg-slate-950/40 text-[10px] rounded">
              {counts.total}
            </span>
          </button>

          <button
            onClick={() => setActiveCategory('deadline')}
            className={`px-3 py-1.5 border transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeCategory === 'deadline'
                ? 'bg-amber-600 text-white border-amber-500 font-bold shadow-sm'
                : 'bg-slate-900 text-amber-400/90 hover:text-amber-300 border-slate-800 hover:bg-slate-850'
            }`}
          >
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span>DEADLINES</span>
            <span className="px-1.5 py-0.2 bg-amber-950/60 text-amber-300 text-[10px] rounded">
              {counts.deadline}
            </span>
          </button>

          <button
            onClick={() => setActiveCategory('task')}
            className={`px-3 py-1.5 border transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeCategory === 'task'
                ? 'bg-sky-600 text-white border-sky-500 font-bold shadow-sm'
                : 'bg-slate-900 text-sky-400/90 hover:text-sky-300 border-slate-800 hover:bg-slate-850'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-sky-400" />
            <span>NEW TASKS</span>
            <span className="px-1.5 py-0.2 bg-sky-950/60 text-sky-300 text-[10px] rounded">
              {counts.task}
            </span>
          </button>

          <button
            onClick={() => setActiveCategory('invoice')}
            className={`px-3 py-1.5 border transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeCategory === 'invoice'
                ? 'bg-emerald-600 text-white border-emerald-500 font-bold shadow-sm'
                : 'bg-slate-900 text-emerald-400/90 hover:text-emerald-300 border-slate-800 hover:bg-slate-850'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>INVOICES</span>
            <span className="px-1.5 py-0.2 bg-emerald-950/60 text-emerald-300 text-[10px] rounded">
              {counts.invoice}
            </span>
          </button>

          <button
            onClick={() => setActiveCategory('unread')}
            className={`px-3 py-1.5 border transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeCategory === 'unread'
                ? 'bg-indigo-600/30 text-indigo-300 border-indigo-500 font-bold shadow-sm'
                : 'bg-slate-900 text-slate-400 hover:text-slate-200 border-slate-800 hover:bg-slate-850'
            }`}
          >
            <span>UNREAD</span>
            {counts.unread > 0 && (
              <span className="px-1.5 py-0.2 bg-indigo-500 text-white text-[10px] font-bold">
                {counts.unread}
              </span>
            )}
          </button>
        </div>

        {/* Search & Action Bar */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search alerts by task, invoice #, client, or keyword..."
              className="w-full pl-9 pr-3 py-1.5 bg-slate-950 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 font-sans"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 text-xs"
              >
                ×
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
            {/* Quick simulation buttons for real-time testing */}
            <div className="flex items-center gap-1 bg-slate-950 border border-slate-800 p-0.5">
              <span className="px-1.5 text-[9px] font-mono text-slate-500 uppercase">Test Stream:</span>
              <button
                onClick={() => handleSimulateEvent('deadline')}
                className="px-2 py-1 text-[10px] font-mono bg-amber-500/10 text-amber-400 hover:bg-amber-500/20 border border-amber-500/30 transition-colors"
                title="Test approaching deadline trigger"
              >
                +Deadline
              </button>
              <button
                onClick={() => handleSimulateEvent('task')}
                className="px-2 py-1 text-[10px] font-mono bg-sky-500/10 text-sky-400 hover:bg-sky-500/20 border border-sky-500/30 transition-colors"
                title="Test new sprint task trigger"
              >
                +Task
              </button>
              <button
                onClick={() => handleSimulateEvent('invoice')}
                className="px-2 py-1 text-[10px] font-mono bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border border-emerald-500/30 transition-colors"
                title="Test invoice payment received trigger"
              >
                +Payment
              </button>
            </div>

            {/* Clear all */}
            <button
              onClick={clearAllNotifications}
              className="px-2.5 py-1.5 text-xs text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-800 transition-colors flex items-center gap-1"
            >
              <CheckCheck className="w-3.5 h-3.5 text-slate-500" />
              <span className="text-[11px] font-mono">Clear Read</span>
            </button>
          </div>
        </div>

        {/* Live status bar */}
        <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 border-t border-slate-800/40 pt-2">
          <div className="flex items-center gap-2">
            <Radio className="w-3 h-3 text-emerald-400 animate-pulse" />
            <span>Listening to Firestore: <strong className="text-slate-400">tasks</strong>, <strong className="text-slate-400">invoices</strong>, <strong className="text-slate-400">notifications</strong></span>
          </div>
          <div>Last synced: <span className="text-slate-400">{lastSyncedTime}</span></div>
        </div>
      </div>

      {/* Main List */}
      <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-2.5 divide-y divide-slate-850/40">
        {filteredNotifications.length === 0 ? (
          <div className="h-64 flex flex-col items-center justify-center text-center p-6 bg-slate-900/30 border border-dashed border-slate-800 my-4">
            <div className="w-12 h-12 rounded-full bg-slate-800/80 flex items-center justify-center text-slate-500 mb-3">
              <CheckCheck className="w-6 h-6 text-emerald-400" />
            </div>
            <h3 className="text-sm font-semibold text-slate-300">All Clear! No Pending Alerts</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm">
              {activeCategory !== 'all' 
                ? `No active notifications in the "${activeCategory}" filter category.`
                : 'All deadlines are on schedule, invoices settled, and sprint deliverables synced with Firebase.'}
            </p>
            <div className="mt-4 flex items-center gap-2">
              <button
                onClick={() => handleSimulateEvent('deadline')}
                className="px-3 py-1.5 text-xs font-mono bg-indigo-600/20 text-indigo-300 hover:bg-indigo-600/30 border border-indigo-500/40"
              >
                Simulate Live Event
              </button>
            </div>
          </div>
        ) : (
          filteredNotifications.map((notif) => {
            const isCritical = notif.urgency === 'critical' || notif.type === 'alert';
            const isDeadline = notif.category === 'deadline';
            const isInvoice = notif.category === 'invoice';
            const isTask = notif.category === 'task';

            let categoryColor = 'text-slate-400 bg-slate-800 border-slate-700';
            let iconComponent = <Bell className="w-4 h-4 text-indigo-400" />;

            if (isDeadline) {
              categoryColor = isCritical 
                ? 'text-rose-400 bg-rose-500/10 border-rose-500/30' 
                : 'text-amber-400 bg-amber-500/10 border-amber-500/30';
              iconComponent = isCritical 
                ? <AlertTriangle className="w-4 h-4 text-rose-400" />
                : <Clock className="w-4 h-4 text-amber-400" />;
            } else if (isInvoice) {
              categoryColor = notif.type === 'success'
                ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30'
                : 'text-purple-400 bg-purple-500/10 border-purple-500/30';
              iconComponent = notif.type === 'success'
                ? <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                : <Download className="w-4 h-4 text-purple-400" />;
            } else if (isTask) {
              categoryColor = 'text-sky-400 bg-sky-500/10 border-sky-500/30';
              iconComponent = <Zap className="w-4 h-4 text-sky-400" />;
            }

            return (
              <div
                key={notif.id}
                className={`p-3.5 sm:p-4 border transition-all ${
                  notif.isRead 
                    ? 'bg-slate-900/40 border-slate-850 opacity-75' 
                    : isCritical
                      ? 'bg-rose-950/20 border-rose-500/40 shadow-sm'
                      : 'bg-slate-900 border-slate-800 shadow-sm'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    {/* Category Icon Badge */}
                    <div className={`p-2 border shrink-0 mt-0.5 ${categoryColor}`}>
                      {iconComponent}
                    </div>

                    <div className="flex-1 min-w-0">
                      {/* Meta badges & timestamp */}
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <span className={`px-1.5 py-0.5 text-[9px] font-mono uppercase font-bold tracking-wider border ${categoryColor}`}>
                          {notif.category || 'SYSTEM'}
                        </span>

                        {notif.urgency && (
                          <span className={`px-1.5 py-0.5 text-[9px] font-mono uppercase font-semibold ${
                            notif.urgency === 'critical' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40' :
                            notif.urgency === 'high' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' :
                            'bg-slate-800 text-slate-300'
                          }`}>
                            {notif.urgency}
                          </span>
                        )}

                        {notif.source === 'firebase' && (
                          <span className="px-1.5 py-0.5 text-[9px] font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/20">
                            FIREBASE
                          </span>
                        )}

                        <span className="text-[10px] text-slate-500 font-mono ml-auto">
                          {new Date(notif.timestamp).toLocaleString([], {
                            month: 'short',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </span>
                      </div>

                      {/* Title */}
                      <h4 className="text-xs sm:text-sm font-semibold text-slate-100 leading-snug">
                        {notif.title}
                      </h4>

                      {/* Body Message */}
                      <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                        {notif.message}
                      </p>

                      {/* Attached Details Pill (e.g. Due Date, Client, Amount) */}
                      {notif.meta && (
                        <div className="flex flex-wrap items-center gap-3 mt-2 text-[11px] font-mono text-slate-400 bg-slate-950/60 p-2 border border-slate-850">
                          {notif.meta.clientName && (
                            <div className="flex items-center gap-1 text-slate-300">
                              <Building className="w-3 h-3 text-slate-500" />
                              <span>{notif.meta.clientName}</span>
                            </div>
                          )}

                          {notif.meta.dueDate && (
                            <div className="flex items-center gap-1 text-amber-300">
                              <Calendar className="w-3 h-3 text-amber-400" />
                              <span>Due: {notif.meta.dueDate}</span>
                              {notif.meta.daysRemaining !== undefined && (
                                <span className={notif.meta.daysRemaining < 0 ? 'text-rose-400 font-bold' : 'text-amber-400'}>
                                  ({notif.meta.daysRemaining < 0 ? `${Math.abs(notif.meta.daysRemaining)}d overdue` : `${notif.meta.daysRemaining}d left`})
                                </span>
                              )}
                            </div>
                          )}

                          {notif.meta.amount !== undefined && (
                            <div className="flex items-center gap-1 text-emerald-300 font-bold">
                              <span>Settlement: ₹{Math.round(notif.meta.amount).toLocaleString('en-IN')}</span>
                            </div>
                          )}
                        </div>
                      )}

                      {/* Action Buttons Bar */}
                      <div className="flex flex-wrap items-center gap-2 mt-3 pt-2 border-t border-slate-800/60">
                        {/* Target Navigation */}
                        {notif.linkAction && (
                          <button
                            onClick={() => {
                              markNotificationRead(notif.id);
                              setActiveTab(notif.linkAction!);
                              if (mode === 'drawer' && onClose) onClose();
                            }}
                            className="px-2.5 py-1 text-xs font-mono bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center gap-1.5 transition-colors"
                          >
                            <span>Open in {notif.linkAction.toUpperCase()}</span>
                            <ArrowUpRight className="w-3 h-3 text-slate-400" />
                          </button>
                        )}

                        {/* Approaching Deadline Specific Actions */}
                        {isDeadline && notif.entityId && (
                          <>
                            <button
                              onClick={() => handleCompleteTask(notif.entityId!)}
                              className="px-2.5 py-1 text-xs font-mono bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 flex items-center gap-1 transition-colors"
                            >
                              <Check className="w-3 h-3" />
                              <span>Mark Done</span>
                            </button>

                            <button
                              onClick={() => handleStartReschedule(notif.entityId!)}
                              className="px-2.5 py-1 text-xs font-mono bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-500/40 flex items-center gap-1 transition-colors"
                            >
                              <Calendar className="w-3 h-3" />
                              <span>Reschedule</span>
                            </button>
                          </>
                        )}

                        {/* Invoice Specific Actions */}
                        {isInvoice && notif.entityId && (
                          <>
                            <button
                              onClick={() => handleDownloadInvoicePdf(notif.entityId!)}
                              className="px-2.5 py-1 text-xs font-mono bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/40 flex items-center gap-1 transition-colors"
                            >
                              <Download className="w-3 h-3" />
                              <span>PDF Invoice</span>
                            </button>

                            {notif.type !== 'success' && (
                              <button
                                onClick={() => handleMarkInvoicePaid(notif.entityId!)}
                                className="px-2.5 py-1 text-xs font-mono bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 flex items-center gap-1 transition-colors"
                              >
                                <CheckCircle2 className="w-3 h-3" />
                                <span>Record Payment</span>
                              </button>
                            )}
                          </>
                        )}

                        {/* Mark Read Toggle */}
                        {!notif.isRead ? (
                          <button
                            onClick={() => markNotificationRead(notif.id)}
                            className="px-2 py-1 text-[11px] font-mono text-slate-400 hover:text-slate-200 transition-colors ml-auto"
                          >
                            Mark Read
                          </button>
                        ) : (
                          <span className="text-[10px] font-mono text-slate-600 ml-auto flex items-center gap-1">
                            <CheckCheck className="w-3 h-3 text-slate-600" />
                            Read
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Footer Banner */}
      <div className="p-3 bg-slate-950 border-t border-slate-800 flex flex-wrap items-center justify-between text-xs text-slate-400 gap-2 shrink-0">
        <div className="flex items-center gap-2 text-[11px] font-mono">
          <span className="text-slate-500">Bpro PMS Real-time Engine</span>
          <span className="text-slate-600">•</span>
          <span className="text-slate-400">{filteredNotifications.length} alerts loaded</span>
        </div>

        <div className="flex items-center gap-3">
          {!desktopEnabled ? (
            <button
              onClick={requestDesktopPermission}
              className="text-[11px] text-indigo-400 hover:text-indigo-300 font-mono underline"
            >
              Enable Browser Notifications
            </button>
          ) : (
            <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              Browser Notifications Enabled
            </span>
          )}

          {mode === 'drawer' && (
            <button
              onClick={() => {
                setActiveTab('notifications');
                if (onClose) onClose();
              }}
              className="text-[11px] text-slate-300 hover:text-white font-mono flex items-center gap-1"
            >
              <span>Full View</span>
              <ExternalLink className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>

      {/* Modal: Quick Reschedule Deadline with Reason */}
      {rescheduleTask && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 border border-slate-700 shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-bold text-slate-100">
                  Reschedule Task Deadline
                </h3>
              </div>
              <button
                onClick={() => setRescheduleTask(null)}
                className="text-slate-400 hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <div className="text-xs font-semibold text-slate-200">{rescheduleTask.title}</div>
              <div className="text-[11px] font-mono text-slate-400 mt-0.5">
                Current Due Date: <span className="text-amber-300">{rescheduleTask.dueDate}</span>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-mono text-slate-300 mb-1">
                  New Due Date Target *
                </label>
                <input
                  type="date"
                  value={newDueDate}
                  onChange={(e) => setNewDueDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 text-xs text-slate-100 focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-300 mb-1">
                  Mandatory Extension Reason *
                </label>
                <textarea
                  value={rescheduleReason}
                  onChange={(e) => setRescheduleReason(e.target.value)}
                  placeholder="e.g. Awaiting client stakeholder approval / upstream API rate limit resolved..."
                  rows={3}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 text-xs text-slate-100 focus:outline-none focus:border-amber-500 font-sans"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setRescheduleTask(null)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 bg-slate-800"
              >
                Cancel
              </button>
              <button
                disabled={!newDueDate || !rescheduleReason.trim()}
                onClick={handleConfirmReschedule}
                className="px-4 py-1.5 text-xs font-mono font-bold bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-slate-950 flex items-center gap-1.5"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Save New Deadline</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  if (mode === 'drawer') {
    return (
      <div className="fixed inset-0 z-50 overflow-hidden">
        {/* Backdrop */}
        <div 
          onClick={onClose}
          className="absolute inset-0 bg-slate-950/70 backdrop-blur-xs transition-opacity" 
        />
        <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
          <div className="w-screen max-w-md sm:max-w-lg shadow-2xl border-l border-slate-800">
            {content}
          </div>
        </div>
      </div>
    );
  }

  return content;
};
