import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Trophy, 
  Award, 
  Crown, 
  Flame, 
  Zap, 
  Star, 
  ShieldCheck, 
  IndianRupee, 
  CheckCircle2, 
  Download, 
  Sparkles, 
  Heart,
  ChevronRight,
  TrendingUp,
  X,
  Plus
} from 'lucide-react';
import { exportToCsv } from '../../services/csvExport';
import { Tooltip } from '../common/Tooltip';

export const GamificationManager: React.FC = () => {
  const { 
    gamificationProfiles, 
    allTeamMembers, 
    currentUser, 
    isSuperAdmin, 
    awardKudos, 
    triggerCelebration,
    formatCurrency
  } = useApp();

  const [isKudosModalOpen, setIsKudosModalOpen] = useState(false);
  const [selectedToUserId, setSelectedToUserId] = useState(allTeamMembers[1]?.id || '');
  const [kudosReason, setKudosReason] = useState('');
  const [kudosStars, setKudosStars] = useState(5);

  const handleSendKudos = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedToUserId || !kudosReason.trim()) return;

    awardKudos(selectedToUserId, kudosReason.trim(), kudosStars);
    setKudosReason('');
    setKudosStars(5);
    setIsKudosModalOpen(false);
  };

  const handleExportGamificationCsv = () => {
    const rows = allTeamMembers.map((member, index) => {
      const profile = gamificationProfiles.find(p => p.userId === member.id) || {
        currentXp: 300,
        level: 1,
        levelTitle: 'Contributor',
        streakDays: 3,
        achievements: [],
        kudosReceived: [],
      };

      return {
        'Rank': index + 1,
        'Member Name': member.name,
        'Email': member.email,
        'Role': member.role,
        'Current Level': profile.level,
        'Level Title': profile.levelTitle,
        'Total XP': profile.currentXp,
        'Active Streak Days': profile.streakDays,
        'Total Badges': profile.achievements.length,
        'Kudos Received Count': profile.kudosReceived.length,
      };
    });

    exportToCsv(`Bpro_Team_Performance_Gamification_${new Date().toISOString().substring(0, 10)}`, rows);
  };

  // Sort team by XP desc
  const rankedMembers = allTeamMembers.map(m => {
    const profile = gamificationProfiles.find(p => p.userId === m.id) || {
      userId: m.id,
      currentXp: 250,
      level: 1,
      levelTitle: 'Contributor',
      streakDays: 3,
      achievements: [],
      kudosReceived: [],
    };
    return { member: m, profile };
  }).sort((a, b) => b.profile.currentXp - a.profile.currentXp);

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              <span className="p-1 bg-amber-500/10 border border-amber-500/30 text-amber-400">
                <Trophy className="w-4 h-4" />
              </span>
              <span>Performance Dynamics & Gamification Hub</span>
            </h1>
            <span className="text-[10px] font-mono font-semibold px-2 py-0.5 bg-emerald-950/80 text-emerald-300 border border-emerald-700/60">
              MERIT & RECOGNITION
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Motivate teams through transparent milestone recognition, continuous streak badges, level progressions, and peer Kudos.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <Tooltip content="Export team performance & gamification matrix to CSV">
            <button
              onClick={handleExportGamificationCsv}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span>Export CSV</span>
            </button>
          </Tooltip>

          <Tooltip content="Recognize a colleague with bonus stars & XP" shortcut="Alt+K">
            <button
              onClick={() => setIsKudosModalOpen(true)}
              className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-lg shadow-indigo-950/40"
            >
              <Heart className="w-3.5 h-3.5 text-rose-300 fill-rose-300/30" />
              <span>Award Kudos</span>
            </button>
          </Tooltip>

          <Tooltip content="Trigger test celebration fireworks">
            <button
              onClick={triggerCelebration}
              className="p-1.5 bg-slate-900 hover:bg-slate-800 text-amber-400 border border-slate-800 transition-colors"
              title="Test Confetti"
            >
              <Sparkles className="w-4 h-4" />
            </button>
          </Tooltip>
        </div>
      </div>

      {/* Top Gamification Summary Banner */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Current User Card */}
        {(() => {
          const userProfile = gamificationProfiles.find(p => p.userId === currentUser.id) || {
            currentXp: 1850,
            level: 5,
            levelTitle: 'Executive Chairman & Super Admin',
            streakDays: 24,
            achievements: [],
            kudosReceived: [],
          };
          const nextLevelXp = userProfile.level * 300;
          const prevLevelXp = (userProfile.level - 1) * 300;
          const progressInLevel = Math.min(100, Math.round(((userProfile.currentXp - prevLevelXp) / (nextLevelXp - prevLevelXp)) * 100));

          return (
            <div className="md:col-span-2 p-5 bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-950 border border-indigo-500/30 shadow-xl space-y-3 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4 opacity-10">
                <Crown className="w-24 h-24 text-indigo-400" />
              </div>
              <div className="flex items-center gap-3">
                <img
                  src={currentUser.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}
                  alt={currentUser.name}
                  className="w-12 h-12 rounded-full border-2 border-indigo-400 object-cover"
                />
                <div>
                  <div className="text-xs text-indigo-400 font-mono font-semibold uppercase tracking-wider">
                    Your Tier & Standing
                  </div>
                  <div className="text-sm font-bold text-slate-100 flex items-center gap-2">
                    <span>{currentUser.name}</span>
                    <span className="px-2 py-0.5 text-[10px] bg-indigo-600/30 text-indigo-300 border border-indigo-500/50 font-mono font-bold">
                      LVL {userProfile.level}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 font-medium">{userProfile.levelTitle}</div>
                </div>
              </div>

              {/* XP Progress Bar */}
              <div className="space-y-1 pt-1">
                <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
                  <span className="text-indigo-300 font-semibold">{userProfile.currentXp} Total XP</span>
                  <span>Next Tier: {nextLevelXp} XP ({progressInLevel}%)</span>
                </div>
                <div className="w-full bg-slate-800 h-2 overflow-hidden border border-slate-700/60">
                  <div
                    className="bg-gradient-to-r from-indigo-500 to-emerald-400 h-full transition-all duration-500 shadow-sm"
                    style={{ width: `${progressInLevel}%` }}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between text-[11px] pt-2 border-t border-slate-800 text-slate-400">
                <span className="flex items-center gap-1.5 text-amber-400 font-mono">
                  <Flame className="w-3.5 h-3.5 fill-amber-400" />
                  <span>{userProfile.streakDays} Days Active Streak</span>
                </span>
                <span className="text-slate-300">
                  {userProfile.achievements.length} Badges Earned
                </span>
              </div>
            </div>
          );
        })()}

        {/* Global Streak Metric */}
        <div className="p-4 bg-slate-900 border border-slate-800 space-y-2 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-mono uppercase tracking-wider font-semibold">Longest Team Streak</span>
            <Flame className="w-4 h-4 text-amber-400" />
          </div>
          <div>
            <div className="text-2xl font-bold font-mono text-amber-400">24 Days</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Consecutive on-time delivery</div>
          </div>
          <div className="text-[10px] text-slate-500 font-mono pt-2 border-t border-slate-800">
            Zero SLA breaches logged
          </div>
        </div>

        {/* Total Kudos Given */}
        <div className="p-4 bg-slate-900 border border-slate-800 space-y-2 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-mono uppercase tracking-wider font-semibold">Total Kudos Shared</span>
            <Heart className="w-4 h-4 text-rose-400" />
          </div>
          <div>
            <div className="text-2xl font-bold font-mono text-rose-400">18 Stars</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Cross-team appreciations</div>
          </div>
          <div className="text-[10px] text-slate-500 font-mono pt-2 border-t border-slate-800">
            100% Verified Peer Recognition
          </div>
        </div>
      </div>

      {/* Main Grid: Leaderboard & Kudos Wall */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Leaderboard Table */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-slate-900 border border-slate-800 overflow-hidden">
            <div className="px-5 py-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Crown className="w-4 h-4 text-amber-400" />
                <h2 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                  Organization Merit Leaderboard
                </h2>
              </div>
              <span className="text-[11px] font-mono text-slate-500">Live XP Ranking</span>
            </div>

            <div className="divide-y divide-slate-800/60">
              {rankedMembers.map(({ member, profile }, rankIndex) => {
                const isCurrent = member.id === currentUser.id;
                const medalColors = [
                  'text-amber-400 bg-amber-950/60 border-amber-500/40',
                  'text-slate-300 bg-slate-800/60 border-slate-600/40',
                  'text-amber-600 bg-amber-950/40 border-amber-700/40',
                ];

                return (
                  <div
                    key={member.id}
                    className={`p-3.5 flex items-center justify-between gap-3 transition-colors ${
                      isCurrent ? 'bg-indigo-950/20' : 'hover:bg-slate-850/40'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-6 h-6 flex items-center justify-center font-mono text-xs font-bold border ${
                        rankIndex < 3 ? medalColors[rankIndex] : 'text-slate-500 bg-slate-950 border-slate-800'
                      }`}>
                        {rankIndex + 1}
                      </div>

                      <img
                        src={member.avatarUrl}
                        alt={member.name}
                        className="w-9 h-9 rounded-full object-cover border border-slate-700"
                      />

                      <div>
                        <div className="font-semibold text-xs text-slate-200 flex items-center gap-1.5">
                          <span>{member.name}</span>
                          {member.role === 'super_admin' && (
                            <Crown className="w-3 h-3 text-amber-400" />
                          )}
                          {isCurrent && (
                            <span className="text-[10px] text-indigo-400 font-mono">(You)</span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-400">
                          {profile.levelTitle} &bull; <span className="text-slate-500 font-mono">{member.role.replace('_', ' ')}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 text-right shrink-0">
                      <div className="hidden sm:block">
                        <div className="text-xs font-mono font-bold text-emerald-400 flex items-center gap-1 justify-end">
                          <Flame className="w-3 h-3 fill-amber-400 text-amber-400" />
                          <span>{profile.streakDays}d streak</span>
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono">
                          {profile.achievements.length} badges
                        </div>
                      </div>

                      <div className="text-right font-mono">
                        <div className="text-xs font-bold text-indigo-300">
                          {profile.currentXp.toLocaleString()} XP
                        </div>
                        <div className="text-[10px] text-slate-400">
                          Lvl {profile.level}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Badges Showcase */}
          <div className="bg-slate-900 border border-slate-800 p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h2 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                <Award className="w-4 h-4 text-emerald-400" />
                <span>Enterprise Milestone Badges</span>
              </h2>
              <span className="text-[11px] font-mono text-slate-500">Continuous Assessment</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                { title: 'Governance Titan', desc: 'Approved all organization compliance policies & budget caps', xp: 300, icon: Crown, color: 'text-amber-400 border-amber-500/40 bg-amber-950/20' },
                { title: 'On-Time Maestro', desc: 'Maintained zero overdue tasks across 10 consecutive milestones', xp: 250, icon: CheckCircle2, color: 'text-emerald-400 border-emerald-500/40 bg-emerald-950/20' },
                { title: 'Master Fiscal Guardian', desc: 'Oversaw ₹1.5 Cr+ in GST-compliant invoice settlements', xp: 350, icon: IndianRupee, color: 'text-indigo-400 border-indigo-500/40 bg-indigo-950/20' },
                { title: 'Zero-Defect Hero', desc: 'Engineered high-throughput streaming systems with zero packet loss', xp: 300, icon: ShieldCheck, color: 'text-sky-400 border-sky-500/40 bg-sky-950/20' },
                { title: 'Code Dynamo', desc: 'Completed 15+ high-complexity tasks with unit tests > 95%', xp: 200, icon: Flame, color: 'text-rose-400 border-rose-500/40 bg-rose-950/20' },
                { title: 'API Innovator', desc: 'Connected Google Meet & Slack automated webhook pipelines', xp: 200, icon: Zap, color: 'text-purple-400 border-purple-500/40 bg-purple-950/20' },
              ].map((badge, idx) => {
                const Icon = badge.icon;
                return (
                  <div key={idx} className={`p-3 border flex items-start gap-3 ${badge.color}`}>
                    <div className="p-2 bg-slate-950 border border-slate-800 shrink-0">
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-slate-200">{badge.title}</span>
                        <span className="text-[10px] font-mono font-bold text-slate-400">+{badge.xp} XP</span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">{badge.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Col: Kudos Wall & Peer Appreciations */}
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 overflow-hidden">
            <div className="px-5 py-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Heart className="w-4 h-4 text-rose-400" />
                <h2 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                  Kudos & Peer Recognition Wall
                </h2>
              </div>
              <button
                onClick={() => setIsKudosModalOpen(true)}
                className="text-xs text-indigo-400 hover:text-indigo-300 font-medium"
              >
                + Send
              </button>
            </div>

            <div className="p-4 space-y-3">
              {gamificationProfiles.flatMap(p => p.kudosReceived).length === 0 ? (
                <div className="text-xs text-slate-500 text-center py-4">
                  No kudos sent yet. Be the first to appreciate a team member!
                </div>
              ) : (
                gamificationProfiles
                  .flatMap(p => p.kudosReceived)
                  .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                  .slice(0, 5)
                  .map((kudos) => {
                    const toMember = allTeamMembers.find(m => m.id === kudos.toUserId);
                    return (
                      <div key={kudos.id} className="p-3 bg-slate-950 border border-slate-800 space-y-2">
                        <div className="flex items-center justify-between text-xs">
                          <div className="flex items-center gap-1.5 font-semibold text-slate-200">
                            <span>{kudos.fromName}</span>
                            <span className="text-slate-500 text-[10px] font-normal">&rarr;</span>
                            <span className="text-indigo-300">{toMember?.name || 'Teammate'}</span>
                          </div>
                          <div className="flex items-center text-amber-400 text-xs">
                            {Array.from({ length: kudos.stars }).map((_, i) => (
                              <Star key={i} className="w-3 h-3 fill-amber-400" />
                            ))}
                          </div>
                        </div>

                        <p className="text-xs text-slate-300 italic leading-snug">
                          "{kudos.reason}"
                        </p>

                        <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 pt-1 border-t border-slate-900">
                          <span>{new Date(kudos.date).toLocaleDateString([], { month: 'short', day: 'numeric' })}</span>
                          <span className="text-emerald-400 font-semibold">+{kudos.stars * 50} XP</span>
                        </div>
                      </div>
                    );
                  })
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Award Kudos Modal */}
      {isKudosModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-md shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <Heart className="w-4 h-4 text-rose-400 fill-rose-400/40" />
                <span>Award Peer Kudos & Bonus Stars</span>
              </h2>
              <button onClick={() => setIsKudosModalOpen(false)} className="text-slate-400 hover:text-slate-200">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSendKudos} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Select Colleague</label>
                <select
                  value={selectedToUserId}
                  onChange={(e) => setSelectedToUserId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 p-2 text-slate-200"
                >
                  {allTeamMembers.filter(m => m.id !== currentUser.id).map(m => (
                    <option key={m.id} value={m.id}>
                      {m.name} ({m.designation || m.role})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Star Rating</label>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setKudosStars(star)}
                      className="p-1 transition-transform hover:scale-125"
                    >
                      <Star
                        className={`w-6 h-6 ${
                          star <= kudosStars
                            ? 'text-amber-400 fill-amber-400'
                            : 'text-slate-600'
                        }`}
                      />
                    </button>
                  ))}
                  <span className="text-xs font-mono text-slate-400 ml-2">+{kudosStars * 50} XP Awarded</span>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Recognition Message / Reason</label>
                <textarea
                  required
                  rows={3}
                  value={kudosReason}
                  onChange={(e) => setKudosReason(e.target.value)}
                  placeholder="e.g. Excellent work on the low latency Kafka deployment and client presentation..."
                  className="w-full bg-slate-950 border border-slate-700 p-2.5 text-slate-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsKudosModalOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold transition-colors flex items-center gap-1.5 shadow-sm"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>Send Kudos & Celebrate</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
