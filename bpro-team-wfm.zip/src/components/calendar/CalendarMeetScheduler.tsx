import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { MeetingSchedule } from '../../types';
import { 
  Calendar as CalendarIcon, 
  Video, 
  Plus, 
  Clock, 
  Users, 
  Copy, 
  Check, 
  ExternalLink, 
  Download, 
  AlertCircle, 
  CheckCircle2, 
  Send,
  X 
} from 'lucide-react';
import { 
  generateMeetCode, 
  createGoogleCalendarWebIntent, 
  downloadIcsFile, 
  createGoogleCalendarEventViaApi 
} from '../../services/googleCalendar';
import { ConfirmActionModal } from '../modals/ConfirmActionModal';

export const CalendarMeetScheduler: React.FC = () => {
  const { 
    meetings, 
    clients, 
    projects, 
    currentUser, 
    googleUser, 
    signInWithGoogle, 
    scheduleMeeting 
  } = useApp();

  const [isNewMeetingOpen, setIsNewMeetingOpen] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [selectedClientId, setSelectedClientId] = useState(clients[0]?.id || '');
  const [selectedProjectId, setSelectedProjectId] = useState(projects[0]?.id || '');
  const [meetingDate, setMeetingDate] = useState(() => new Date().toISOString().substring(0, 10));
  const [meetingTime, setMeetingTime] = useState('14:00');
  const [durationMinutes, setDurationMinutes] = useState(45);
  const [attendeeEmails, setAttendeeEmails] = useState('');
  const [syncToGoogleCalendar, setSyncToGoogleCalendar] = useState(true);

  // Confirmation modal state for Workspace mutation
  const [pendingSchedulePayload, setPendingSchedulePayload] = useState<any | null>(null);
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
  const [apiStatusMessage, setApiStatusMessage] = useState<string | null>(null);

  const handleCopyLink = (url: string, id: string) => {
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleOpenScheduleModal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !selectedClientId) return;

    const startDateTime = new Date(`${meetingDate}T${meetingTime}:00`);
    const endDateTime = new Date(startDateTime.getTime() + durationMinutes * 60 * 1000);

    const client = clients.find(c => c.id === selectedClientId);
    const emails = attendeeEmails.split(',').map(s => s.trim()).filter(Boolean);
    if (client?.email && !emails.includes(client.email)) {
      emails.push(client.email);
    }

    const payload = {
      title: title.trim(),
      description: description.trim(),
      clientId: selectedClientId,
      projectId: selectedProjectId || undefined,
      startTime: startDateTime.toISOString(),
      endTime: endDateTime.toISOString(),
      attendeeEmails: emails,
      scheduledBy: currentUser.id,
      syncToApi: syncToGoogleCalendar && !!googleUser,
    };

    setPendingSchedulePayload(payload);
    // As per Workspace integration skill, always confirm before mutating user calendar!
    setIsConfirmModalOpen(true);
  };

  const executeScheduleMeeting = async () => {
    if (!pendingSchedulePayload) return;

    const payload = pendingSchedulePayload;
    let meetLink = generateMeetCode('omn');
    let gCalEventId: string | undefined = undefined;

    if (payload.syncToApi) {
      try {
        setApiStatusMessage('Syncing event & Google Meet room with Google Calendar API...');
        const apiEvent = await createGoogleCalendarEventViaApi({
          title: payload.title,
          description: `${payload.description}\n\nClient: ${clients.find(c => c.id === payload.clientId)?.company || ''}\nProject: ${projects.find(p => p.id === payload.projectId)?.title || ''}`,
          startDate: payload.startTime,
          endDate: payload.endTime,
          attendees: payload.attendeeEmails,
          createMeetLink: true,
        });

        if (apiEvent.meetLink) {
          meetLink = apiEvent.meetLink;
        }
        gCalEventId = apiEvent.id;
        setApiStatusMessage('Successfully synchronized with Google Calendar!');
      } catch (err: any) {
        console.warn('Google Calendar API sync note:', err.message);
        setApiStatusMessage(`Created offline with Meet link. Note: ${err.message}`);
      }
    }

    scheduleMeeting({
      title: payload.title,
      description: payload.description,
      clientId: payload.clientId,
      projectId: payload.projectId,
      startTime: payload.startTime,
      endTime: payload.endTime,
      attendeeEmails: payload.attendeeEmails,
      googleMeetLink: meetLink,
      googleCalendarEventId: gCalEventId,
      scheduledBy: payload.scheduledBy,
    });

    setIsNewMeetingOpen(false);
    setTitle('');
    setDescription('');
    setPendingSchedulePayload(null);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-slate-900 border border-slate-800">
        <div>
          <h1 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <Video className="w-5 h-5 text-sky-400" />
            <span>Google Calendar & Meet Scheduling Platform</span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Launch instant video conferences, sync client milestones & invite stakeholders
          </p>
        </div>

        <div className="flex items-center gap-2">
          {!googleUser ? (
            <button
              onClick={signInWithGoogle}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <CalendarIcon className="w-3.5 h-3.5 text-indigo-400" />
              <span>Sign in with Google</span>
            </button>
          ) : (
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-950/60 border border-indigo-700/60 text-xs font-mono text-indigo-300">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Google Calendar Active: {googleUser.email}</span>
            </div>
          )}

          <button
            onClick={() => setIsNewMeetingOpen(true)}
            className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Schedule Session</span>
          </button>
        </div>
      </div>

      {apiStatusMessage && (
        <div className="p-3 bg-indigo-950/40 border border-indigo-800 text-xs text-indigo-300 flex items-center justify-between">
          <span>{apiStatusMessage}</span>
          <button onClick={() => setApiStatusMessage(null)} className="text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Instant Google Meet Room Card */}
      <div className="p-5 bg-gradient-to-r from-slate-900 to-indigo-950/30 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <h2 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              Instant Google Meet Video Room Generator
            </h2>
          </div>
          <p className="text-xs text-slate-400 max-w-xl">
            Need an urgent ad-hoc sync with a client or external consultant? Generate an enterprise meeting link in 1-click and copy the invitation.
          </p>
        </div>

        <button
          onClick={() => {
            const instantLink = generateMeetCode('omn-quick');
            navigator.clipboard.writeText(instantLink);
            setApiStatusMessage(`Instant Google Meet link generated & copied: ${instantLink}`);
            setTimeout(() => setApiStatusMessage(null), 5000);
          }}
          className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold flex items-center gap-2 transition-colors shrink-0 shadow-lg shadow-sky-950/30"
        >
          <Video className="w-4 h-4" />
          <span>Generate & Copy Instant Meet Link</span>
        </button>
      </div>

      {/* Scheduled Sessions List */}
      <div className="bg-slate-900 border border-slate-800 overflow-hidden">
        <div className="px-5 py-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
            Scheduled Calendar Sessions ({meetings.length})
          </span>
          <span className="text-[11px] font-mono text-slate-500">All times in {Intl.DateTimeFormat().resolvedOptions().timeZone}</span>
        </div>

        <div className="divide-y divide-slate-800/60">
          {meetings.length === 0 ? (
            <div className="p-12 text-center text-xs text-slate-500">
              No meetings scheduled yet. Click "Schedule Session" above to set up a Google Meet call.
            </div>
          ) : (
            meetings.map((meet) => {
              const client = clients.find(c => c.id === meet.clientId);
              const project = projects.find(p => p.id === meet.projectId);
              const isPast = new Date(meet.endTime) < new Date();

              const gCalWebIntent = createGoogleCalendarWebIntent({
                title: meet.title,
                description: `${meet.description}\n\nGoogle Meet Link: ${meet.googleMeetLink}`,
                startDate: meet.startTime,
                endDate: meet.endTime,
                location: meet.googleMeetLink,
                addEmails: meet.attendeeEmails,
              });

              return (
                <div key={meet.id} className="p-5 hover:bg-slate-850/40 transition-colors flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div className="space-y-1.5 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-sm font-bold text-slate-100">{meet.title}</h3>
                      <span className="text-[10px] font-mono px-1.5 py-0.2 bg-slate-800 text-slate-300 border border-slate-700">
                        {client?.company || client?.name}
                      </span>
                      {project && (
                        <span className="text-[10px] font-mono px-1.5 py-0.2 bg-indigo-950 text-indigo-400 border border-indigo-800">
                          {project.code}
                        </span>
                      )}
                      {isPast && (
                        <span className="text-[10px] font-mono px-1.5 py-0.2 bg-slate-800 text-slate-500 uppercase">
                          Completed / Past
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-slate-400 leading-relaxed">{meet.description}</p>

                    <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-slate-400 pt-1">
                      <div className="flex items-center gap-1.5 text-slate-300">
                        <Clock className="w-3.5 h-3.5 text-indigo-400" />
                        <span>
                          {new Date(meet.startTime).toLocaleString([], { 
                            weekday: 'short', 
                            month: 'short', 
                            day: 'numeric', 
                            hour: '2-digit', 
                            minute: '2-digit' 
                          })}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 text-slate-400">
                        <Users className="w-3.5 h-3.5 text-slate-500" />
                        <span>{meet.attendeeEmails.join(', ')}</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    {/* Copy Meet Link */}
                    <button
                      onClick={() => handleCopyLink(meet.googleMeetLink, meet.id)}
                      className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium flex items-center gap-1 transition-colors"
                      title="Copy Google Meet Link"
                    >
                      {copiedId === meet.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
                      <span>{copiedId === meet.id ? 'Copied' : 'Copy Link'}</span>
                    </button>

                    {/* Add to Google Calendar Web Intent */}
                    <a
                      href={gCalWebIntent}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium flex items-center gap-1 transition-colors"
                      title="Add to your personal Google Calendar"
                    >
                      <CalendarIcon className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Add to Google Cal</span>
                    </a>

                    {/* Download ICS */}
                    <button
                      onClick={() => downloadIcsFile({
                        title: meet.title,
                        description: `${meet.description}\nJoin Meet: ${meet.googleMeetLink}`,
                        startDate: meet.startTime,
                        endDate: meet.endTime,
                        filename: meet.title.toLowerCase().replace(/[^a-z0-9]/g, '-'),
                      })}
                      className="px-2 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 border border-slate-700 text-xs transition-colors"
                      title="Download .ics Calendar File"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>

                    {/* Join Google Meet Button */}
                    <a
                      href={meet.googleMeetLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
                    >
                      <Video className="w-3.5 h-3.5" />
                      <span>Join Google Meet</span>
                    </a>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Schedule Meeting Modal */}
      {isNewMeetingOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-xl shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <Video className="w-4 h-4 text-sky-400" />
                <span>Schedule Google Calendar & Meet Session</span>
              </h2>
              <button onClick={() => setIsNewMeetingOpen(false)} className="text-slate-400 hover:text-slate-200">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleOpenScheduleModal} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Meeting Title *</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Q4 Milestone Scoping Review & Google Meet"
                  className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 focus:outline-none focus:border-indigo-500"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Agenda & Context</label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={2}
                  placeholder="Outline topics, deliverables under review, meeting goals..."
                  className="w-full bg-slate-950 border border-slate-700 p-2.5 text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Client Stakeholder *</label>
                  <select
                    value={selectedClientId}
                    onChange={(e) => setSelectedClientId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    {clients.map(c => (
                      <option key={c.id} value={c.id}>{c.company || c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Project</label>
                  <select
                    value={selectedProjectId}
                    onChange={(e) => setSelectedProjectId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="">None / General</option>
                    {projects.map(p => (
                      <option key={p.id} value={p.id}>{p.code} - {p.title}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Date</label>
                  <input
                    type="date"
                    value={meetingDate}
                    onChange={(e) => setMeetingDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200 font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Start Time</label>
                  <input
                    type="time"
                    value={meetingTime}
                    onChange={(e) => setMeetingTime(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200 font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Duration</label>
                  <select
                    value={durationMinutes}
                    onChange={(e) => setDurationMinutes(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200"
                  >
                    <option value={15}>15 Minutes</option>
                    <option value={30}>30 Minutes</option>
                    <option value={45}>45 Minutes</option>
                    <option value={60}>1 Hour</option>
                    <option value={90}>1.5 Hours</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Attendee Emails (comma separated)</label>
                <input
                  type="text"
                  value={attendeeEmails}
                  onChange={(e) => setAttendeeEmails(e.target.value)}
                  placeholder="client@corp.com, consultant@cloud.io"
                  className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100"
                />
              </div>

              <div className="p-3 bg-slate-950 border border-slate-800 flex items-center gap-2">
                <input
                  type="checkbox"
                  id="syncGCal"
                  checked={syncToGoogleCalendar}
                  onChange={(e) => setSyncToGoogleCalendar(e.target.checked)}
                  className="rounded-none bg-slate-900 border-slate-700 text-indigo-600 focus:ring-0"
                />
                <label htmlFor="syncGCal" className="text-slate-300 text-xs cursor-pointer">
                  Sync directly to connected Google Calendar account & generate official Google Meet conference link
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsNewMeetingOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold transition-colors shadow-sm"
                >
                  Review & Schedule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Confirmation Modal for Calendar Event Creation */}
      <ConfirmActionModal
        isOpen={isConfirmModalOpen}
        title="Confirm Google Calendar & Meet Scheduling"
        message={`You are about to schedule "${pendingSchedulePayload?.title}" on ${pendingSchedulePayload?.startTime?.substring(0, 10)}. This will create the Google Meet conference space and invite ${pendingSchedulePayload?.attendeeEmails?.length || 0} participants.`}
        confirmText="Confirm & Create Meeting"
        onConfirm={executeScheduleMeeting}
        onClose={() => setIsConfirmModalOpen(false)}
      />
    </div>
  );
};
