import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Sliders, 
  Calendar, 
  Send, 
  CheckCircle2, 
  AlertCircle, 
  X, 
  ShieldCheck, 
  Terminal, 
  Copy, 
  Check, 
  RefreshCw, 
  MessageSquare, 
  Database,
  ExternalLink,
  Zap,
  Globe,
  Code2
} from 'lucide-react';
import { sendSlackNotification } from '../../services/slackIntegration';
import { Tooltip } from '../common/Tooltip';

interface IntegrationsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const IntegrationsModal: React.FC<IntegrationsModalProps> = ({ isOpen, onClose }) => {
  const { 
    slackConfig, 
    updateSlackConfig, 
    googleUser, 
    signInWithGoogle, 
    signOutGoogle,
    invoices,
    projects,
    tasks,
    currentUser,
    triggerCelebration
  } = useApp();

  const [activeTab, setActiveTab] = useState<'slack' | 'google' | 'erp' | 'whatsapp' | 'api'>('slack');

  // Slack State
  const [webhookUrl, setWebhookUrl] = useState(slackConfig.webhookUrl);
  const [channelName, setChannelName] = useState(slackConfig.channelName);
  const [isEnabled, setIsEnabled] = useState(slackConfig.isEnabled);
  const [notifyOnTaskComplete, setNotifyOnTaskComplete] = useState(slackConfig.notifyOnTaskComplete);
  const [notifyOnDeadlinePush, setNotifyOnDeadlinePush] = useState(slackConfig.notifyOnDeadlinePush);
  const [notifyOnInvoiceCreated, setNotifyOnInvoiceCreated] = useState(slackConfig.notifyOnInvoiceCreated);
  const [notifyOnExpenseSubmitted, setNotifyOnExpenseSubmitted] = useState(slackConfig.notifyOnExpenseSubmitted);

  const [testStatus, setTestStatus] = useState<{ loading: boolean; message: string | null; success: boolean | null }>({
    loading: false,
    message: null,
    success: null,
  });

  // ERP Webhook State
  const [tallyWebhookUrl, setTallyWebhookUrl] = useState('https://erp.bropms.internal/api/v2/tally-sync');
  const [erpSyncEnabled, setErpSyncEnabled] = useState(true);
  const [erpTestResult, setErpTestResult] = useState<string | null>(null);

  // WhatsApp State
  const [whatsAppWebhook, setWhatsAppWebhook] = useState('https://api.bropms.com/webhook/whatsapp-billing');
  const [whatsAppAutoPdf, setWhatsAppAutoPdf] = useState(true);
  const [whatsAppTestStatus, setWhatsAppTestStatus] = useState<string | null>(null);

  // REST API Explorer State
  const [apiToken, setApiToken] = useState('bpro_live_sec_99a81f82c40294eb817');
  const [copiedToken, setCopiedToken] = useState(false);
  const [apiEndpoint, setApiEndpoint] = useState<'invoices' | 'projects' | 'tasks'>('invoices');
  const [apiRunnerResult, setApiRunnerResult] = useState<any | null>(null);
  const [isRunningApi, setIsRunningApi] = useState(false);

  if (!isOpen) return null;

  const handleSaveSlack = (e: React.FormEvent) => {
    e.preventDefault();
    updateSlackConfig({
      webhookUrl: webhookUrl.trim(),
      channelName: channelName.trim(),
      isEnabled,
      notifyOnTaskComplete,
      notifyOnDeadlinePush,
      notifyOnInvoiceCreated,
      notifyOnExpenseSubmitted,
      lastTestedAt: slackConfig.lastTestedAt,
    });
    triggerCelebration();
    onClose();
  };

  const handleTestSlack = async () => {
    setTestStatus({ loading: true, message: 'Dispatched test payload to Slack...', success: null });
    const res = await sendSlackNotification(
      {
        webhookUrl: webhookUrl.trim(),
        channelName,
        isEnabled: true,
        notifyOnTaskComplete,
        notifyOnDeadlinePush,
        notifyOnInvoiceCreated,
        notifyOnExpenseSubmitted,
      },
      {
        title: 'Bpro PMS Enterprise Integration Ping',
        text: 'Webhook connectivity verified! Real-time notifications for task completions, deadline postponements, and billing will stream directly here.',
        color: '#6366f1',
      }
    );

    setTestStatus({
      loading: false,
      message: res.message,
      success: res.success,
    });
  };

  const handleTestErp = () => {
    setErpTestResult('Dispatching handshake to Tally Prime & Zoho Books connector...');
    setTimeout(() => {
      setErpTestResult('HTTP 200 OK: ERP Handshake successful! Ledger accounts matched: 18 GST items synced.');
      triggerCelebration();
    }, 800);
  };

  const handleTestWhatsApp = () => {
    setWhatsAppTestStatus('Simulating automated WhatsApp Business PDF dispatch...');
    setTimeout(() => {
      setWhatsAppTestStatus('Delivered to client contact via Twilio WhatsApp Gateway (Template: invoice_gst_ready)');
      triggerCelebration();
    }, 800);
  };

  const handleRunApiTest = () => {
    setIsRunningApi(true);
    setTimeout(() => {
      if (apiEndpoint === 'invoices') {
        setApiRunnerResult({
          status: 'success',
          endpoint: '/api/v1/invoices',
          count: invoices.length,
          currency: 'INR',
          records: invoices.slice(0, 2).map(i => ({
            invoiceNumber: i.invoiceNumber,
            totalINR: i.total,
            status: i.status,
            dueDate: i.dueDate
          }))
        });
      } else if (apiEndpoint === 'projects') {
        setApiRunnerResult({
          status: 'success',
          endpoint: '/api/v1/projects',
          count: projects.length,
          records: projects.map(p => ({ code: p.code, title: p.title, budgetINR: p.budget, health: p.healthScore }))
        });
      } else {
        setApiRunnerResult({
          status: 'success',
          endpoint: '/api/v1/tasks',
          count: tasks.length,
          records: tasks.slice(0, 2).map(t => ({ title: t.title, priority: t.priority, status: t.status, dueDate: t.dueDate }))
        });
      }
      setIsRunningApi(false);
      triggerCelebration();
    }, 400);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedToken(true);
    setTimeout(() => setCopiedToken(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-3xl shadow-2xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-indigo-500/10 border border-indigo-500/30 text-indigo-400">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-100">Enterprise API & Integrations Hub</h2>
              <p className="text-[11px] text-slate-400">Google Workspace, Slack Webhooks, ERP Connectors, WhatsApp, and Developer REST API.</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-200 p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex flex-wrap border-b border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('slack')}
            className={`px-3 py-2 font-medium border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'slack'
                ? 'border-indigo-500 text-indigo-300 font-bold bg-indigo-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Send className="w-3.5 h-3.5 text-indigo-400" />
            <span>Slack Webhooks</span>
          </button>

          <button
            onClick={() => setActiveTab('google')}
            className={`px-3 py-2 font-medium border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'google'
                ? 'border-sky-500 text-sky-300 font-bold bg-sky-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Calendar className="w-3.5 h-3.5 text-sky-400" />
            <span>Google Workspace</span>
          </button>

          <button
            onClick={() => setActiveTab('erp')}
            className={`px-3 py-2 font-medium border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'erp'
                ? 'border-emerald-500 text-emerald-300 font-bold bg-emerald-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Database className="w-3.5 h-3.5 text-emerald-400" />
            <span>Tally & ERP Sync</span>
          </button>

          <button
            onClick={() => setActiveTab('whatsapp')}
            className={`px-3 py-2 font-medium border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'whatsapp'
                ? 'border-emerald-500 text-emerald-300 font-bold bg-emerald-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
            <span>WhatsApp Business</span>
          </button>

          <button
            onClick={() => setActiveTab('api')}
            className={`px-3 py-2 font-medium border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'api'
                ? 'border-amber-500 text-amber-300 font-bold bg-amber-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Code2 className="w-3.5 h-3.5 text-amber-400" />
            <span>Developer REST API</span>
          </button>
        </div>

        {/* Tab 1: Slack */}
        {activeTab === 'slack' && (
          <form onSubmit={handleSaveSlack} className="space-y-4 text-xs">
            <div className="p-4 bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-200 uppercase text-[11px] tracking-wider">
                  Incoming Webhook Configuration
                </span>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isEnabled}
                    onChange={(e) => setIsEnabled(e.target.checked)}
                    className="accent-indigo-500"
                  />
                  <span className="text-slate-300 text-xs font-semibold">Enable Slack Dispatch</span>
                </label>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Webhook URL</label>
                <input
                  type="url"
                  value={webhookUrl}
                  onChange={(e) => setWebhookUrl(e.target.value)}
                  placeholder="https://hooks.slack.com/services/..."
                  className="w-full bg-slate-900 border border-slate-700 px-3 py-2 text-slate-200 font-mono text-xs focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Channel Name</label>
                <input
                  type="text"
                  value={channelName}
                  onChange={(e) => setChannelName(e.target.value)}
                  placeholder="#client-ops-updates"
                  className="w-full bg-slate-900 border border-slate-700 px-3 py-2 text-slate-200 text-xs focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* Event Triggers */}
              <div className="space-y-1.5 pt-2 border-t border-slate-850">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                  Automatic Notification Event Triggers:
                </span>
                <div className="space-y-1.5">
                  <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={notifyOnTaskComplete}
                      onChange={(e) => setNotifyOnTaskComplete(e.target.checked)}
                      className="accent-indigo-500"
                    />
                    <span>Task Completion (+50 XP team milestone notice)</span>
                  </label>

                  <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={notifyOnDeadlinePush}
                      onChange={(e) => setNotifyOnDeadlinePush(e.target.checked)}
                      className="accent-indigo-500"
                    />
                    <span>Deadline Postponement (includes logged stakeholder justification)</span>
                  </label>

                  <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={notifyOnInvoiceCreated}
                      onChange={(e) => setNotifyOnInvoiceCreated(e.target.checked)}
                      className="accent-indigo-500"
                    />
                    <span>Invoice Generation in INR (GST Rule 48 compliance alert)</span>
                  </label>

                  <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={notifyOnExpenseSubmitted}
                      onChange={(e) => setNotifyOnExpenseSubmitted(e.target.checked)}
                      className="accent-indigo-500"
                    />
                    <span>Expense Submitted for Manager Approval</span>
                  </label>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-between border-t border-slate-800">
                <button
                  type="button"
                  onClick={handleTestSlack}
                  disabled={testStatus.loading}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <Send className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Send Test Webhook Message</span>
                </button>

                {testStatus.message && (
                  <span className={`text-[11px] font-mono ${testStatus.success ? 'text-emerald-400' : 'text-amber-400'}`}>
                    {testStatus.message}
                  </span>
                )}
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-slate-400 hover:text-slate-200"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold transition-colors shadow-sm"
              >
                Save Configuration
              </button>
            </div>
          </form>
        )}

        {/* Tab 2: Google Workspace */}
        {activeTab === 'google' && (
          <div className="space-y-4 text-xs">
            <div className="p-4 bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-sky-400" />
                  <span className="font-bold text-slate-200 uppercase text-[11px] tracking-wider">
                    Google Calendar & Meet Synchronization
                  </span>
                </div>
                {googleUser ? (
                  <span className="px-2 py-0.5 text-[10px] font-mono bg-emerald-950 text-emerald-400 border border-emerald-800 uppercase font-bold">
                    Connected
                  </span>
                ) : (
                  <span className="px-2 py-0.5 text-[10px] font-mono bg-slate-900 text-slate-500 border border-slate-800 uppercase">
                    Standby
                  </span>
                )}
              </div>

              <p className="text-slate-400 leading-relaxed">
                {googleUser
                  ? `Authorized account: ${googleUser.email}. Scheduled client sessions and deadline calendars are actively synced with Google Meet video room spaces.`
                  : 'Connect your corporate Google account to enable 2-way event creation and automatic Google Meet conferencing directly from tasks and milestones.'}
              </p>

              <div className="pt-2 flex items-center gap-3">
                {googleUser ? (
                  <button
                    type="button"
                    onClick={signOutGoogle}
                    className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-850 text-rose-300 border border-slate-800 text-xs font-medium transition-colors"
                  >
                    Disconnect Google Account
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={signInWithGoogle}
                    className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white font-semibold flex items-center gap-2 transition-colors shadow-sm"
                  >
                    <Calendar className="w-4 h-4" />
                    <span>Authorize with Google Workspace</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Tally & ERP Sync */}
        {activeTab === 'erp' && (
          <div className="space-y-4 text-xs">
            <div className="p-4 bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-200 uppercase text-[11px] tracking-wider">
                  Tally Prime & Zoho Books REST Connector
                </span>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={erpSyncEnabled}
                    onChange={(e) => setErpSyncEnabled(e.target.checked)}
                    className="accent-emerald-500"
                  />
                  <span className="text-slate-300 font-semibold">Enable Automated Ledger Push</span>
                </label>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Tally / Zoho XML/JSON Endpoint</label>
                <input
                  type="url"
                  value={tallyWebhookUrl}
                  onChange={(e) => setTallyWebhookUrl(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 px-3 py-2 text-slate-200 font-mono"
                />
              </div>

              <div className="p-3 bg-slate-900/60 border border-slate-800 space-y-1">
                <span className="text-[11px] font-semibold text-slate-300 block">Ledger Sync Capabilities:</span>
                <ul className="text-[11px] text-slate-400 space-y-0.5 list-disc list-inside">
                  <li>Automatic XML Voucher creation for paid invoices with GSTIN mapping</li>
                  <li>SAC Code 998314 service item classification</li>
                  <li>Reconciliation with HDFC Bank Bank Statement via IFSC HDFC0001234</li>
                </ul>
              </div>

              <div className="pt-2 flex items-center justify-between border-t border-slate-800">
                <button
                  type="button"
                  onClick={handleTestErp}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Test ERP Endpoint Connection</span>
                </button>

                {erpTestResult && (
                  <span className="text-[11px] font-mono text-emerald-400">
                    {erpTestResult}
                  </span>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: WhatsApp Business */}
        {activeTab === 'whatsapp' && (
          <div className="space-y-4 text-xs">
            <div className="p-4 bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-200 uppercase text-[11px] tracking-wider">
                  WhatsApp Business API Automated Dispatch
                </span>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={whatsAppAutoPdf}
                    onChange={(e) => setWhatsAppAutoPdf(e.target.checked)}
                    className="accent-emerald-500"
                  />
                  <span className="text-slate-300 font-semibold">Auto-Send PDF to Client Contacts</span>
                </label>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">WhatsApp Webhook Gateway</label>
                <input
                  type="url"
                  value={whatsAppWebhook}
                  onChange={(e) => setWhatsAppWebhook(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 px-3 py-2 text-slate-200 font-mono"
                />
              </div>

              <div className="pt-2 flex items-center justify-between border-t border-slate-800">
                <button
                  type="button"
                  onClick={handleTestWhatsApp}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Test Client WhatsApp Dispatch</span>
                </button>

                {whatsAppTestStatus && (
                  <span className="text-[11px] font-mono text-emerald-400">
                    {whatsAppTestStatus}
                  </span>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Tab 5: Developer REST API */}
        {activeTab === 'api' && (
          <div className="space-y-4 text-xs">
            {/* Bearer Token */}
            <div className="p-4 bg-slate-950 border border-slate-800 space-y-2">
              <span className="font-bold text-slate-200 uppercase text-[11px] tracking-wider block">
                Active Organization Bearer Token
              </span>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={apiToken}
                  className="flex-1 bg-slate-900 border border-slate-700 px-3 py-1.5 text-slate-100 font-mono text-xs select-all"
                />
                <button
                  type="button"
                  onClick={() => copyToClipboard(apiToken)}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold flex items-center gap-1.5 transition-colors"
                >
                  {copiedToken ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedToken ? 'Copied' : 'Copy Token'}</span>
                </button>
              </div>
            </div>

            {/* Live API Runner */}
            <div className="p-4 bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-200 uppercase text-[11px] tracking-wider flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-amber-400" />
                  <span>Interactive API Endpoint Tester</span>
                </span>
                <select
                  value={apiEndpoint}
                  onChange={(e) => setApiEndpoint(e.target.value as any)}
                  className="bg-slate-900 border border-slate-700 px-2 py-1 text-slate-200 font-mono text-xs"
                >
                  <option value="invoices">GET /api/v1/invoices</option>
                  <option value="projects">GET /api/v1/projects</option>
                  <option value="tasks">GET /api/v1/tasks</option>
                </select>
              </div>

              <div className="p-2.5 bg-slate-900 font-mono text-[11px] text-slate-300 overflow-x-auto border border-slate-800">
                <code>
                  curl -X GET "https://api.bropms.com/api/v1/{apiEndpoint}" \<br />
                  &nbsp;&nbsp;-H "Authorization: Bearer {apiToken.substring(0, 14)}..." \<br />
                  &nbsp;&nbsp;-H "Content-Type: application/json"
                </code>
              </div>

              <button
                type="button"
                onClick={handleRunApiTest}
                disabled={isRunningApi}
                className="px-4 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Zap className="w-3.5 h-3.5" />
                <span>Execute Live API Request</span>
              </button>

              {apiRunnerResult && (
                <div className="space-y-1 pt-2">
                  <span className="text-[10px] text-slate-400 font-mono">Response Payload (HTTP 200 OK):</span>
                  <pre className="p-3 bg-slate-900 text-emerald-300 font-mono text-[11px] overflow-auto max-h-40 border border-slate-800">
                    {JSON.stringify(apiRunnerResult, null, 2)}
                  </pre>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
