import React, { useState, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Upload, 
  FileText, 
  FileSpreadsheet, 
  Check, 
  AlertCircle, 
  Download, 
  X, 
  Paperclip, 
  Trash2, 
  ArrowRight,
  ShieldCheck,
  FileCheck
} from 'lucide-react';
import { exportToCsv } from '../../services/csvExport';
import { Tooltip } from '../common/Tooltip';
import { storageService } from '../../services/storage';

interface FormatUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FormatUploadModal: React.FC<FormatUploadModalProps> = ({ isOpen, onClose }) => {
  const { 
    addTask, 
    addClient, 
    documents, 
    addDocument, 
    deleteDocument, 
    projects, 
    clients, 
    currentUser,
    triggerCelebration
  } = useApp();

  const [activeTab, setActiveTab] = useState<'csv' | 'receipts' | 'json'>('csv');

  // CSV State
  const [csvType, setCsvType] = useState<'tasks' | 'clients'>('tasks');
  const [parsedRows, setParsedRows] = useState<any[]>([]);
  const [csvFileName, setCsvFileName] = useState<string | null>(null);
  const [importSuccessMessage, setImportSuccessMessage] = useState<string | null>(null);

  // Document Upload State
  const [docCategory, setDocCategory] = useState<'receipt' | 'contract' | 'specification' | 'statement' | 'other'>('receipt');
  const [docFile, setDocFile] = useState<File | null>(null);

  // JSON Restore State
  const [jsonRestoreData, setJsonRestoreData] = useState<any | null>(null);
  const [jsonRestoreFileName, setJsonRestoreFileName] = useState<string | null>(null);
  const [restoreMessage, setRestoreMessage] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const docInputRef = useRef<HTMLInputElement>(null);
  const jsonInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  // Handle CSV Upload & Parse
  const handleCsvFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setCsvFileName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (!text) return;

      const lines = text.split(/\r\n|\n/).filter(line => line.trim());
      if (lines.length < 2) return;

      const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
      const rows: any[] = [];

      for (let i = 1; i < lines.length; i++) {
        // Basic CSV regex split
        const values = lines[i].split(',').map(v => v.trim().replace(/^"|"$/g, ''));
        const rowObj: any = {};
        headers.forEach((h, idx) => {
          rowObj[h] = values[idx] || '';
        });
        rows.push(rowObj);
      }

      setParsedRows(rows.slice(0, 50)); // limit preview
    };
    reader.readAsText(file);
  };

  const handleDownloadTemplate = (type: 'tasks' | 'clients') => {
    if (type === 'tasks') {
      const sample = [
        {
          'Title': 'Design HL7 FHIR biometric validator',
          'Description': 'Strict JSON schema parsing adhering to HL7 v4 standard',
          'Priority': 'high',
          'EstimatedHours': '24',
          'DueDate': new Date(Date.now() + 7 * 86400000).toISOString().substring(0, 10),
          'ProjectCode': projects[0]?.code || 'APO-EHR',
        },
        {
          'Title': 'Automate Kafka broker partition failover test',
          'Description': 'Zero message loss benchmark across 3 availability zones',
          'Priority': 'urgent',
          'EstimatedHours': '36',
          'DueDate': new Date(Date.now() + 10 * 86400000).toISOString().substring(0, 10),
          'ProjectCode': projects[1]?.code || 'VAN-FRD',
        },
      ];
      exportToCsv('Tasks_Import_Template', sample);
    } else {
      const sample = [
        {
          'Name': 'Dr. Vikram Malhotra',
          'Company': 'Apex Health Diagnostics Ltd',
          'Email': 'v.malhotra@apexdiagnostics.in',
          'Phone': '+91 22 2840 5500',
          'Address': 'Powai Tech City, Mumbai, Maharashtra 400076',
          'TaxId': '27AABCA5512F1Z4',
          'HourlyRate': '4200',
        },
      ];
      exportToCsv('Clients_Import_Template', sample);
    }
  };

  const handleExecuteImport = () => {
    if (!parsedRows.length) return;

    let count = 0;
    if (csvType === 'tasks') {
      parsedRows.forEach((row) => {
        const title = row['Title'] || row['title'] || row['task'] || 'Imported Task';
        const description = row['Description'] || row['description'] || '';
        const priority = (row['Priority'] || row['priority'] || 'medium').toLowerCase() as any;
        const estHours = Number(row['EstimatedHours'] || row['Hours'] || 16);
        const dueDate = row['DueDate'] || row['dueDate'] || new Date(Date.now() + 7 * 86400000).toISOString().substring(0, 10);
        const projCode = (row['ProjectCode'] || '').toUpperCase();
        const matchedProj = projects.find(p => p.code === projCode) || projects[0];

        addTask({
          title,
          description,
          priority: ['low', 'medium', 'high', 'urgent'].includes(priority) ? priority : 'medium',
          estimatedHours: estHours,
          actualHours: 0,
          dueDate,
          projectId: matchedProj ? matchedProj.id : projects[0]?.id || '',
          clientId: matchedProj ? matchedProj.clientId : clients[0]?.id || '',
          assignedToId: currentUser.id,
          createdBy: currentUser.id,
          status: 'backlog',
          tags: ['CSV-Imported'],
        });
        count++;
      });
      setImportSuccessMessage(`Successfully imported ${count} tasks into the backlog!`);
    } else {
      parsedRows.forEach((row) => {
        const name = row['Name'] || row['name'] || 'Enterprise Client';
        const company = row['Company'] || row['company'] || name;
        const email = row['Email'] || row['email'] || 'contact@client.in';
        const phone = row['Phone'] || row['phone'] || '+91 98000 00000';
        const address = row['Address'] || row['address'] || 'India';
        const taxId = row['TaxId'] || row['taxId'] || '';
        const defaultHourlyRate = Number(row['HourlyRate'] || 4500);

        addClient({
          name,
          company,
          email,
          phone,
          address,
          taxId,
          defaultHourlyRate,
          currency: 'INR',
          status: 'active',
          notes: 'Bulk imported via CSV format upload engine.',
        });
        count++;
      });
      setImportSuccessMessage(`Successfully imported ${count} client profiles into CRM!`);
    }

    setParsedRows([]);
    setCsvFileName(null);
    triggerCelebration();
    setTimeout(() => setImportSuccessMessage(null), 5000);
  };

  // Handle Document Upload
  const handleUploadDocument = (e: React.FormEvent) => {
    e.preventDefault();
    if (!docFile) return;

    addDocument({
      name: docFile.name,
      size: docFile.size,
      type: docFile.type || 'application/octet-stream',
      category: docCategory,
    });

    setDocFile(null);
    if (docInputRef.current) docInputRef.current.value = '';
    triggerCelebration();
  };

  // Handle JSON Restore
  const handleJsonFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setJsonRestoreFileName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        setJsonRestoreData(parsed);
      } catch (err: any) {
        setRestoreMessage('Invalid JSON format: ' + err.message);
      }
    };
    reader.readAsText(file);
  };

  const handleApplyJsonRestore = () => {
    if (!jsonRestoreData) return;
    try {
      storageService.importBackup(jsonRestoreData);
      setRestoreMessage('Backup state successfully restored into localStorage! Refreshing view...');
      triggerCelebration();
      setTimeout(() => {
        window.location.reload();
      }, 1500);
    } catch (err: any) {
      setRestoreMessage('Error restoring backup: ' + err.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-3xl shadow-2xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-indigo-500/10 border border-indigo-500/30 text-indigo-400">
              <Upload className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-100">Enterprise Format Upload & Ingestion Engine</h2>
              <p className="text-[11px] text-slate-400">Bulk CSV/Excel parsing, document vault attachments, and JSON backup restores.</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-200 p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('csv')}
            className={`px-4 py-2 font-medium border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'csv'
                ? 'border-indigo-500 text-indigo-300 font-bold bg-indigo-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-indigo-400" />
            <span>Bulk CSV / Excel Ingest</span>
          </button>

          <button
            onClick={() => setActiveTab('receipts')}
            className={`px-4 py-2 font-medium border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'receipts'
                ? 'border-emerald-500 text-emerald-300 font-bold bg-emerald-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Paperclip className="w-3.5 h-3.5 text-emerald-400" />
            <span>Document & Receipt Vault ({documents.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('json')}
            className={`px-4 py-2 font-medium border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'json'
                ? 'border-amber-500 text-amber-300 font-bold bg-amber-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>JSON State Restore</span>
          </button>
        </div>

        {/* Tab 1: CSV / Excel Ingest */}
        {activeTab === 'csv' && (
          <div className="space-y-4 text-xs">
            {importSuccessMessage && (
              <div className="p-3 bg-emerald-950/80 border border-emerald-700 text-emerald-200 flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{importSuccessMessage}</span>
              </div>
            )}

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-slate-300 font-semibold">Select Dataset Type:</span>
                <div className="flex bg-slate-950 border border-slate-800 p-0.5">
                  <button
                    type="button"
                    onClick={() => { setCsvType('tasks'); setParsedRows([]); setCsvFileName(null); }}
                    className={`px-3 py-1 font-medium transition-colors ${
                      csvType === 'tasks' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Sprint Tasks
                  </button>
                  <button
                    type="button"
                    onClick={() => { setCsvType('clients'); setParsedRows([]); setCsvFileName(null); }}
                    className={`px-3 py-1 font-medium transition-colors ${
                      csvType === 'clients' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Clients / Accounts
                  </button>
                </div>
              </div>

              <button
                type="button"
                onClick={() => handleDownloadTemplate(csvType)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 flex items-center gap-1.5 transition-colors"
              >
                <Download className="w-3.5 h-3.5 text-indigo-400" />
                <span>Download Sample CSV Template</span>
              </button>
            </div>

            {/* Drag and Drop Zone */}
            <div
              onClick={() => fileInputRef.current?.click()}
              className="p-8 border-2 border-dashed border-slate-700 hover:border-indigo-500 bg-slate-950/60 text-center cursor-pointer space-y-2 transition-colors"
            >
              <FileSpreadsheet className="w-8 h-8 text-indigo-400 mx-auto" />
              <div className="text-slate-200 font-semibold">
                {csvFileName ? `Selected File: ${csvFileName}` : 'Drop .csv spreadsheet or click to browse'}
              </div>
              <p className="text-[11px] text-slate-400">
                Supports automated header mapping for Title, Description, Priority, Due Date, and Project Code.
              </p>
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv,text/csv"
                onChange={handleCsvFileChange}
                className="hidden"
              />
            </div>

            {/* Parsed Rows Preview */}
            {parsedRows.length > 0 && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-200 flex items-center gap-1.5">
                    <FileCheck className="w-4 h-4 text-emerald-400" />
                    <span>Parsed Rows Preview ({parsedRows.length} records ready to import)</span>
                  </span>
                  <button
                    onClick={handleExecuteImport}
                    className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold transition-colors flex items-center gap-1.5 shadow-sm"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Import {parsedRows.length} Records Now</span>
                  </button>
                </div>

                <div className="max-h-56 overflow-auto border border-slate-800 bg-slate-950">
                  <table className="w-full text-left border-collapse text-[11px]">
                    <thead>
                      <tr className="bg-slate-900 border-b border-slate-800 text-slate-400 font-mono">
                        {Object.keys(parsedRows[0]).slice(0, 5).map((k) => (
                          <th key={k} className="p-2">{k}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 text-slate-300">
                      {parsedRows.slice(0, 10).map((row, idx) => (
                        <tr key={idx} className="hover:bg-slate-900/40">
                          {Object.values(row).slice(0, 5).map((val: any, cidx) => (
                            <td key={cidx} className="p-2 font-mono truncate max-w-[140px]">{String(val)}</td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Document & Receipt Vault */}
        {activeTab === 'receipts' && (
          <div className="space-y-4 text-xs">
            <form onSubmit={handleUploadDocument} className="p-4 bg-slate-950 border border-slate-800 space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-slate-300 font-semibold mb-1">Select File to Upload</label>
                  <input
                    ref={docInputRef}
                    type="file"
                    required
                    onChange={(e) => setDocFile(e.target.files?.[0] || null)}
                    className="w-full bg-slate-900 border border-slate-700 px-3 py-1.5 text-slate-200"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Document Category</label>
                  <select
                    value={docCategory}
                    onChange={(e) => setDocCategory(e.target.value as any)}
                    className="w-full bg-slate-900 border border-slate-700 p-2 text-slate-200"
                  >
                    <option value="receipt">Expense Receipt</option>
                    <option value="contract">Client Contract / NDA</option>
                    <option value="specification">Technical Specification</option>
                    <option value="statement">Bank Statement / Audit</option>
                    <option value="other">Other Document</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end pt-1">
                <button
                  type="submit"
                  disabled={!docFile}
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold transition-colors flex items-center gap-1.5"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Attach Document to Vault</span>
                </button>
              </div>
            </form>

            {/* Existing Documents List */}
            <div className="space-y-2">
              <h3 className="font-bold text-slate-200 uppercase text-[11px] tracking-wider">
                Vault Repository ({documents.length} files stored)
              </h3>

              <div className="divide-y divide-slate-800 bg-slate-950 border border-slate-800 max-h-60 overflow-y-auto">
                {documents.map((doc) => (
                  <div key={doc.id} className="p-3 flex items-center justify-between gap-3 hover:bg-slate-900/40 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-slate-900 border border-slate-800 text-emerald-400 shrink-0">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="font-semibold text-slate-200">{doc.name}</div>
                        <div className="text-[11px] text-slate-400 font-mono">
                          {Math.round(doc.size / 1024)} KB &bull; <span className="capitalize">{doc.category}</span> &bull; {doc.uploadedByName}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => {
                          const dummy = new Blob([`Enterprise vault document: ${doc.name}\nUploaded by: ${doc.uploadedByName}\nTimestamp: ${doc.uploadedAt}`], { type: 'text/plain' });
                          const url = URL.createObjectURL(dummy);
                          const a = document.createElement('a');
                          a.href = url;
                          a.download = doc.name;
                          a.click();
                          URL.revokeObjectURL(url);
                        }}
                        className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 text-[11px] flex items-center gap-1 transition-colors"
                      >
                        <Download className="w-3 h-3 text-indigo-400" />
                        <span>Download</span>
                      </button>

                      <button
                        onClick={() => deleteDocument(doc.id)}
                        className="p-1 text-slate-500 hover:text-rose-400 transition-colors"
                        title="Remove file"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: JSON State Restore */}
        {activeTab === 'json' && (
          <div className="space-y-4 text-xs">
            {restoreMessage && (
              <div className="p-3 bg-indigo-950/80 border border-indigo-700 text-indigo-200 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-indigo-400 shrink-0" />
                <span>{restoreMessage}</span>
              </div>
            )}

            <div
              onClick={() => jsonInputRef.current?.click()}
              className="p-8 border-2 border-dashed border-slate-700 hover:border-amber-500 bg-slate-950/60 text-center cursor-pointer space-y-2 transition-colors"
            >
              <ShieldCheck className="w-8 h-8 text-amber-400 mx-auto" />
              <div className="text-slate-200 font-semibold">
                {jsonRestoreFileName ? `Selected Backup: ${jsonRestoreFileName}` : 'Select enterprise JSON backup file'}
              </div>
              <p className="text-[11px] text-slate-400">
                Restores complete operational database state (clients, projects, tasks, invoices, expenses, audit ledger).
              </p>
              <input
                ref={jsonInputRef}
                type="file"
                accept=".json,application/json"
                onChange={handleJsonFileChange}
                className="hidden"
              />
            </div>

            {jsonRestoreData && (
              <div className="p-4 bg-slate-950 border border-slate-800 space-y-3">
                <div className="font-bold text-slate-200 flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span>Valid Backup Signature Detected</span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-slate-400 font-mono text-[11px]">
                  <div>Exported: {jsonRestoreData.exportedAt?.substring(0, 10) || 'N/A'}</div>
                  <div>Invoices: {jsonRestoreData.invoices?.length || 0}</div>
                  <div>Tasks: {jsonRestoreData.tasks?.length || 0}</div>
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    onClick={handleApplyJsonRestore}
                    className="px-5 py-2 bg-amber-600 hover:bg-amber-500 text-white font-semibold transition-colors"
                  >
                    Restore Database from JSON Backup
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
