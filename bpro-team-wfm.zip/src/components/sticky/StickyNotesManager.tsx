import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StickyNote, StickyNoteColor } from '../../types';
import { 
  Pin, 
  Plus, 
  Trash2, 
  Download, 
  CheckSquare, 
  Square, 
  Search, 
  Tag, 
  Calendar, 
  Sparkles,
  FileText,
  Filter,
  X,
  User,
  Share2
} from 'lucide-react';
import { Tooltip } from '../common/Tooltip';

const COLOR_STYLES: Record<StickyNoteColor, { bg: string; border: string; text: string; badge: string; accent: string }> = {
  amber: {
    bg: 'bg-amber-950/40 hover:bg-amber-950/50',
    border: 'border-amber-500/40',
    text: 'text-amber-200',
    badge: 'bg-amber-900/60 text-amber-300 border-amber-700/60',
    accent: 'bg-amber-500',
  },
  emerald: {
    bg: 'bg-emerald-950/40 hover:bg-emerald-950/50',
    border: 'border-emerald-500/40',
    text: 'text-emerald-200',
    badge: 'bg-emerald-900/60 text-emerald-300 border-emerald-700/60',
    accent: 'bg-emerald-500',
  },
  sky: {
    bg: 'bg-sky-950/40 hover:bg-sky-950/50',
    border: 'border-sky-500/40',
    text: 'text-sky-200',
    badge: 'bg-sky-900/60 text-sky-300 border-sky-700/60',
    accent: 'bg-sky-500',
  },
  violet: {
    bg: 'bg-purple-950/40 hover:bg-purple-950/50',
    border: 'border-purple-500/40',
    text: 'text-purple-200',
    badge: 'bg-purple-900/60 text-purple-300 border-purple-700/60',
    accent: 'bg-purple-500',
  },
  rose: {
    bg: 'bg-rose-950/40 hover:bg-rose-950/50',
    border: 'border-rose-500/40',
    text: 'text-rose-200',
    badge: 'bg-rose-900/60 text-rose-300 border-rose-700/60',
    accent: 'bg-rose-500',
  },
  indigo: {
    bg: 'bg-indigo-950/40 hover:bg-indigo-950/50',
    border: 'border-indigo-500/40',
    text: 'text-indigo-200',
    badge: 'bg-indigo-900/60 text-indigo-300 border-indigo-700/60',
    accent: 'bg-indigo-500',
  },
};

export const StickyNotesManager: React.FC = () => {
  const { 
    stickyNotes, 
    addStickyNote, 
    updateStickyNote, 
    deleteStickyNote, 
    toggleStickyChecklistItem,
    clients, 
    projects,
    currentUser,
    searchQuery,
    triggerCelebration
  } = useApp();

  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [selectedColorFilter, setSelectedColorFilter] = useState<'all' | StickyNoteColor>('all');
  const [showPinnedOnly, setShowPinnedOnly] = useState(false);

  // Form State
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [color, setColor] = useState<StickyNoteColor>('amber');
  const [isPinned, setIsPinned] = useState(false);
  const [clientId, setClientId] = useState('');
  const [projectId, setProjectId] = useState('');
  const [checklistText, setChecklistText] = useState('');
  const [checklistItems, setChecklistItems] = useState<{ id: string; text: string; completed: boolean }[]>([]);

  const handleAddChecklistItem = () => {
    if (!checklistText.trim()) return;
    setChecklistItems([
      ...checklistItems,
      { id: `chk_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`, text: checklistText.trim(), completed: false }
    ]);
    setChecklistText('');
  };

  const handleCreateNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() && !content.trim()) return;

    addStickyNote({
      title: title.trim() || 'Untitled Note',
      content: content.trim(),
      color,
      isPinned,
      checklist: checklistItems,
      clientId: clientId || undefined,
      projectId: projectId || undefined,
    });

    setTitle('');
    setContent('');
    setColor('amber');
    setIsPinned(false);
    setClientId('');
    setProjectId('');
    setChecklistItems([]);
    setIsCreateOpen(false);
    triggerCelebration();
  };

  const downloadNote = (note: StickyNote, format: 'md' | 'txt' | 'json') => {
    let fileContent = '';
    let fileName = `${note.title.toLowerCase().replace(/[^a-z0-9]/g, '_')}`;
    let mimeType = 'text/plain';

    if (format === 'json') {
      fileContent = JSON.stringify(note, null, 2);
      fileName += '.json';
      mimeType = 'application/json';
    } else if (format === 'md') {
      fileName += '.md';
      mimeType = 'text/markdown';
      fileContent = `# ${note.title}\n\n`;
      fileContent += `**Author:** ${note.authorName}  \n`;
      fileContent += `**Created:** ${new Date(note.createdAt).toLocaleString()}  \n\n`;
      fileContent += `## Notes\n${note.content}\n\n`;
      if (note.checklist?.length) {
        fileContent += `## Checklist\n`;
        note.checklist.forEach(item => {
          fileContent += `- [${item.completed ? 'x' : ' '}] ${item.text}\n`;
        });
      }
    } else {
      fileName += '.txt';
      fileContent = `${note.title.toUpperCase()}\n`;
      fileContent += `Author: ${note.authorName} (${new Date(note.createdAt).toLocaleString()})\n\n`;
      fileContent += `${note.content}\n\n`;
      if (note.checklist?.length) {
        fileContent += `CHECKLIST:\n`;
        note.checklist.forEach(item => {
          fileContent += `[${item.completed ? 'X' : ' '}] ${item.text}\n`;
        });
      }
    }

    const blob = new Blob([fileContent], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const filteredNotes = stickyNotes.filter(n => {
    if (selectedColorFilter !== 'all' && n.color !== selectedColorFilter) return false;
    if (showPinnedOnly && !n.isPinned) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = n.title.toLowerCase().includes(q);
      const matchContent = n.content.toLowerCase().includes(q);
      const matchAuthor = n.authorName.toLowerCase().includes(q);
      const matchChecklist = n.checklist?.some(item => item.text.toLowerCase().includes(q));
      if (!matchTitle && !matchContent && !matchAuthor && !matchChecklist) return false;
    }
    return true;
  });

  // Sort pinned first
  const sortedNotes = [...filteredNotes].sort((a, b) => {
    if (a.isPinned && !b.isPinned) return -1;
    if (!a.isPinned && b.isPinned) return 1;
    return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
  });

  return (
    <div className="space-y-6">
      {/* Top Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              <span className="p-1 bg-amber-500/10 border border-amber-500/30 text-amber-400">
                <Pin className="w-4 h-4" />
              </span>
              <span>Collaborative Sticky Notes & Scratchpad</span>
            </h1>
            <span className="text-[10px] font-mono font-semibold px-2 py-0.5 bg-indigo-950/80 text-indigo-300 border border-indigo-700/60">
              LIVE PERSISTENCE
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Pin executive reminders, sprint thoughts, checklists, and project scratchpads. Instant 1-click download in Markdown or Text.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <Tooltip content="Create new vibrant sticky note with interactive checklist" shortcut="Alt+N">
            <button
              onClick={() => setIsCreateOpen(true)}
              className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-lg shadow-amber-950/40"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Sticky Note</span>
            </button>
          </Tooltip>
        </div>
      </div>

      {/* Filter & Palette Bar */}
      <div className="p-3 bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <span className="text-slate-400 text-[11px] font-medium flex items-center gap-1">
            <Filter className="w-3.5 h-3.5 text-amber-400" />
            <span>Palette Filter:</span>
          </span>

          <div className="flex items-center gap-1">
            <button
              onClick={() => setSelectedColorFilter('all')}
              className={`px-2 py-1 text-[11px] transition-colors ${
                selectedColorFilter === 'all'
                  ? 'bg-slate-800 text-white font-semibold border border-slate-600'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All Colors
            </button>
            {(['amber', 'emerald', 'sky', 'violet', 'rose', 'indigo'] as StickyNoteColor[]).map((c) => (
              <button
                key={c}
                onClick={() => setSelectedColorFilter(c)}
                className={`w-5 h-5 transition-transform ${COLOR_STYLES[c].accent} ${
                  selectedColorFilter === c ? 'scale-125 ring-2 ring-white' : 'opacity-70 hover:opacity-100'
                }`}
                title={`Filter ${c}`}
              />
            ))}
          </div>
        </div>

        <div className="flex items-center gap-3">
          <label className="flex items-center gap-1.5 text-slate-300 text-[11px] cursor-pointer">
            <input
              type="checkbox"
              checked={showPinnedOnly}
              onChange={(e) => setShowPinnedOnly(e.target.checked)}
              className="accent-amber-500"
            />
            <span>Pinned only</span>
          </label>
          <span className="text-slate-500 font-mono text-[11px]">
            {sortedNotes.length} {sortedNotes.length === 1 ? 'note' : 'notes'} visible
          </span>
        </div>
      </div>

      {/* Sticky Notes Grid */}
      {sortedNotes.length === 0 ? (
        <div className="p-12 text-center bg-slate-900/60 border border-dashed border-slate-800 space-y-3">
          <Pin className="w-8 h-8 text-slate-600 mx-auto" />
          <div className="text-sm font-semibold text-slate-300">No Sticky Notes Found</div>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Create color-coded scratchpads with checklists to track immediate priorities, ideas, and reminders.
          </p>
          <button
            onClick={() => setIsCreateOpen(true)}
            className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold transition-colors"
          >
            Create Your First Note
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {sortedNotes.map((note) => {
            const styles = COLOR_STYLES[note.color] || COLOR_STYLES.amber;
            const client = clients.find(c => c.id === note.clientId);
            const project = projects.find(p => p.id === note.projectId);
            const checklist = note.checklist || [];
            const completedCount = checklist.filter(c => c.completed).length;

            return (
              <div
                key={note.id}
                className={`p-4 border transition-all duration-200 flex flex-col justify-between relative shadow-lg ${styles.bg} ${styles.border} ${
                  note.isPinned ? 'ring-1 ring-amber-400/30' : ''
                }`}
              >
                {/* Note Top Bar */}
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h3 className={`font-bold text-sm leading-snug break-words ${styles.text}`}>
                      {note.title}
                    </h3>
                    <div className="flex items-center gap-1 shrink-0">
                      <Tooltip content={note.isPinned ? "Unpin note" : "Pin note to top"}>
                        <button
                          onClick={() => updateStickyNote(note.id, { isPinned: !note.isPinned })}
                          className={`p-1 transition-colors ${
                            note.isPinned ? 'text-amber-400' : 'text-slate-500 hover:text-slate-300'
                          }`}
                        >
                          <Pin className="w-3.5 h-3.5" />
                        </button>
                      </Tooltip>
                      <Tooltip content="Delete sticky note">
                        <button
                          onClick={() => deleteStickyNote(note.id)}
                          className="p-1 text-slate-500 hover:text-rose-400 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </Tooltip>
                    </div>
                  </div>

                  {/* Body Content */}
                  {note.content && (
                    <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-wrap mb-3 font-sans">
                      {note.content}
                    </p>
                  )}

                  {/* Checklist if any */}
                  {checklist.length > 0 && (
                    <div className="space-y-1.5 pt-2 pb-2 border-t border-slate-800/60 mb-2">
                      <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono mb-1">
                        <span>Checklist</span>
                        <span>{completedCount}/{checklist.length} fulfilled</span>
                      </div>
                      {checklist.map((item) => (
                        <div
                          key={item.id}
                          onClick={() => toggleStickyChecklistItem(note.id, item.id)}
                          className="flex items-start gap-2 text-xs cursor-pointer group hover:bg-slate-900/40 p-1 transition-colors"
                        >
                          {item.completed ? (
                            <CheckSquare className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                          ) : (
                            <Square className="w-3.5 h-3.5 text-slate-500 group-hover:text-slate-300 shrink-0 mt-0.5" />
                          )}
                          <span className={`text-[11px] leading-tight select-none ${
                            item.completed ? 'line-through text-slate-500' : 'text-slate-200'
                          }`}>
                            {item.text}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Project / Client Tags */}
                  {(client || project) && (
                    <div className="flex flex-wrap gap-1.5 mb-3 text-[10px] font-mono">
                      {client && (
                        <span className="px-1.5 py-0.5 bg-slate-950/80 text-slate-300 border border-slate-800">
                          Client: {client.company || client.name}
                        </span>
                      )}
                      {project && (
                        <span className="px-1.5 py-0.5 bg-indigo-950/80 text-indigo-300 border border-indigo-800/80">
                          {project.code}
                        </span>
                      )}
                    </div>
                  )}
                </div>

                {/* Footer Metadata & Download Provision */}
                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400">
                  <div className="flex items-center gap-1.5 truncate max-w-[160px]">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" />
                    <span className="truncate">{note.authorName}</span>
                    <span className="text-slate-600">&bull;</span>
                    <span className="font-mono text-slate-500">{new Date(note.updatedAt).toLocaleDateString([], { month: 'short', day: 'numeric' })}</span>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <Tooltip content="Download note as Markdown (.md)">
                      <button
                        onClick={() => downloadNote(note, 'md')}
                        className="px-1.5 py-0.5 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 text-[10px] font-mono font-medium flex items-center gap-1 transition-colors"
                      >
                        <Download className="w-2.5 h-2.5 text-indigo-400" />
                        <span>MD</span>
                      </button>
                    </Tooltip>
                    <Tooltip content="Download note as Plain Text (.txt)">
                      <button
                        onClick={() => downloadNote(note, 'txt')}
                        className="px-1.5 py-0.5 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 text-[10px] font-mono font-medium flex items-center gap-1 transition-colors"
                      >
                        <Download className="w-2.5 h-2.5 text-emerald-400" />
                        <span>TXT</span>
                      </button>
                    </Tooltip>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Create Modal */}
      {isCreateOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-lg shadow-2xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <Pin className="w-4 h-4 text-amber-400" />
                <span>Create New Executive Sticky Note</span>
              </h2>
              <button onClick={() => setIsCreateOpen(false)} className="text-slate-400 hover:text-slate-200">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateNote} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Title / Summary</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Critical Hospital FHIR HL7 Review"
                  className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Color Palette</label>
                <div className="flex items-center gap-2">
                  {(['amber', 'emerald', 'sky', 'violet', 'rose', 'indigo'] as StickyNoteColor[]).map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setColor(c)}
                      className={`w-7 h-7 transition-all ${COLOR_STYLES[c].accent} ${
                        color === c ? 'scale-110 ring-2 ring-white ring-offset-2 ring-offset-slate-900' : 'opacity-80 hover:opacity-100'
                      }`}
                    />
                  ))}
                  <span className="text-[11px] font-mono text-slate-400 capitalize ml-2">{color} palette</span>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Note Content & Details</label>
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  rows={3}
                  placeholder="Type executive remarks, observations, or action items..."
                  className="w-full bg-slate-950 border border-slate-700 p-2.5 text-slate-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Checklist Builder */}
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Checklist Items</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={checklistText}
                    onChange={(e) => setChecklistText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddChecklistItem();
                      }
                    }}
                    placeholder="Add to-do item and press Enter..."
                    className="flex-1 bg-slate-950 border border-slate-700 px-3 py-1.5 text-slate-100"
                  />
                  <button
                    type="button"
                    onClick={handleAddChecklistItem}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700"
                  >
                    Add
                  </button>
                </div>

                {checklistItems.length > 0 && (
                  <div className="space-y-1 mt-2 p-2 bg-slate-950 border border-slate-800">
                    {checklistItems.map((item, idx) => (
                      <div key={item.id} className="flex items-center justify-between text-[11px] text-slate-300">
                        <span>• {item.text}</span>
                        <button
                          type="button"
                          onClick={() => setChecklistItems(checklistItems.filter((_, i) => i !== idx))}
                          className="text-slate-500 hover:text-rose-400"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Affiliations */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Link Client (Optional)</label>
                  <select
                    value={clientId}
                    onChange={(e) => setClientId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 p-2 text-slate-300"
                  >
                    <option value="">None</option>
                    {clients.map(c => (
                      <option key={c.id} value={c.id}>{c.company || c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Link Project (Optional)</label>
                  <select
                    value={projectId}
                    onChange={(e) => setProjectId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 p-2 text-slate-300"
                  >
                    <option value="">None</option>
                    {projects.map(p => (
                      <option key={p.id} value={p.id}>{p.code} - {p.title}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="pinNoteCheck"
                  checked={isPinned}
                  onChange={(e) => setIsPinned(e.target.checked)}
                  className="accent-amber-500"
                />
                <label htmlFor="pinNoteCheck" className="text-slate-300 font-medium cursor-pointer">
                  Pin this note to the top of the scratchpad
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCreateOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-600 hover:bg-amber-500 text-white font-semibold transition-colors shadow-sm"
                >
                  Pin Note
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
