import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StickyNoteColor } from '../../types';
import { 
  Pin, 
  Plus, 
  Trash2, 
  CheckSquare, 
  Square, 
  Search, 
  X, 
  Maximize2,
  Sparkles,
  Download
} from 'lucide-react';
import { Tooltip } from '../common/Tooltip';

const COLOR_STYLES: Record<StickyNoteColor, { bg: string; border: string; text: string; badge: string; accent: string }> = {
  amber: {
    bg: 'bg-amber-950/40 hover:bg-amber-950/60',
    border: 'border-amber-500/40',
    text: 'text-amber-200',
    badge: 'bg-amber-900/60 text-amber-300 border-amber-700/60',
    accent: 'bg-amber-500',
  },
  emerald: {
    bg: 'bg-emerald-950/40 hover:bg-emerald-950/60',
    border: 'border-emerald-500/40',
    text: 'text-emerald-200',
    badge: 'bg-emerald-900/60 text-emerald-300 border-emerald-700/60',
    accent: 'bg-emerald-500',
  },
  sky: {
    bg: 'bg-sky-950/40 hover:bg-sky-950/60',
    border: 'border-sky-500/40',
    text: 'text-sky-200',
    badge: 'bg-sky-900/60 text-sky-300 border-sky-700/60',
    accent: 'bg-sky-500',
  },
  violet: {
    bg: 'bg-purple-950/40 hover:bg-purple-950/60',
    border: 'border-purple-500/40',
    text: 'text-purple-200',
    badge: 'bg-purple-900/60 text-purple-300 border-purple-700/60',
    accent: 'bg-purple-500',
  },
  rose: {
    bg: 'bg-rose-950/40 hover:bg-rose-950/60',
    border: 'border-rose-500/40',
    text: 'text-rose-200',
    badge: 'bg-rose-900/60 text-rose-300 border-rose-700/60',
    accent: 'bg-rose-500',
  },
  indigo: {
    bg: 'bg-indigo-950/40 hover:bg-indigo-950/60',
    border: 'border-indigo-500/40',
    text: 'text-indigo-200',
    badge: 'bg-indigo-900/60 text-indigo-300 border-indigo-700/60',
    accent: 'bg-indigo-500',
  },
};

export const StickyQuickDrawer: React.FC = () => {
  const { 
    stickyNotes, 
    addStickyNote, 
    updateStickyNote, 
    deleteStickyNote, 
    toggleStickyChecklistItem,
    isStickyDrawerOpen, 
    setIsStickyDrawerOpen,
    setActiveTab,
    triggerCelebration
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newColor, setNewColor] = useState<StickyNoteColor>('amber');
  const [newChecklistText, setNewChecklistText] = useState('');

  if (!isStickyDrawerOpen) return null;

  const handleCreateQuickNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() && !newContent.trim()) return;

    const checklistItems = newChecklistText
      .split('\n')
      .map(line => line.trim())
      .filter(Boolean)
      .map(text => ({
        id: `chk_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        text,
        completed: false
      }));

    addStickyNote({
      title: newTitle.trim() || 'Quick Scratchpad Note',
      content: newContent.trim(),
      color: newColor,
      isPinned: true,
      checklist: checklistItems,
    });

    setNewTitle('');
    setNewContent('');
    setNewChecklistText('');
    setIsAdding(false);
    triggerCelebration();
  };

  const filteredNotes = stickyNotes.filter(n => {
    const q = searchQuery.toLowerCase();
    return n.title.toLowerCase().includes(q) || 
      n.content.toLowerCase().includes(q) ||
      n.checklist.some(c => c.text.toLowerCase().includes(q));
  });

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-md bg-slate-900 border-l border-slate-700 flex flex-col h-full shadow-2xl">
        {/* Drawer Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-amber-500/10 border border-amber-500/30 text-amber-400">
              <Pin className="w-4 h-4" />
            </span>
            <div>
              <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider font-mono">
                Sticky Notes Dock
              </h2>
              <p className="text-[11px] text-slate-400">Persistent live scratchpad</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <Tooltip content="Open Full Sticky Notes Board">
              <button
                onClick={() => {
                  setIsStickyDrawerOpen(false);
                  setActiveTab('sticky');
                }}
                className="p-1.5 text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
              >
                <Maximize2 className="w-4 h-4" />
              </button>
            </Tooltip>
            <button
              onClick={() => setIsStickyDrawerOpen(false)}
              className="p-1.5 text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Search & Actions Bar */}
        <div className="p-3 border-b border-slate-800/80 bg-slate-900/60 space-y-2">
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search scratchpad notes..."
                className="w-full bg-slate-950 border border-slate-800 pl-8 pr-2 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>
            <button
              onClick={() => setIsAdding(!isAdding)}
              className="px-2.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold font-mono uppercase transition-colors flex items-center gap-1 shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isAdding ? 'Cancel' : 'New Note'}</span>
            </button>
          </div>

          {/* Quick Create Form */}
          {isAdding && (
            <form onSubmit={handleCreateQuickNote} className="p-3 bg-slate-950 border border-amber-500/40 space-y-2.5 animate-in slide-in-from-top-2">
              <input
                type="text"
                placeholder="Note Title..."
                value={newTitle}
                onChange={e => setNewTitle(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 px-2 py-1 text-xs text-slate-100 focus:outline-none focus:border-amber-400"
                autoFocus
              />
              <textarea
                placeholder="Write your note or thoughts..."
                value={newContent}
                onChange={e => setNewContent(e.target.value)}
                rows={3}
                className="w-full bg-slate-900 border border-slate-800 p-2 text-xs text-slate-200 focus:outline-none focus:border-amber-400 resize-none"
              />
              <textarea
                placeholder="Checklist items (one per line, optional)..."
                value={newChecklistText}
                onChange={e => setNewChecklistText(e.target.value)}
                rows={2}
                className="w-full bg-slate-900 border border-slate-800 p-2 text-[11px] text-slate-300 font-mono focus:outline-none focus:border-amber-400 resize-none"
              />
              
              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center gap-1.5">
                  {(['amber', 'emerald', 'sky', 'violet', 'rose', 'indigo'] as StickyNoteColor[]).map(c => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setNewColor(c)}
                      className={`w-4 h-4 ${COLOR_STYLES[c].accent} ${newColor === c ? 'ring-2 ring-white scale-110' : 'opacity-70 hover:opacity-100'} transition-all`}
                    />
                  ))}
                </div>
                <button
                  type="submit"
                  className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold font-mono uppercase"
                >
                  Save Note
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Notes List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {filteredNotes.length === 0 ? (
            <div className="text-center py-12 text-slate-500 space-y-2">
              <Pin className="w-8 h-8 mx-auto text-slate-700" />
              <p className="text-xs">No sticky notes found</p>
              <button
                onClick={() => setIsAdding(true)}
                className="text-[11px] text-amber-400 hover:underline font-mono"
              >
                + Create your first scratchpad note
              </button>
            </div>
          ) : (
            filteredNotes.map(note => {
              const styles = COLOR_STYLES[note.color];
              return (
                <div
                  key={note.id}
                  className={`p-3.5 border transition-all relative ${styles.bg} ${styles.border} ${
                    note.isPinned ? 'ring-1 ring-amber-400/30' : ''
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <h3 className={`font-bold text-xs leading-snug break-words ${styles.text}`}>
                      {note.title}
                    </h3>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => updateStickyNote(note.id, { isPinned: !note.isPinned })}
                        className={`p-0.5 transition-colors ${
                          note.isPinned ? 'text-amber-400' : 'text-slate-600 hover:text-slate-400'
                        }`}
                        title={note.isPinned ? 'Unpin' : 'Pin to top'}
                      >
                        <Pin className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => deleteStickyNote(note.id)}
                        className="p-0.5 text-slate-600 hover:text-rose-400 transition-colors"
                        title="Delete note"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {note.content && (
                    <p className="text-[11px] text-slate-300 whitespace-pre-wrap leading-relaxed mb-2">
                      {note.content}
                    </p>
                  )}

                  {/* Checklist */}
                  {note.checklist.length > 0 && (
                    <div className="space-y-1 my-2 pt-2 border-t border-slate-800/60">
                      {note.checklist.map(item => (
                        <div
                          key={item.id}
                          onClick={() => toggleStickyChecklistItem(note.id, item.id)}
                          className="flex items-center gap-2 cursor-pointer group py-0.5"
                        >
                          {item.completed ? (
                            <CheckSquare className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          ) : (
                            <Square className="w-3.5 h-3.5 text-slate-500 group-hover:text-slate-300 shrink-0" />
                          )}
                          <span
                            className={`text-[11px] leading-tight select-none ${
                              item.completed
                                ? 'line-through text-slate-500'
                                : 'text-slate-200 group-hover:text-white'
                            }`}
                          >
                            {item.text}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="flex items-center justify-between text-[10px] text-slate-500 pt-2 border-t border-slate-800/40 font-mono">
                    <span>{note.authorName}</span>
                    <span>{new Date(note.updatedAt).toLocaleDateString()}</span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Drawer Footer */}
        <div className="p-3 border-t border-slate-800 bg-slate-950 flex items-center justify-between text-xs">
          <span className="text-[11px] text-slate-500 font-mono">
            {stickyNotes.length} scratchpad notes saved
          </span>
          <button
            onClick={() => {
              setIsStickyDrawerOpen(false);
              setActiveTab('sticky');
            }}
            className="text-[11px] text-indigo-400 hover:text-indigo-300 font-mono font-medium flex items-center gap-1"
          >
            Open Full Canvas &rarr;
          </button>
        </div>
      </div>
    </div>
  );
};
