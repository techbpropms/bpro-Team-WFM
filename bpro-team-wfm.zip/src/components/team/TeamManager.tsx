import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TeamMember, UserRole, UserPermissions } from '../../types';
import { 
  UserCheck, 
  UserPlus, 
  Shield, 
  Lock, 
  Check, 
  Mail, 
  Phone, 
  MapPin, 
  Briefcase, 
  Globe, 
  Linkedin, 
  Github, 
  Twitter, 
  Crown, 
  Edit3, 
  Sparkles, 
  IndianRupee, 
  Award, 
  X,
  Save,
  CheckCircle2,
  ExternalLink
} from 'lucide-react';

const AVATAR_PRESETS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
];

export const TeamManager: React.FC = () => {
  const { allTeamMembers, currentUser, inviteTeamMember, updateMemberProfile, switchUser, formatCurrency } = useApp();

  const [isInviteOpen, setIsInviteOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<TeamMember | null>(null);

  // Invite Form State
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<UserRole>('external_consultant');
  const [designation, setDesignation] = useState('Senior Cloud Architect');
  const [department, setDepartment] = useState('Engineering & Architecture');
  const [isExternal, setIsExternal] = useState(true);
  const [consultantOrg, setConsultantOrg] = useState('Ross Cloud Advisory India Pvt Ltd');
  const [hourlyRate, setHourlyRate] = useState(3500);

  // Profile Edit Form State
  const [profileForm, setProfileForm] = useState<Partial<TeamMember>>({});

  const isSuperAdminEmail = (email: string) => {
    const e = email.toLowerCase();
    return e === 'drbabukollam@gmail.com' || e === 'drbabukoillam@gmail.com' || e === 'tech@bropms.com';
  };

  const getDefaultPermissionsForRole = (r: UserRole): UserPermissions => {
    switch (r) {
      case 'super_admin':
      case 'admin':
        return {
          canManageClients: true,
          canManageProjects: true,
          canAssignTasks: true,
          canEditDeadlines: true,
          canViewFinancials: true,
          canCreateInvoices: true,
          canApproveExpenses: true,
          canManageTeam: true,
          canManageIntegrations: true,
          canExportReports: true,
          canManageSettings: true,
        };
      case 'project_manager':
        return {
          canManageClients: true,
          canManageProjects: true,
          canAssignTasks: true,
          canEditDeadlines: true,
          canViewFinancials: true,
          canCreateInvoices: true,
          canApproveExpenses: true,
          canManageTeam: false,
          canManageIntegrations: true,
          canExportReports: true,
          canManageSettings: false,
        };
      case 'external_consultant':
        return {
          canManageClients: false,
          canManageProjects: false,
          canAssignTasks: false,
          canEditDeadlines: true,
          canViewFinancials: false,
          canCreateInvoices: false,
          canApproveExpenses: false,
          canManageTeam: false,
          canManageIntegrations: false,
          canExportReports: false,
          canManageSettings: false,
        };
      case 'client_stakeholder':
        return {
          canManageClients: false,
          canManageProjects: false,
          canAssignTasks: false,
          canEditDeadlines: false,
          canViewFinancials: true,
          canCreateInvoices: false,
          canApproveExpenses: false,
          canManageTeam: false,
          canManageIntegrations: false,
          canExportReports: true,
          canManageSettings: false,
        };
      default: // team_member
        return {
          canManageClients: false,
          canManageProjects: false,
          canAssignTasks: false,
          canEditDeadlines: true,
          canViewFinancials: false,
          canCreateInvoices: false,
          canApproveExpenses: false,
          canManageTeam: false,
          canManageIntegrations: false,
          canExportReports: false,
          canManageSettings: false,
        };
    }
  };

  const [permissions, setPermissions] = useState<UserPermissions>(getDefaultPermissionsForRole('external_consultant'));

  const handleRoleChange = (newRole: UserRole) => {
    setRole(newRole);
    setIsExternal(newRole === 'external_consultant' || newRole === 'client_stakeholder');
    setPermissions(getDefaultPermissionsForRole(newRole));
  };

  const handleInvite = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim()) return;

    inviteTeamMember({
      name: name.trim(),
      email: email.trim(),
      avatarUrl: `https://images.unsplash.com/photo-${1530000000000 + Math.floor(Math.random() * 9999999)}?w=150&auto=format&fit=crop&q=80`,
      role,
      isExternal,
      designation: designation.trim(),
      department: department.trim(),
      consultantOrg: isExternal ? consultantOrg : undefined,
      hourlyRate: Number(hourlyRate) || 2500,
      permissions,
      activeStatus: 'active',
      assignedProjectIds: [],
    });

    setIsInviteOpen(false);
    setName('');
    setEmail('');
  };

  const openEditModal = (member: TeamMember) => {
    setEditingMember(member);
    setProfileForm({
      ...member,
      skills: member.skills || [],
      certifications: member.certifications || [],
    });
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingMember) return;

    updateMemberProfile(editingMember.id, profileForm);
    setEditingMember(null);
  };

  const roleBadges: Record<UserRole, { label: string; style: string }> = {
    super_admin: { label: 'Super Admin', style: 'bg-amber-500/10 text-amber-300 border-amber-500/40 font-bold' },
    admin: { label: 'Admin', style: 'bg-indigo-950/80 text-indigo-400 border-indigo-800' },
    project_manager: { label: 'Project Manager', style: 'bg-emerald-950/80 text-emerald-400 border-emerald-800' },
    team_member: { label: 'Team Member', style: 'bg-sky-950/80 text-sky-400 border-sky-800' },
    external_consultant: { label: 'External Consultant', style: 'bg-amber-950/80 text-amber-400 border-amber-800' },
    client_stakeholder: { label: 'Client Stakeholder', style: 'bg-purple-950/80 text-purple-400 border-purple-800' },
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950/40 border border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-indigo-400" />
            <h1 className="text-lg font-bold text-slate-100">Team & Consultant Credentials Directory</h1>
            <span className="px-2 py-0.5 text-[10px] font-mono bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold">
              RBAC GOVERNED (INR ₹)
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Super Admins (<strong className="text-slate-200">drbabukollam@gmail.com</strong> & <strong className="text-slate-200">tech@bropms.com</strong>) have supreme authority; all others follow role-based approvals.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Quick Profile Edit for Current User */}
          <button
            onClick={() => openEditModal(currentUser)}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Edit3 className="w-3.5 h-3.5 text-indigo-400" />
            <span>Edit My Profile</span>
          </button>

          <button
            onClick={() => setIsInviteOpen(true)}
            className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Invite Member / Consultant</span>
          </button>
        </div>
      </div>

      {/* Team Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {allTeamMembers.map((member) => {
          const isSuper = member.role === 'super_admin' || isSuperAdminEmail(member.email);
          const isCurrent = member.id === currentUser.id;

          return (
            <div
              key={member.id}
              className={`bg-slate-900 border p-5 space-y-4 transition-all flex flex-col justify-between ${
                isSuper ? 'border-amber-500/50 shadow-md shadow-amber-950/20' : 'border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="space-y-3">
                {/* Header Profile Row */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <img
                        src={member.avatarUrl}
                        alt={member.name}
                        className="w-12 h-12 rounded-none border border-slate-700 object-cover"
                      />
                      {isSuper && (
                        <div className="absolute -top-1.5 -right-1.5 p-0.5 bg-amber-500 text-slate-950 shadow-sm" title="Super Administrator">
                          <Crown className="w-3.5 h-3.5" />
                        </div>
                      )}
                    </div>
                    <div>
                      <h2 className="text-sm font-bold text-slate-100 flex items-center gap-1.5">
                        <span>{member.name}</span>
                        {isCurrent && (
                          <span className="text-[9px] font-mono px-1 py-0.2 bg-indigo-500 text-white font-bold">YOU</span>
                        )}
                      </h2>
                      <div className="text-xs text-slate-400 font-medium">
                        {member.designation || member.role.replace('_', ' ')}
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono mt-0.5">{member.email}</div>
                    </div>
                  </div>

                  <span className={`px-2 py-0.5 text-[10px] uppercase font-mono font-bold border ${roleBadges[member.role]?.style || 'border-slate-700'}`}>
                    {roleBadges[member.role]?.label || member.role}
                  </span>
                </div>

                {/* Bio / Description */}
                {member.bio && (
                  <p className="text-xs text-slate-400 leading-relaxed line-clamp-2 italic bg-slate-950/60 p-2 border border-slate-800/80">
                    "{member.bio}"
                  </p>
                )}

                {/* Personal & Professional Meta */}
                <div className="space-y-1.5 text-xs text-slate-400">
                  {member.location && (
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                      <span>{member.location}</span>
                    </div>
                  )}
                  {member.phone && (
                    <div className="flex items-center gap-2 font-mono">
                      <Phone className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                      <span>{member.phone}</span>
                    </div>
                  )}
                  {member.consultantOrg && (
                    <div className="flex items-center gap-2 text-amber-300 font-medium">
                      <Briefcase className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span className="truncate">{member.consultantOrg}</span>
                    </div>
                  )}
                </div>

                {/* Hourly Rate & Financials */}
                <div className="p-2.5 bg-slate-950 border border-slate-800 flex items-center justify-between font-mono text-xs">
                  <span className="text-slate-500 uppercase text-[10px]">Contract Rate:</span>
                  <span className="text-emerald-400 font-bold">
                    {formatCurrency(member.hourlyRate || 3500)} / hr
                  </span>
                </div>

                {/* Social Profiles */}
                {(member.linkedIn || member.github || member.twitter || member.portfolio) && (
                  <div className="flex items-center gap-2 pt-1">
                    <span className="text-[10px] font-mono text-slate-500 uppercase">Profiles:</span>
                    {member.linkedIn && (
                      <a href={member.linkedIn} target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-indigo-400 p-1" title="LinkedIn">
                        <Linkedin className="w-3.5 h-3.5" />
                      </a>
                    )}
                    {member.github && (
                      <a href={member.github} target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-white p-1" title="GitHub">
                        <Github className="w-3.5 h-3.5" />
                      </a>
                    )}
                    {member.twitter && (
                      <a href={member.twitter} target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-sky-400 p-1" title="Twitter/X">
                        <Twitter className="w-3.5 h-3.5" />
                      </a>
                    )}
                    {member.portfolio && (
                      <a href={member.portfolio} target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-emerald-400 p-1" title="Portfolio">
                        <Globe className="w-3.5 h-3.5" />
                      </a>
                    )}
                  </div>
                )}

                {/* Skills & Certifications */}
                {member.skills && member.skills.length > 0 && (
                  <div className="flex flex-wrap gap-1 pt-1">
                    {member.skills.map((s, idx) => (
                      <span key={idx} className="text-[10px] font-mono px-1.5 py-0.2 bg-slate-950 text-slate-400 border border-slate-800">
                        {s}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* Bottom Actions */}
              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs gap-2">
                <button
                  onClick={() => openEditModal(member)}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs font-medium transition-colors flex items-center gap-1"
                >
                  <Edit3 className="w-3 h-3 text-indigo-400" />
                  <span>Edit Profile</span>
                </button>

                <button
                  onClick={() => switchUser(member.id)}
                  className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800 text-xs font-medium transition-colors"
                >
                  Switch Perspective
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Professional Profile Editor Modal */}
      {editingMember && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-2xl shadow-2xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-indigo-400" />
                <h2 className="text-sm font-bold text-slate-100">
                  Edit Professional Credentials & Social Profile ({editingMember.name})
                </h2>
              </div>
              <button onClick={() => setEditingMember(null)} className="text-slate-400 hover:text-slate-200">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-4 text-xs">
              {/* Photo & Basic Details */}
              <div className="p-3 bg-slate-950 border border-slate-800 space-y-3">
                <span className="text-xs font-bold text-slate-200 uppercase tracking-wider block">
                  1. Profile Photo & Core Details
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-center">
                  <div className="flex items-center gap-3">
                    <img
                      src={profileForm.avatarUrl || editingMember.avatarUrl}
                      alt=""
                      className="w-14 h-14 border border-slate-700 object-cover shrink-0 shadow-md"
                    />
                    <div className="text-[11px] text-slate-400">
                      Live Photo Preview
                    </div>
                  </div>

                  <div className="sm:col-span-2 space-y-2">
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">Avatar / Photo Image URL</label>
                      <input
                        type="url"
                        value={profileForm.avatarUrl || ''}
                        onChange={(e) => setProfileForm({ ...profileForm, avatarUrl: e.target.value })}
                        placeholder="https://images.unsplash.com/..."
                        className="w-full bg-slate-900 border border-slate-700 px-3 py-1.5 text-slate-100 text-xs font-mono"
                      />
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block mb-1">Or choose a professional preset photo:</span>
                      <div className="flex items-center gap-2">
                        {AVATAR_PRESETS.map((url, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => setProfileForm({ ...profileForm, avatarUrl: url })}
                            className={`w-7 h-7 border transition-transform hover:scale-110 overflow-hidden ${
                              profileForm.avatarUrl === url ? 'ring-2 ring-indigo-500 border-white' : 'border-slate-700 opacity-70 hover:opacity-100'
                            }`}
                          >
                            <img src={url} alt="" className="w-full h-full object-cover" />
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Full Legal Name *</label>
                    <input
                      type="text"
                      value={profileForm.name || ''}
                      onChange={(e) => setProfileForm({ ...profileForm, name: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 px-3 py-1.5 text-slate-100"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Designation / Executive Title *</label>
                    <input
                      type="text"
                      value={profileForm.designation || ''}
                      onChange={(e) => setProfileForm({ ...profileForm, designation: e.target.value })}
                      placeholder="e.g. Chief Operations Officer, Senior Cloud Consultant"
                      className="w-full bg-slate-900 border border-slate-700 px-3 py-1.5 text-slate-100"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Department</label>
                    <input
                      type="text"
                      value={profileForm.department || ''}
                      onChange={(e) => setProfileForm({ ...profileForm, department: e.target.value })}
                      placeholder="e.g. Core Engineering, Leadership"
                      className="w-full bg-slate-900 border border-slate-700 px-3 py-1.5 text-slate-100"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Phone Number</label>
                    <input
                      type="text"
                      value={profileForm.phone || ''}
                      onChange={(e) => setProfileForm({ ...profileForm, phone: e.target.value })}
                      placeholder="+91 98470 12345"
                      className="w-full bg-slate-900 border border-slate-700 px-3 py-1.5 text-slate-100 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Location / Base City</label>
                    <input
                      type="text"
                      value={profileForm.location || ''}
                      onChange={(e) => setProfileForm({ ...profileForm, location: e.target.value })}
                      placeholder="e.g. Kollam / Bangalore"
                      className="w-full bg-slate-900 border border-slate-700 px-3 py-1.5 text-slate-100"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Executive Bio / Specialization Statement</label>
                    <textarea
                      value={profileForm.bio || ''}
                      onChange={(e) => setProfileForm({ ...profileForm, bio: e.target.value })}
                      rows={2}
                      placeholder="Brief summary of domain expertise, career highlights, and role overview..."
                      className="w-full bg-slate-900 border border-slate-700 p-2 text-slate-100"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Emergency Contact & Relationship</label>
                    <input
                      type="text"
                      value={profileForm.emergencyContact || ''}
                      onChange={(e) => setProfileForm({ ...profileForm, emergencyContact: e.target.value })}
                      placeholder="+91 98470 54321 (Office Admin / Spouse)"
                      className="w-full bg-slate-900 border border-slate-700 px-3 py-2 text-slate-100 font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Social Logins & Online Profiles */}
              <div className="p-3 bg-slate-950 border border-slate-800 space-y-3">
                <span className="text-xs font-bold text-slate-200 uppercase tracking-wider block">
                  2. Social Logins & Online Professional Links
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1 flex items-center gap-1">
                      <Linkedin className="w-3.5 h-3.5 text-indigo-400" />
                      <span>LinkedIn Profile URL</span>
                    </label>
                    <input
                      type="url"
                      value={profileForm.linkedIn || ''}
                      onChange={(e) => setProfileForm({ ...profileForm, linkedIn: e.target.value })}
                      placeholder="https://linkedin.com/in/username"
                      className="w-full bg-slate-900 border border-slate-700 px-3 py-1.5 text-slate-100 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-semibold mb-1 flex items-center gap-1">
                      <Github className="w-3.5 h-3.5 text-slate-300" />
                      <span>GitHub Handle / URL</span>
                    </label>
                    <input
                      type="text"
                      value={profileForm.github || ''}
                      onChange={(e) => setProfileForm({ ...profileForm, github: e.target.value })}
                      placeholder="https://github.com/username"
                      className="w-full bg-slate-900 border border-slate-700 px-3 py-1.5 text-slate-100 font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1 flex items-center gap-1">
                      <Twitter className="w-3.5 h-3.5 text-sky-400" />
                      <span>Twitter / X Handle</span>
                    </label>
                    <input
                      type="text"
                      value={profileForm.twitter || ''}
                      onChange={(e) => setProfileForm({ ...profileForm, twitter: e.target.value })}
                      placeholder="https://twitter.com/username"
                      className="w-full bg-slate-900 border border-slate-700 px-3 py-1.5 text-slate-100 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-semibold mb-1 flex items-center gap-1">
                      <Globe className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Portfolio / Corporate Website</span>
                    </label>
                    <input
                      type="url"
                      value={profileForm.portfolio || ''}
                      onChange={(e) => setProfileForm({ ...profileForm, portfolio: e.target.value })}
                      placeholder="https://bropms.com"
                      className="w-full bg-slate-900 border border-slate-700 px-3 py-1.5 text-slate-100 font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Professional Technical Qualifications & Financials */}
              <div className="p-3 bg-slate-950 border border-slate-800 space-y-3">
                <span className="text-xs font-bold text-slate-200 uppercase tracking-wider block">
                  3. Technical Qualifications & Indian Tax/Financial Rates
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Contract Hourly Billing Rate (INR ₹)</label>
                    <input
                      type="number"
                      value={profileForm.hourlyRate || 3500}
                      onChange={(e) => setProfileForm({ ...profileForm, hourlyRate: Number(e.target.value) })}
                      className="w-full bg-slate-900 border border-slate-700 px-3 py-1.5 text-slate-100 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">PAN Card Number (Tax Compliance)</label>
                    <input
                      type="text"
                      value={profileForm.panNumber || ''}
                      onChange={(e) => setProfileForm({ ...profileForm, panNumber: e.target.value.toUpperCase() })}
                      placeholder="ABCDE1234F"
                      className="w-full bg-slate-900 border border-slate-700 px-3 py-1.5 text-slate-100 font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Primary Core Skills (comma-separated)</label>
                    <input
                      type="text"
                      value={(profileForm.skills || []).join(', ')}
                      onChange={(e) => setProfileForm({ ...profileForm, skills: e.target.value.split(',').map(s => s.trim()).filter(Boolean) })}
                      placeholder="Distributed Systems, Cloud Security, Healthcare Informatics, Kafka"
                      className="w-full bg-slate-900 border border-slate-700 px-3 py-1.5 text-slate-100 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Professional Certifications & Fellowships</label>
                    <input
                      type="text"
                      value={(profileForm.certifications || []).join(', ')}
                      onChange={(e) => setProfileForm({ ...profileForm, certifications: e.target.value.split(',').map(s => s.trim()).filter(Boolean) })}
                      placeholder="CISSP, AWS Solutions Architect Pro, MD Healthcare"
                      className="w-full bg-slate-900 border border-slate-700 px-3 py-1.5 text-slate-100 font-mono"
                    />
                  </div>
                </div>

                {editingMember.isExternal && (
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Consulting Entity / Agency Name</label>
                    <input
                      type="text"
                      value={profileForm.consultantOrg || ''}
                      onChange={(e) => setProfileForm({ ...profileForm, consultantOrg: e.target.value })}
                      placeholder="e.g. Ross Cloud Advisory India Pvt Ltd"
                      className="w-full bg-slate-900 border border-slate-700 px-3 py-1.5 text-slate-100"
                    />
                  </div>
                )}
              </div>

              {/* Section 4: Role-Based Authority & Governance Status */}
              <div className="p-3 bg-slate-950 border border-slate-800 space-y-2">
                <span className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center justify-between">
                  <span>4. Role-Based Approvals & Authorization Authority</span>
                  {isSuperAdminEmail(editingMember.email) ? (
                    <span className="text-[10px] font-mono text-amber-300 bg-amber-500/10 px-2 py-0.5 border border-amber-500/30 flex items-center gap-1">
                      <Crown className="w-3 h-3 text-amber-400" />
                      SUPER ADMIN SUPREME
                    </span>
                  ) : (
                    <span className="text-[10px] font-mono text-indigo-400 bg-indigo-950/80 px-2 py-0.5 border border-indigo-800">
                      DELEGATED APPROVALS
                    </span>
                  )}
                </span>

                <div className="p-2.5 bg-slate-900/60 border border-slate-800/80 text-[11px] text-slate-400 space-y-1">
                  {isSuperAdminEmail(editingMember.email) ? (
                    <p className="text-amber-200/90 leading-relaxed">
                      <strong>Designated Super Admin ({editingMember.email}):</strong> Full unconditional executive authority across client billings, budget releases, team promotions, and security rule changes.
                    </p>
                  ) : (
                    <p className="text-slate-300 leading-relaxed">
                      <strong>Role Approach ({editingMember.role.replace('_', ' ').toUpperCase()}):</strong> Approvals for expenses over ₹50,000, sensitive timeline amendments, and invoice releases are routed through Super Admins (<strong>drbabukoillam@gmail.com</strong> & <strong>tech@bropms.com</strong>).
                    </p>
                  )}

                  <div className="flex flex-wrap gap-1.5 pt-1">
                    <span className={`px-1.5 py-0.5 text-[10px] font-mono border ${editingMember.permissions.canApproveExpenses ? 'bg-emerald-950 text-emerald-400 border-emerald-800' : 'bg-slate-900 text-slate-500 border-slate-800'}`}>
                      {editingMember.permissions.canApproveExpenses ? '✓ Can Approve Expenses' : '✗ No Expense Approval'}
                    </span>
                    <span className={`px-1.5 py-0.5 text-[10px] font-mono border ${editingMember.permissions.canCreateInvoices ? 'bg-indigo-950 text-indigo-400 border-indigo-800' : 'bg-slate-900 text-slate-500 border-slate-800'}`}>
                      {editingMember.permissions.canCreateInvoices ? '✓ Can Create Invoices' : '✗ No Invoicing Rights'}
                    </span>
                    <span className={`px-1.5 py-0.5 text-[10px] font-mono border ${editingMember.permissions.canEditDeadlines ? 'bg-amber-950 text-amber-300 border-amber-800' : 'bg-slate-900 text-slate-500 border-slate-800'}`}>
                      {editingMember.permissions.canEditDeadlines ? '✓ Can Amend Deadlines' : '✗ Locked Deadlines'}
                    </span>
                    <span className={`px-1.5 py-0.5 text-[10px] font-mono border ${editingMember.permissions.canManageClients ? 'bg-sky-950 text-sky-400 border-sky-800' : 'bg-slate-900 text-slate-500 border-slate-800'}`}>
                      {editingMember.permissions.canManageClients ? '✓ Client CRM Access' : '✗ Restricted Client Access'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingMember(null)}
                  className="px-4 py-2 text-slate-400 hover:text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold transition-colors flex items-center gap-1.5 shadow-lg shadow-indigo-950/40"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Profile Credentials</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Invite Member Modal */}
      {isInviteOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-xl shadow-2xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-indigo-400" />
                <span>Invite Team Member or Contracted Consultant</span>
              </h2>
              <button onClick={() => setIsInviteOpen(false)} className="text-slate-400 hover:text-slate-200">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleInvite} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Full Name *</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Dr. Ramesh Chandran"
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Email Address *</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="ramesh@cloudadvisory.in"
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Executive Title / Designation</label>
                  <input
                    type="text"
                    value={designation}
                    onChange={(e) => setDesignation(e.target.value)}
                    placeholder="e.g. Principal Cloud Security Consultant"
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Role Classification *</label>
                  <select
                    value={role}
                    onChange={(e) => handleRoleChange(e.target.value as UserRole)}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="external_consultant">External Consultant (Restricted Project View & Hourly Rate)</option>
                    <option value="team_member">Team Member / Engineer (Tasks execution & status updates)</option>
                    <option value="project_manager">Project Manager (Timelines, assignments, expenses)</option>
                    <option value="admin">Administrator (Operations & Billing)</option>
                    <option value="super_admin">Super Administrator (Supreme Organization Authority)</option>
                  </select>
                </div>
              </div>

              {isExternal && (
                <div className="p-3 bg-slate-950 border border-slate-800 space-y-3">
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Consulting Entity / Agency Name</label>
                    <input
                      type="text"
                      value={consultantOrg}
                      onChange={(e) => setConsultantOrg(e.target.value)}
                      placeholder="e.g. Ross Cloud Advisory India Pvt Ltd"
                      className="w-full bg-slate-900 border border-slate-700 px-3 py-2 text-slate-100"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Contract Hourly Rate (INR ₹)</label>
                    <input
                      type="number"
                      value={hourlyRate}
                      onChange={(e) => setHourlyRate(Number(e.target.value))}
                      className="w-full bg-slate-900 border border-slate-700 px-3 py-2 text-slate-100 font-mono"
                    />
                  </div>
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsInviteOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold transition-colors shadow-sm"
                >
                  Send Enterprise Invitation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
