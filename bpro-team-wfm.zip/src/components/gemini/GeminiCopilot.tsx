import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Bot, 
  Send, 
  Sparkles, 
  MapPin, 
  ExternalLink, 
  Trash2, 
  Download, 
  Zap, 
  BrainCircuit, 
  Compass, 
  CheckCircle2, 
  Clock, 
  FileText, 
  IndianRupee, 
  Building, 
  RefreshCw,
  Copy,
  Check,
  ChevronDown
} from 'lucide-react';
import { Tooltip } from '../common/Tooltip';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  modelUsed?: string;
  mapLinks?: Array<{ title: string; uri: string; address?: string; snippet?: string }>;
}

type ModelType = 'gemini-3.5-flash' | 'gemini-3.1-pro-preview' | 'gemini-3.1-flash-lite';

interface RolePreset {
  id: string;
  title: string;
  badge: string;
  description: string;
  systemInstruction: string;
  defaultModel: ModelType;
  enableMaps?: boolean;
}

const ROLE_PRESETS: RolePreset[] = [
  {
    id: 'general_erp',
    title: 'Executive ERP Copilot',
    badge: 'GENERAL',
    description: 'Operational analytics, project milestones, and INR financial optimization.',
    systemInstruction: 'You are the Executive Operations Copilot for Bpro PMS, an enterprise platform managing Indian Rupee (INR ₹) billing, projects, team productivity, and CRM. Provide concise, professional, actionable guidance with clear formatting.',
    defaultModel: 'gemini-3.5-flash'
  },
  {
    id: 'complex_strategy',
    title: 'Strategic & Tax Advisor',
    badge: 'COMPLEX',
    description: 'In-depth GST tax auditing, contracts, and complex multi-quarter forecasting.',
    systemInstruction: 'You are a Senior Strategic Advisory Partner specializing in Indian GST compliance, commercial contract risk assessment, EBITDA margins, and multi-team resource allocation. Provide rigorous, structured, in-depth analysis.',
    defaultModel: 'gemini-3.1-pro-preview'
  },
  {
    id: 'fast_assistant',
    title: 'Rapid Query Assistant',
    badge: 'FAST',
    description: 'Instant summaries, task drafting, math calculations, and quick status checks.',
    systemInstruction: 'You are an ultra-fast executive assistant. Give short, punchy, immediate answers in 1-3 bullet points.',
    defaultModel: 'gemini-3.1-flash-lite'
  },
  {
    id: 'maps_grounding',
    title: 'Client Logistics & Maps Scout',
    badge: 'MAPS GROUNDED',
    description: 'Real-time geography, client corporate headquarters, tech hubs, and venues with live Google Maps links.',
    systemInstruction: 'You are a corporate logistics and client site scout. You leverage real-time Google Maps Grounding to discover client office addresses, nearest business centers, conference venues, and transit hubs. Always emphasize verified locations.',
    defaultModel: 'gemini-3.5-flash',
    enableMaps: true
  }
];

export const GeminiCopilot: React.FC = () => {
  const { 
    currentUser, 
    clients, 
    projects, 
    invoices, 
    tasks, 
    formatCurrency,
    triggerCelebration 
  } = useApp();

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: `Hello ${currentUser.name}! I am your Gemini-powered Enterprise Copilot. I can assist with operations, analyze pending invoices in ₹ (INR), draft milestone plans, or query live locations and tech parks via Google Maps Grounding.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      modelUsed: 'gemini-3.5-flash'
    }
  ]);

  const [inputPrompt, setInputPrompt] = useState('');
  const [selectedRole, setSelectedRole] = useState<RolePreset>(ROLE_PRESETS[0]);
  const [selectedModel, setSelectedModel] = useState<ModelType>(ROLE_PRESETS[0].defaultModel);
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [enableMapsGrounding, setEnableMapsGrounding] = useState(false);

  const threadEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    threadEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleRoleChange = (role: RolePreset) => {
    setSelectedRole(role);
    setSelectedModel(role.defaultModel);
    if (role.enableMaps) {
      setEnableMapsGrounding(true);
    }
  };

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputPrompt.trim() || isLoading) return;

    const userText = inputPrompt.trim();
    setInputPrompt('');

    const userMessage: ChatMessage = {
      id: `msg_u_${Date.now()}`,
      role: 'user',
      content: userText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const updatedHistory = [...messages, userMessage];
    setMessages(updatedHistory);
    setIsLoading(true);

    try {
      if (enableMapsGrounding || selectedRole.enableMaps) {
        // Query Google Maps Grounding endpoint
        // Try to get geolocation if available
        let latLng: { latitude: number; longitude: number } | undefined = undefined;
        try {
          if ('geolocation' in navigator) {
            const pos: GeolocationPosition = await new Promise((resolve, reject) => {
              navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 3000 });
            });
            latLng = {
              latitude: pos.coords.latitude,
              longitude: pos.coords.longitude
            };
          }
        } catch {
          // Geolocation optional fallback
        }

        const res = await fetch('/api/maps-grounding', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt: userText,
            latLng
          })
        });

        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Maps Grounding error');

        const aiMessage: ChatMessage = {
          id: `msg_a_${Date.now()}`,
          role: 'assistant',
          content: data.text || 'Location intelligence gathered.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          modelUsed: 'gemini-3.5-flash (Maps Grounded)',
          mapLinks: data.mapLinks || []
        };

        setMessages(prev => [...prev, aiMessage]);
      } else {
        // Multi-turn Gemini chat API
        // Provide contextual summary of business metrics to system instruction
        const contextSummary = `\nCurrent Enterprise State:\n- Total Clients: ${clients.length}\n- Active Projects: ${projects.length}\n- Pending Tasks: ${tasks.filter(t => t.status !== 'completed').length}\n- Overdue Invoices: ${invoices.filter(i => i.status === 'sent' || i.status === 'overdue').length}`;
        const finalSystemInstruction = `${selectedRole.systemInstruction}\n${contextSummary}`;

        const apiMessages = updatedHistory.map(m => ({
          role: m.role,
          content: m.content
        }));

        const res = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            messages: apiMessages,
            model: selectedModel,
            systemInstruction: finalSystemInstruction
          })
        });

        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Chat request failed');

        const aiMessage: ChatMessage = {
          id: `msg_a_${Date.now()}`,
          role: 'assistant',
          content: data.text || 'Response received.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          modelUsed: selectedModel,
        };

        setMessages(prev => [...prev, aiMessage]);
      }
    } catch (err: any) {
      const errorMessage: ChatMessage = {
        id: `msg_err_${Date.now()}`,
        role: 'assistant',
        content: `Error: ${err.message || 'Unable to connect to Gemini API. Please verify server status.'}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        modelUsed: selectedModel,
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleExportChat = () => {
    const text = messages.map(m => `[${m.timestamp}] ${m.role.toUpperCase()} (${m.modelUsed || 'user'}):\n${m.content}\n`).join('\n---\n\n');
    const blob = new Blob([text], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Gemini_Chat_Transcript_${new Date().toISOString().substring(0, 10)}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    triggerCelebration();
  };

  const PREMADE_PROMPTS = [
    { label: 'Audit Pending Invoices (INR)', prompt: 'Review our unpaid invoices and generate an empathetic follow-up email in INR with 18% GST calculation.' },
    { label: 'Maps: Find Tech Parks & Venues', prompt: 'Find the top 5 tech business parks and executive client meeting spaces in Electronic City Bangalore or BKC Mumbai with Google Maps locations.' },
    { label: 'Sprint Milestone Decomposition', prompt: 'Create a 2-week sprint breakdown for implementing microservice authentication with hour estimates.' },
    { label: 'Client SLA Health Analysis', prompt: 'Suggest strategic recommendations to improve client satisfaction and reduce turnaround times for active projects.' },
  ];

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] min-h-[600px] bg-slate-900 border border-slate-800 shadow-2xl">
      {/* Top Header */}
      <div className="p-4 border-b border-slate-800 bg-slate-950 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-500/10 border border-indigo-500/30 text-indigo-400">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm font-bold text-slate-100 uppercase tracking-wider font-mono">
                Gemini Multi-Turn AI Copilot
              </h1>
              <span className="px-2 py-0.5 bg-indigo-950 text-indigo-300 border border-indigo-700/50 text-[10px] font-mono font-bold">
                ENTERPRISE
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Role-guided multi-turn chat with Google Maps Grounding & model auto-routing
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          <Tooltip content="Export Chat Transcript (.md)">
            <button
              onClick={handleExportChat}
              className="p-1.5 bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white border border-slate-800 transition-colors"
            >
              <Download className="w-4 h-4" />
            </button>
          </Tooltip>
          <Tooltip content="Clear Thread History">
            <button
              onClick={() => setMessages([])}
              className="p-1.5 bg-slate-900 hover:bg-rose-950/40 text-slate-300 hover:text-rose-400 border border-slate-800 transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </Tooltip>
        </div>
      </div>

      {/* Role & Model Configuration Bar */}
      <div className="p-3 border-b border-slate-800 bg-slate-950/70 flex flex-wrap items-center justify-between gap-3 text-xs">
        {/* Role Presets */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          <span className="text-[11px] font-mono uppercase text-slate-500 font-semibold mr-1">
            Role:
          </span>
          {ROLE_PRESETS.map(r => (
            <button
              key={r.id}
              onClick={() => handleRoleChange(r)}
              className={`px-2.5 py-1 text-xs font-medium transition-all flex items-center gap-1.5 border ${
                selectedRole.id === r.id
                  ? 'bg-indigo-600/20 text-indigo-300 border-indigo-500 shadow-sm'
                  : 'bg-slate-900/80 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              {r.enableMaps && <MapPin className="w-3 h-3 text-emerald-400" />}
              <span>{r.title}</span>
              <span className="text-[9px] font-mono opacity-70">[{r.badge}]</span>
            </button>
          ))}
        </div>

        {/* Model Selector & Grounding Toggle */}
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-1 text-[11px] font-mono">
            <span className="text-slate-500 uppercase">Model:</span>
            <select
              value={selectedModel}
              onChange={e => setSelectedModel(e.target.value as ModelType)}
              className="bg-slate-900 border border-slate-800 text-indigo-300 px-2 py-1 focus:outline-none focus:border-indigo-500"
            >
              <option value="gemini-3.5-flash">gemini-3.5-flash (General Tasks)</option>
              <option value="gemini-3.1-pro-preview">gemini-3.1-pro-preview (Complex Tasks)</option>
              <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite (Fast Tasks)</option>
            </select>
          </div>

          {/* Maps Grounding Toggle */}
          <button
            onClick={() => setEnableMapsGrounding(!enableMapsGrounding)}
            className={`px-2 py-1 text-xs font-mono font-medium border flex items-center gap-1.5 transition-colors ${
              enableMapsGrounding
                ? 'bg-emerald-950/40 text-emerald-300 border-emerald-500/50'
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
            }`}
          >
            <MapPin className={`w-3.5 h-3.5 ${enableMapsGrounding ? 'text-emerald-400' : 'text-slate-500'}`} />
            <span>Maps Grounding: {enableMapsGrounding ? 'ON' : 'OFF'}</span>
          </button>
        </div>
      </div>

      {/* Role Brief Banner */}
      <div className="px-4 py-2 bg-slate-950/40 border-b border-slate-800/60 text-[11px] text-slate-400 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BrainCircuit className="w-3.5 h-3.5 text-indigo-400" />
          <span>Active Role: <strong className="text-slate-200">{selectedRole.title}</strong> — {selectedRole.description}</span>
        </div>
        <span className="font-mono text-indigo-400 text-[10px]">
          Target: {selectedModel}
        </span>
      </div>

      {/* Scrollable Message Thread */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="text-center py-16 text-slate-500 space-y-3">
            <Bot className="w-10 h-10 mx-auto text-slate-700" />
            <p className="text-sm font-medium text-slate-400">Thread conversation is empty</p>
            <p className="text-xs max-w-sm mx-auto">
              Choose a role preset or pick one of the prompts below to initiate strategic guidance.
            </p>
          </div>
        ) : (
          messages.map(msg => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'} space-y-1.5`}
            >
              {/* Message Header */}
              <div className="flex items-center gap-2 text-[10px] font-mono text-slate-500 px-1">
                <span>{msg.role === 'user' ? currentUser.name : 'Gemini AI'}</span>
                {msg.modelUsed && (
                  <span className="px-1.5 py-0.2 bg-slate-800 text-indigo-300 border border-slate-700">
                    {msg.modelUsed}
                  </span>
                )}
                <span>{msg.timestamp}</span>
              </div>

              {/* Message Bubble */}
              <div
                className={`max-w-3xl p-4 border shadow-md relative group ${
                  msg.role === 'user'
                    ? 'bg-indigo-950/30 text-indigo-100 border-indigo-500/40'
                    : 'bg-slate-950 text-slate-200 border-slate-800'
                }`}
              >
                <div className="whitespace-pre-wrap leading-relaxed text-xs">
                  {msg.content}
                </div>

                {/* Google Maps Grounding Links */}
                {msg.mapLinks && msg.mapLinks.length > 0 && (
                  <div className="mt-4 pt-3 border-t border-slate-800 space-y-2">
                    <div className="flex items-center gap-1.5 text-[11px] font-mono font-bold text-emerald-400 uppercase tracking-wider">
                      <MapPin className="w-3.5 h-3.5" />
                      <span>Verified Google Maps Locations & Sources:</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {msg.mapLinks.map((loc, idx) => (
                        <a
                          key={idx}
                          href={loc.uri}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-2.5 bg-slate-900 hover:bg-slate-850 border border-emerald-500/30 hover:border-emerald-500 flex flex-col justify-between group/link transition-all"
                        >
                          <div>
                            <div className="text-xs font-bold text-slate-200 group-hover/link:text-emerald-300 flex items-center justify-between">
                              <span>{loc.title}</span>
                              <ExternalLink className="w-3 h-3 text-slate-500 group-hover/link:text-emerald-400" />
                            </div>
                            {loc.address && (
                              <p className="text-[10px] text-slate-400 mt-0.5">{loc.address}</p>
                            )}
                            {loc.snippet && (
                              <p className="text-[10px] text-slate-500 italic mt-1 line-clamp-2">"{loc.snippet}"</p>
                            )}
                          </div>
                          <span className="text-[9px] font-mono text-emerald-400 mt-2 flex items-center gap-1">
                            Open in Google Maps &rarr;
                          </span>
                        </a>
                      ))}
                    </div>
                  </div>
                )}

                {/* Copy Button */}
                <button
                  onClick={() => handleCopy(msg.id, msg.content)}
                  className="absolute top-2 right-2 p-1 text-slate-600 hover:text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity"
                  title="Copy text"
                >
                  {copiedId === msg.id ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            </div>
          ))
        )}

        {isLoading && (
          <div className="flex items-start space-y-1.5">
            <div className="p-3 bg-slate-950 border border-slate-800 text-xs text-indigo-400 flex items-center gap-2">
              <RefreshCw className="w-4 h-4 animate-spin text-indigo-400" />
              <span className="font-mono">
                {enableMapsGrounding
                  ? 'Querying Google Maps Grounding & Place intelligence...'
                  : `Generating reasoning with ${selectedModel}...`}
              </span>
            </div>
          </div>
        )}

        <div ref={threadEndRef} />
      </div>

      {/* Suggested Prompt Chips */}
      <div className="px-4 py-2 bg-slate-950/80 border-t border-slate-800 flex items-center gap-2 overflow-x-auto text-[11px]">
        <span className="text-slate-500 font-mono text-[10px] uppercase font-bold shrink-0">
          Suggested:
        </span>
        {PREMADE_PROMPTS.map((chip, idx) => (
          <button
            key={idx}
            onClick={() => {
              setInputPrompt(chip.prompt);
            }}
            className="px-2.5 py-1 bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white border border-slate-800 hover:border-indigo-500/50 whitespace-nowrap transition-colors shrink-0 font-medium"
          >
            {chip.label}
          </button>
        ))}
      </div>

      {/* Chat Input Bar */}
      <div className="p-4 border-t border-slate-800 bg-slate-950">
        <form onSubmit={handleSendMessage} className="flex items-center gap-2">
          <input
            type="text"
            value={inputPrompt}
            onChange={e => setInputPrompt(e.target.value)}
            placeholder={
              enableMapsGrounding
                ? 'Ask for locations, venues, or client sites (e.g. Find top coworking tech hubs in Bangalore)...'
                : `Ask ${selectedRole.title} (${selectedModel})...`
            }
            className="flex-1 bg-slate-900 border border-slate-800 px-3.5 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
            disabled={isLoading}
          />
          <button
            type="submit"
            disabled={isLoading || !inputPrompt.trim()}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-600 text-white text-xs font-bold font-mono uppercase tracking-wider flex items-center gap-1.5 transition-colors shrink-0"
          >
            <Send className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Dispatch</span>
          </button>
        </form>
      </div>
    </div>
  );
};
