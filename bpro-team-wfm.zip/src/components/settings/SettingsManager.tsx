import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Sliders, 
  ShieldCheck, 
  Building2, 
  Receipt, 
  CreditCard, 
  Lock, 
  Crown, 
  Check, 
  Download, 
  AlertCircle, 
  Key, 
  FileText, 
  Users,
  IndianRupee,
  Save,
  CheckCircle2,
  RefreshCw
} from 'lucide-react';
import { storageService } from '../../services/storage';

export const SettingsManager: React.FC = () => {
  const { orgSettings, updateOrgSettings, currentUser, isSuperAdmin, formatCurrency, allTeamMembers } = useApp();

  const [activeTab, setActiveTab] = useState<'org' | 'governance' | 'approvals' | 'invoicing' | 'banking' | 'security'>('governance');
  const [formData, setFormData] = useState({ ...orgSettings });
  const [savedSuccess, setSavedSuccess] = useState(false);

  const isSuperOrAdmin = isSuperAdmin || currentUser.role === 'admin';

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateOrgSettings(formData);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleBackup = () => {
    const backup = storageService.exportFullBackup();
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `BproPMS_Enterprise_Encrypted_Backup_${new Date().toISOString().substring(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950/40 border border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-indigo-400" />
            <h1 className="text-lg font-bold text-slate-100">Enterprise Administration & Settings</h1>
            <span className="px-2 py-0.5 text-[10px] font-mono bg-amber-500/10 text-amber-300 border border-amber-500/30 flex items-center gap-1 font-bold">
              <Crown className="w-3 h-3 text-amber-400" />
              <span>SUPER ADMIN PORTAL</span>
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Governed by Super Admins (<strong className="text-slate-200">drbabukollam@gmail.com</strong> & <strong className="text-slate-200">tech@bropms.com</strong>). All other tiers are governed by role-based approvals.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleBackup}
            className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
            <span>Encrypted JSON Backup</span>
          </button>
        </div>
      </div>

      {savedSuccess && (
        <div className="p-3 bg-emerald-950/50 border border-emerald-700 text-xs text-emerald-300 flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>Enterprise organization settings and Super Admin governance parameters have been successfully persisted.</span>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="flex flex-wrap items-center border-b border-slate-800 gap-1 text-xs">
        <button
          onClick={() => setActiveTab('governance')}
          className={`px-4 py-2.5 font-medium border-b-2 flex items-center gap-2 transition-colors ${
            activeTab === 'governance'
              ? 'border-indigo-500 text-indigo-300 font-semibold bg-slate-900/60'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Crown className="w-4 h-4 text-amber-400" />
          <span>Super Admin Governance & RBAC</span>
        </button>

        <button
          onClick={() => setActiveTab('approvals')}
          className={`px-4 py-2.5 font-medium border-b-2 flex items-center gap-2 transition-colors ${
            activeTab === 'approvals'
              ? 'border-indigo-500 text-indigo-300 font-semibold bg-slate-900/60'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Role-Based Approvals Matrix</span>
        </button>

        <button
          onClick={() => setActiveTab('org')}
          className={`px-4 py-2.5 font-medium border-b-2 flex items-center gap-2 transition-colors ${
            activeTab === 'org'
              ? 'border-indigo-500 text-indigo-300 font-semibold bg-slate-900/60'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Building2 className="w-4 h-4 text-sky-400" />
          <span>Company & Legal Entity</span>
        </button>

        <button
          onClick={() => setActiveTab('invoicing')}
          className={`px-4 py-2.5 font-medium border-b-2 flex items-center gap-2 transition-colors ${
            activeTab === 'invoicing'
              ? 'border-indigo-500 text-indigo-300 font-semibold bg-slate-900/60'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Receipt className="w-4 h-4 text-emerald-400" />
          <span>GST & Invoicing (INR ₹)</span>
        </button>

        <button
          onClick={() => setActiveTab('banking')}
          className={`px-4 py-2.5 font-medium border-b-2 flex items-center gap-2 transition-colors ${
            activeTab === 'banking'
              ? 'border-indigo-500 text-indigo-300 font-semibold bg-slate-900/60'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <CreditCard className="w-4 h-4 text-amber-400" />
          <span>Bank, IFSC & UPI Remittance</span>
        </button>

        <button
          onClick={() => setActiveTab('security')}
          className={`px-4 py-2.5 font-medium border-b-2 flex items-center gap-2 transition-colors ${
            activeTab === 'security'
              ? 'border-indigo-500 text-indigo-300 font-semibold bg-slate-900/60'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Lock className="w-4 h-4 text-rose-400" />
          <span>Security & Compliance Policies</span>
        </button>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Tab 1: Super Admin Governance & RBAC */}
        {activeTab === 'governance' && (
          <div className="space-y-5">
            <div className="p-4 bg-slate-900 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                  <Crown className="w-4 h-4 text-amber-400" />
                  <span>Designated Super Administrators</span>
                </span>
                <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/80 px-2 py-0.5 border border-emerald-800">
                  SUPREME AUTHORITY ENFORCED
                </span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Super Admins possess root-level authority across all projects, financial disbursements, team roles, and Google Workspace integrations. All other users operate strictly within delegated role approvals.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                <div className="p-3 bg-slate-950 border border-amber-500/40 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-xs text-slate-100 flex items-center gap-1.5">
                      <Crown className="w-3.5 h-3.5 text-amber-400" />
                      <span>Dr. Babu Kollam</span>
                    </span>
                    <span className="text-[10px] font-mono text-amber-300 font-bold">PRIMARY SUPER ADMIN</span>
                  </div>
                  <div className="text-xs text-indigo-400 font-mono">drbabukollam@gmail.com</div>
                  <div className="text-[11px] text-slate-400">Managing Director & Executive Sponsor</div>
                </div>

                <div className="p-3 bg-slate-950 border border-amber-500/40 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-xs text-slate-100 flex items-center gap-1.5">
                      <Crown className="w-3.5 h-3.5 text-amber-400" />
                      <span>Bpro PMS Tech Architecture</span>
                    </span>
                    <span className="text-[10px] font-mono text-amber-300 font-bold">TECHNICAL SUPER ADMIN</span>
                  </div>
                  <div className="text-xs text-indigo-400 font-mono">tech@bropms.com</div>
                  <div className="text-[11px] text-slate-400">Chief Technology Officer & Lead Architect</div>
                </div>
              </div>
            </div>

            {/* Approval Hierarchy Controls */}
            <div className="p-5 bg-slate-900 border border-slate-800 space-y-4">
              <h2 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                Role-Based Approval Governance Thresholds
              </h2>

              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between p-3 bg-slate-950 border border-slate-800">
                  <div>
                    <span className="font-semibold text-slate-200 block">Mandatory Super Admin Financial Authorization</span>
                    <span className="text-[11px] text-slate-400">Any invoice, expense payout, or contract exceeding this amount requires Super Admin approval</span>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="font-mono text-slate-400">₹</span>
                    <input
                      type="number"
                      value={formData.requireApprovalOverAmount}
                      onChange={(e) => setFormData({ ...formData, requireApprovalOverAmount: Number(e.target.value) })}
                      className="w-32 bg-slate-900 border border-slate-700 px-3 py-1.5 text-slate-100 font-mono text-right"
                    />
                  </div>
                </div>

                <label className="flex items-center justify-between p-3 bg-slate-950 border border-slate-800 cursor-pointer">
                  <div>
                    <span className="font-semibold text-slate-200 block">Strict External Consultant Isolation</span>
                    <span className="text-[11px] text-slate-400">External consultants only view specifically assigned tasks/projects with zero access to client billings or invoices</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={formData.restrictConsultants}
                    onChange={(e) => setFormData({ ...formData, restrictConsultants: e.target.checked })}
                    className="rounded-none bg-slate-900 border-slate-700 text-indigo-600 focus:ring-0 w-4 h-4"
                  />
                </label>

                <label className="flex items-center justify-between p-3 bg-slate-950 border border-slate-800 cursor-pointer">
                  <div>
                    <span className="font-semibold text-slate-200 block">Mandatory Multi-Factor Authentication (MFA)</span>
                    <span className="text-[11px] text-slate-400">Enforce hardware token or authenticator app for Admin & Super Admin logins</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={formData.enforceMfa}
                    onChange={(e) => setFormData({ ...formData, enforceMfa: e.target.checked })}
                    className="rounded-none bg-slate-900 border-slate-700 text-indigo-600 focus:ring-0 w-4 h-4"
                  />
                </label>
              </div>
            </div>
          </div>
        )}

        {/* Tab: Role-Based Approvals Matrix & Approaches */}
        {activeTab === 'approvals' && (
          <div className="space-y-5">
            <div className="p-4 bg-slate-900 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Role-Based Approvals & Tiered Authority Governance</span>
                </span>
                <span className="text-[11px] font-mono text-amber-300 bg-amber-500/10 px-2.5 py-0.5 border border-amber-500/30 font-bold">
                  SUPER ADMIN APPOINTED: drbabukoillam@gmail.com & tech@bropms.com
                </span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Bpro PMS enforces zero-trust role-based approaches for every operational action. All high-stakes decisions (expenditures, tax configuration, role promotions, and invoice cancellations) mandate Super Admin authorization.
              </p>
            </div>

            {/* Matrix Table */}
            <div className="p-5 bg-slate-900 border border-slate-800 space-y-4 text-xs">
              <h2 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                Authority & Approval Approaches by Role
              </h2>

              <div className="overflow-x-auto border border-slate-800">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950 text-slate-400 font-mono text-[11px] uppercase border-b border-slate-800">
                    <tr>
                      <th className="p-3">User Role & Scope</th>
                      <th className="p-3">Financials & Invoicing</th>
                      <th className="p-3">Expense Approval Tier</th>
                      <th className="p-3">Deadline Amendments</th>
                      <th className="p-3">Approvals Approach</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80 text-slate-300 font-medium">
                    <tr className="bg-amber-950/20">
                      <td className="p-3">
                        <div className="flex items-center gap-1.5 font-bold text-amber-300">
                          <Crown className="w-3.5 h-3.5 text-amber-400" />
                          <span>SUPER ADMIN</span>
                        </div>
                        <div className="text-[11px] text-slate-400">drbabukoillam@gmail.com & tech@bropms.com</div>
                      </td>
                      <td className="p-3 text-emerald-400 font-bold">Full Unlimited Autonomy</td>
                      <td className="p-3 text-emerald-400 font-bold">Unconditional Direct Sign-off</td>
                      <td className="p-3 text-emerald-400 font-bold">Direct Override</td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 bg-amber-500/10 text-amber-300 border border-amber-500/30 text-[10px] font-mono font-bold">
                          SUPREME GOVERNANCE
                        </span>
                      </td>
                    </tr>

                    <tr>
                      <td className="p-3">
                        <div className="font-bold text-indigo-400">ADMINISTRATOR</div>
                        <div className="text-[11px] text-slate-400">Operations & Billing Management</div>
                      </td>
                      <td className="p-3 text-slate-200">Creates & dispatches invoices</td>
                      <td className="p-3 text-slate-200">Up to ₹{formData.requireApprovalOverAmount.toLocaleString('en-IN')}</td>
                      <td className="p-3 text-slate-200">Approved with logged reason</td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 bg-indigo-950 text-indigo-300 border border-indigo-800 text-[10px] font-mono">
                          OPERATIONAL APPROVER
                        </span>
                      </td>
                    </tr>

                    <tr>
                      <td className="p-3">
                        <div className="font-bold text-emerald-400">PROJECT MANAGER</div>
                        <div className="text-[11px] text-slate-400">Timelines, Tasks & Team Allocation</div>
                      </td>
                      <td className="p-3 text-slate-400">View-only & line item draft</td>
                      <td className="p-3 text-slate-400">Initial verification only</td>
                      <td className="p-3 text-slate-200">Can amend with mandatory justification</td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 bg-emerald-950 text-emerald-300 border border-emerald-800 text-[10px] font-mono">
                          DELIVERY APPROVER
                        </span>
                      </td>
                    </tr>

                    <tr>
                      <td className="p-3">
                        <div className="font-bold text-sky-400">TEAM MEMBER</div>
                        <div className="text-[11px] text-slate-400">Core Engineering & Execution</div>
                      </td>
                      <td className="p-3 text-slate-500">Restricted / No access</td>
                      <td className="p-3 text-slate-400">Submits claims for review</td>
                      <td className="p-3 text-slate-400">Requests postponement with reason</td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 bg-sky-950 text-sky-300 border border-sky-800 text-[10px] font-mono">
                          EXECUTION & SUBMISSION
                        </span>
                      </td>
                    </tr>

                    <tr>
                      <td className="p-3">
                        <div className="font-bold text-amber-400">EXTERNAL CONSULTANT</div>
                        <div className="text-[11px] text-slate-400">Contracted Specialist</div>
                      </td>
                      <td className="p-3 text-rose-400">Strictly Isolated / Zero access</td>
                      <td className="p-3 text-slate-500">Requires PM & Admin sign-off</td>
                      <td className="p-3 text-slate-400">Requests date adjustments with reason</td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 bg-amber-950 text-amber-400 border border-amber-800 text-[10px] font-mono">
                          SANDBOXED DELIVERABLE
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Specific Operational Guardrails */}
              <div className="p-4 bg-slate-950 border border-slate-800 space-y-3 pt-4">
                <span className="text-xs font-bold text-slate-200 uppercase tracking-wider block">
                  Mandatory Enterprise Compliance Policies
                </span>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 bg-slate-900 border border-slate-800 space-y-1">
                    <span className="font-semibold text-slate-200 block">Single-Source Super Admin Audit</span>
                    <span className="text-[11px] text-slate-400">
                      Any changes to designated Super Admins (<strong>drbabukoillam@gmail.com</strong>, <strong>tech@bropms.com</strong>) requires out-of-band master key rotation.
                    </span>
                  </div>

                  <div className="p-3 bg-slate-900 border border-slate-800 space-y-1">
                    <span className="font-semibold text-slate-200 block">Immutable Cryptographic Trail</span>
                    <span className="text-[11px] text-slate-400">
                      Every task status change, deadline extension, and expense approval produces an encrypted SHA-256 ledger entry in the Audit Log Manager.
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
        {activeTab === 'org' && (
          <div className="p-5 bg-slate-900 border border-slate-800 space-y-4 text-xs">
            <h2 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              Corporate Organization & Registration (India)
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Company Legal Name *</label>
                <input
                  type="text"
                  value={formData.companyName}
                  onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Tagline / Brand Statement</label>
                <input
                  type="text"
                  value={formData.tagline}
                  onChange={(e) => setFormData({ ...formData, tagline: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">GSTIN (Goods & Services Tax ID) *</label>
                <input
                  type="text"
                  value={formData.gstin}
                  onChange={(e) => setFormData({ ...formData, gstin: e.target.value.toUpperCase() })}
                  placeholder="32AABCB1234F1Z8"
                  className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 font-mono"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">PAN (Permanent Account Number) *</label>
                <input
                  type="text"
                  value={formData.pan}
                  onChange={(e) => setFormData({ ...formData, pan: e.target.value.toUpperCase() })}
                  placeholder="AABCB1234F"
                  className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 font-mono"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Official Communications Email</label>
                <input
                  type="email"
                  value={formData.officialEmail}
                  onChange={(e) => setFormData({ ...formData, officialEmail: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Helpline Phone Number</label>
                <input
                  type="text"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Registered Corporate Address</label>
              <textarea
                value={formData.registeredAddress}
                onChange={(e) => setFormData({ ...formData, registeredAddress: e.target.value })}
                rows={2}
                className="w-full bg-slate-950 border border-slate-700 p-2.5 text-slate-100"
              />
            </div>
          </div>
        )}

        {/* Tab 3: GST & Invoicing */}
        {activeTab === 'invoicing' && (
          <div className="p-5 bg-slate-900 border border-slate-800 space-y-4 text-xs">
            <h2 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              Indian GST Taxation & Invoice Formatting Parameters
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Base Currency</label>
                <div className="p-2 bg-slate-950 border border-slate-700 text-slate-200 font-mono font-bold flex items-center gap-1.5">
                  <IndianRupee className="w-4 h-4 text-emerald-400" />
                  <span>INR (₹ Indian Rupee)</span>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Standard GST Rate (%)</label>
                <input
                  type="number"
                  value={formData.defaultGstRate}
                  onChange={(e) => setFormData({ ...formData, defaultGstRate: Number(e.target.value) })}
                  step="0.5"
                  className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 font-mono"
                />
                <span className="text-[10px] text-slate-500 mt-1 block">9% CGST + 9% SGST (or 18% IGST)</span>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">SAC Code (Services)</label>
                <input
                  type="text"
                  value={formData.hsnSacCode}
                  onChange={(e) => setFormData({ ...formData, hsnSacCode: e.target.value })}
                  placeholder="998314"
                  className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 font-mono"
                />
                <span className="text-[10px] text-slate-500 mt-1 block">IT Consulting / Development SAC</span>
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Invoice Number Prefix</label>
              <input
                type="text"
                value={formData.invoicePrefix}
                onChange={(e) => setFormData({ ...formData, invoicePrefix: e.target.value.toUpperCase() })}
                placeholder="BPRO-INV-2026-"
                className="w-full max-w-sm bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 font-mono"
              />
            </div>
          </div>
        )}

        {/* Tab 4: Banking, IFSC & UPI */}
        {activeTab === 'banking' && (
          <div className="p-5 bg-slate-900 border border-slate-800 space-y-4 text-xs">
            <h2 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              Settlement Banking & UPI Remittance Channels
            </h2>
            <p className="text-xs text-slate-400">
              These details are printed automatically on all generated client invoices and automated PDF payment stubs.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Bank Name</label>
                <input
                  type="text"
                  value={formData.bankName}
                  onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
                  placeholder="HDFC Bank Ltd"
                  className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Corporate Current Account #</label>
                <input
                  type="text"
                  value={formData.accountNumber}
                  onChange={(e) => setFormData({ ...formData, accountNumber: e.target.value })}
                  placeholder="50200084920194"
                  className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">IFSC Code (NEFT / RTGS / IMPS)</label>
                <input
                  type="text"
                  value={formData.ifscCode}
                  onChange={(e) => setFormData({ ...formData, ifscCode: e.target.value.toUpperCase() })}
                  placeholder="HDFC0001234"
                  className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Bank Branch</label>
                <input
                  type="text"
                  value={formData.branch}
                  onChange={(e) => setFormData({ ...formData, branch: e.target.value })}
                  placeholder="Cyber Park Executive Branch"
                  className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Instant UPI ID (VPA)</label>
                <input
                  type="text"
                  value={formData.upiId}
                  onChange={(e) => setFormData({ ...formData, upiId: e.target.value.toLowerCase() })}
                  placeholder="bropms@hdfcbank"
                  className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 font-mono"
                />
              </div>
            </div>
          </div>
        )}

        {/* Tab 5: Security & Compliance Policies */}
        {activeTab === 'security' && (
          <div className="p-5 bg-slate-900 border border-slate-800 space-y-4 text-xs">
            <h2 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              Enterprise Security & Audit Retention Protocols
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-3 bg-slate-950 border border-slate-800 space-y-2">
                <span className="font-semibold text-slate-200 block">Session Inactivity Timeout</span>
                <span className="text-[11px] text-slate-400">Forces user re-authentication after period of zero activity</span>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    value={formData.sessionTimeoutMinutes}
                    onChange={(e) => setFormData({ ...formData, sessionTimeoutMinutes: Number(e.target.value) })}
                    className="w-24 bg-slate-900 border border-slate-700 px-2 py-1 text-slate-100 font-mono text-right"
                  />
                  <span className="text-slate-400 font-mono">minutes</span>
                </div>
              </div>

              <div className="p-3 bg-slate-950 border border-slate-800 space-y-2">
                <span className="font-semibold text-slate-200 block">Audit Ledger Retention Window</span>
                <span className="text-[11px] text-slate-400">Retains immutable SHA-256 event checksums for auditor inspection</span>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    value={formData.auditRetentionDays}
                    onChange={(e) => setFormData({ ...formData, auditRetentionDays: Number(e.target.value) })}
                    className="w-24 bg-slate-900 border border-slate-700 px-2 py-1 text-slate-100 font-mono text-right"
                  />
                  <span className="text-slate-400 font-mono">days</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Submit Bar */}
        <div className="flex items-center justify-between p-4 bg-slate-900 border border-slate-800">
          <div className="text-xs text-slate-400">
            Current Operator: <strong className="text-slate-200">{currentUser.name}</strong> ({currentUser.role.replace('_', ' ')})
          </div>

          <button
            type="submit"
            className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-colors flex items-center gap-1.5 shadow-lg shadow-indigo-950/40"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save Enterprise Settings</span>
          </button>
        </div>
      </form>
    </div>
  );
};
