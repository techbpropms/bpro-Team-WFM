import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Bell, 
  Wifi, 
  WifiOff, 
  Search, 
  ChevronDown, 
  Shield, 
  Calendar as CalendarIcon, 
  Sliders, 
  Download, 
  LogOut, 
  Check, 
  ExternalLink,
  Layers,
  Sparkles,
  Crown,
  Settings,
  Pin,
  Trophy,
  Upload,
  FileSpreadsheet,
  FileText,
  Bot,
  Database,
  GitBranch,
  FolderArchive
} from 'lucide-react';
import { storageService } from '../../services/storage';
import { exportToCsv } from '../../services/csvExport';
import { Tooltip } from '../common/Tooltip';
import { GitPushModal } from '../modals/GitPushModal';

interface NavbarProps {
  onOpenIntegrations: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenIntegrations }) => {
  const { 
    currentUser, 
    allTeamMembers, 
    switchUser, 
    googleUser, 
    signInWithGoogle, 
    signOutGoogle, 
    isOffline, 
    notifications, 
    markNotificationRead, 
    clearAllNotifications, 
    searchQuery, 
    setSearchQuery,
    setActiveTab,
    activeTab,
    isSuperAdmin,
    setIsUploadModalOpen,
    invoices,
    tasks,
    expenses,
    auditLogs,
    gamificationProfiles,
    triggerCelebration,
    isFirestoreConnected,
    orgSettings,
    setIsNotificationCenterOpen
  } = useApp();

  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showDownloadsMenu, setShowDownloadsMenu] = useState(false);
  const [showGitPushModal, setShowGitPushModal] = useState(false);
  const unreadCount = notifications.filter(n => !n.isRead).length;

  const userGamification = gamificationProfiles.find(p => p.userId === currentUser.id);

  const handleExportBackup = () => {
    const backup = storageService.exportFullBackup();
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bropms_enterprise_backup_${new Date().toISOString().substring(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    triggerCelebration();
  };

  const handleExportInvoicesCsv = () => {
    const rows = invoices.map(i => ({
      'Invoice #': i.invoiceNumber,
      'Issue Date': i.issueDate,
      'Due Date': i.dueDate,
      'Status': i.status.toUpperCase(),
      'Subtotal (INR)': i.subtotal,
      'GST Tax 18% (INR)': i.taxAmount,
      'Total (INR)': i.total,
      'Payment Terms': i.paymentTerms,
    }));
    exportToCsv(`Bpro_Invoices_Ledger_${new Date().toISOString().substring(0, 10)}`, rows);
    setShowDownloadsMenu(false);
    triggerCelebration();
  };

  const handleExportTasksCsv = () => {
    const rows = tasks.map(t => ({
      'Task ID': t.id,
      'Title': t.title,
      'Status': t.status.toUpperCase(),
      'Priority': t.priority.toUpperCase(),
      'Due Date': t.dueDate,
      'Est Hours': t.estimatedHours,
      'Actual Hours': t.actualHours,
      'Amendments Count': t.amendments.length,
    }));
    exportToCsv(`Bpro_Tasks_Sprint_Ledger_${new Date().toISOString().substring(0, 10)}`, rows);
    setShowDownloadsMenu(false);
    triggerCelebration();
  };

  const handleExportExpensesCsv = () => {
    const rows = expenses.map(e => ({
      'Expense ID': e.id,
      'Date': e.date,
      'Category': e.category,
      'Description': e.description,
      'Amount (INR)': e.amount,
      'Billable': e.isBillable ? 'YES' : 'NO',
      'Status': e.status.toUpperCase(),
      'Submitted By': e.submittedByName,
    }));
    exportToCsv(`Bpro_Expenses_Audit_Ledger_${new Date().toISOString().substring(0, 10)}`, rows);
    setShowDownloadsMenu(false);
    triggerCelebration();
  };

  const roleBadgeStyles: Record<string, string> = {
    admin: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/30',
    project_manager: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    team_member: 'bg-sky-500/10 text-sky-400 border-sky-500/30',
    external_consultant: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    client_stakeholder: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80 px-4 lg:px-6 py-2.5 flex items-center justify-between gap-4">
      {/* Brand & Status */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-indigo-700 flex items-center justify-center font-bold text-white shadow-md shadow-indigo-950/50">
            <Layers className="w-4 h-4" />
          </div>
          <div className="hidden sm:block">
            <span className="font-bold text-sm tracking-wide text-slate-100 flex items-center gap-1.5">
              BPRO <span className="text-indigo-400 font-mono text-xs">PMS</span>
            </span>
            <span className="text-[10px] text-slate-400 tracking-wider font-mono block -mt-1 truncate max-w-[200px]">
              {orgSettings?.tagline || 'ENTERPRISE OPS & CRM'}
            </span>
          </div>
        </div>

        {/* Offline / Online Badge */}
        <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 bg-slate-900 border border-slate-800 text-[11px] font-mono">
          {isOffline ? (
            <>
              <WifiOff className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              <span className="text-amber-400 font-medium">OFFLINE CACHED</span>
            </>
          ) : (
            <>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-emerald-400 font-medium">LIVE // SYNCED</span>
            </>
          )}
        </div>

        {/* Firestore Cloud DB Badge */}
        <div className="hidden xl:flex items-center gap-1.5 px-2.5 py-1 bg-slate-900 border border-slate-800 text-[11px] font-mono text-slate-300">
          <Database className="w-3 h-3 text-amber-400" />
          <span>FIRESTORE: <strong className="text-emerald-400">ONLINE</strong></span>
        </div>
      </div>

      {/* Global Search Bar */}
      <div className="flex-1 max-w-md hidden lg:block">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search clients, projects, tasks, invoices (Cmd+K)..."
            className="w-full bg-slate-900/80 border border-slate-800 pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 font-medium transition-colors"
          />
        </div>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Google Workspace Connection Pill */}
        {googleUser ? (
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 bg-indigo-950/40 border border-indigo-700/50 text-indigo-300 text-xs">
            <CalendarIcon className="w-3.5 h-3.5 text-indigo-400" />
            <span className="truncate max-w-[130px] font-mono text-[11px]">{googleUser.email}</span>
            <button 
              onClick={signOutGoogle} 
              title="Disconnect Google Calendar"
              className="ml-1 text-slate-400 hover:text-rose-400"
            >
              <LogOut className="w-3 h-3" />
            </button>
          </div>
        ) : (
          <button
            onClick={signInWithGoogle}
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 bg-slate-900 hover:bg-slate-850 border border-slate-700 text-slate-200 hover:text-white text-xs font-medium transition-colors"
          >
            <CalendarIcon className="w-3.5 h-3.5 text-indigo-400" />
            <span>Connect Google Calendar</span>
          </button>
        )}

        {/* Merit & Gamification Hub */}
        <Tooltip content="Team Merit, Leaderboard & XP Progress">
          <button
            onClick={() => setActiveTab('gamification')}
            className={`p-2 border transition-colors flex items-center gap-1.5 text-xs font-medium ${
              activeTab === 'gamification'
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800'
            }`}
          >
            <Trophy className="w-4 h-4 text-amber-400" />
            <span className="hidden xl:inline text-[10px] font-mono font-bold text-amber-300">
              LVL {userGamification?.level || 1}
            </span>
          </button>
        </Tooltip>

        {/* Gemini AI Copilot */}
        <Tooltip content="Gemini Multi-Turn AI Copilot & Maps Grounding">
          <button
            onClick={() => setActiveTab('gemini')}
            className={`p-2 border transition-colors flex items-center gap-1.5 text-xs font-medium ${
              activeTab === 'gemini'
                ? 'bg-indigo-600/25 text-indigo-300 border-indigo-500 shadow-sm'
                : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800'
            }`}
          >
            <Bot className="w-4 h-4 text-indigo-400" />
            <span className="hidden xl:inline text-[10px] font-mono font-bold text-indigo-300">
              AI COPILOT
            </span>
          </button>
        </Tooltip>

        {/* Sticky Notes Quick Access */}
        <Tooltip content="Collaborative Sticky Notes & Scratchpad">
          <button
            onClick={() => setActiveTab('sticky')}
            className={`p-2 border transition-colors flex items-center gap-1 text-xs font-medium ${
              activeTab === 'sticky'
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800'
            }`}
          >
            <Pin className="w-4 h-4 text-amber-400" />
          </button>
        </Tooltip>

        {/* Format Ingest & Uploads */}
        <Tooltip content="Format Ingest & Document Vault (CSV, Receipts, JSON)">
          <button
            onClick={() => setIsUploadModalOpen(true)}
            className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 transition-colors flex items-center gap-1"
          >
            <Upload className="w-4 h-4 text-emerald-400" />
          </button>
        </Tooltip>

        {/* Super Admin / Admin Settings Button */}
        <Tooltip content="Enterprise Governance & Approvals (Super Admin / Admin)">
          <button
            onClick={() => setActiveTab('settings')}
            className={`p-2 border transition-colors flex items-center gap-1.5 text-xs font-medium ${
              activeTab === 'settings'
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800'
            }`}
          >
            <Crown className={`w-4 h-4 ${isSuperAdmin ? 'text-amber-400' : 'text-slate-400'}`} />
            <span className="hidden lg:inline text-[11px] font-mono">SETTINGS</span>
          </button>
        </Tooltip>

        {/* Integrations modal trigger */}
        <Tooltip content="API Integrations (Slack, Meet, Tally ERP)">
          <button
            onClick={onOpenIntegrations}
            className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 transition-colors"
          >
            <Sliders className="w-4 h-4 text-indigo-400" />
          </button>
        </Tooltip>

        {/* Downloads & Data Export Hub Dropdown */}
        <div className="relative">
          <Tooltip content="Quick Downloads & Data Ledgers (CSV, PDF, JSON)">
            <button
              onClick={() => setShowDownloadsMenu(!showDownloadsMenu)}
              className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 transition-colors flex items-center gap-1"
            >
              <Download className="w-4 h-4 text-emerald-400" />
            </button>
          </Tooltip>

          {showDownloadsMenu && (
            <div className="absolute right-0 mt-2 w-64 bg-slate-900 border border-slate-700 shadow-2xl z-50 p-2 space-y-1 animate-in fade-in text-xs">
              <div className="px-3 py-1.5 text-[10px] font-mono text-slate-400 uppercase font-semibold border-b border-slate-800">
                1-Click Export Ledgers
              </div>
              <button
                onClick={handleExportInvoicesCsv}
                className="w-full text-left px-3 py-2 text-slate-200 hover:bg-slate-800 flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Invoices Ledger (CSV)</span>
                </div>
                <span className="text-[10px] font-mono text-slate-500">{invoices.length} inv</span>
              </button>
              <button
                onClick={handleExportTasksCsv}
                className="w-full text-left px-3 py-2 text-slate-200 hover:bg-slate-800 flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Sprint Tasks Breakdown (CSV)</span>
                </div>
                <span className="text-[10px] font-mono text-slate-500">{tasks.length} tasks</span>
              </button>
              <button
                onClick={handleExportExpensesCsv}
                className="w-full text-left px-3 py-2 text-slate-200 hover:bg-slate-800 flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="w-3.5 h-3.5 text-amber-400" />
                  <span>Expenses & Receipts Audit (CSV)</span>
                </div>
                <span className="text-[10px] font-mono text-slate-500">{expenses.length} exp</span>
              </button>
              <button
                onClick={handleExportBackup}
                className="w-full text-left px-3 py-2 text-slate-200 hover:bg-slate-800 flex items-center justify-between border-t border-slate-800 pt-2"
              >
                <div className="flex items-center gap-2">
                  <Download className="w-3.5 h-3.5 text-sky-400" />
                  <span>Full System Backup (JSON)</span>
                </div>
                <span className="text-[10px] font-mono text-slate-500">JSON</span>
              </button>
              <button
                onClick={() => {
                  window.location.href = '/bpro-team-wfm.zip';
                  setShowDownloadsMenu(false);
                }}
                className="w-full text-left px-3 py-2 text-emerald-300 hover:bg-slate-800 flex items-center justify-between bg-emerald-950/20"
              >
                <div className="flex items-center gap-2">
                  <FolderArchive className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="font-semibold">Download Project (.ZIP)</span>
                </div>
                <span className="text-[10px] font-mono text-emerald-400">197 KB</span>
              </button>
              <button
                onClick={() => {
                  setShowGitPushModal(true);
                  setShowDownloadsMenu(false);
                }}
                className="w-full text-left px-3 py-2 text-indigo-300 hover:bg-slate-800 flex items-center justify-between bg-indigo-950/20 border-t border-slate-800 pt-2"
              >
                <div className="flex items-center gap-2">
                  <GitBranch className="w-3.5 h-3.5 text-indigo-400" />
                  <span className="font-semibold">Push to GitHub (WFM)</span>
                </div>
                <span className="text-[10px] font-mono text-indigo-400 font-bold">GIT ↗</span>
              </button>
            </div>
          )}
        </div>

        {/* Notification Center */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 relative transition-colors"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-indigo-600 text-[10px] font-bold text-white flex items-center justify-center font-mono">
                {unreadCount}
              </span>
            )}
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-slate-900 border border-slate-700 shadow-2xl z-50 overflow-hidden">
              <div className="p-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
                    Real-time Alerts ({notifications.length})
                  </span>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" title="Live Firebase Synced" />
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setShowNotifications(false);
                      setIsNotificationCenterOpen(true);
                    }}
                    className="text-[11px] text-indigo-400 hover:text-indigo-300 font-medium font-mono"
                  >
                    Open Full Center ↗
                  </button>
                  <span className="text-slate-600">|</span>
                  <button
                    onClick={clearAllNotifications}
                    className="text-[11px] text-slate-400 hover:text-slate-200 font-medium font-mono"
                  >
                    Clear all
                  </button>
                </div>
              </div>

              {/* Quick Filter Bar */}
              <div className="px-3 py-1.5 bg-slate-900 border-b border-slate-800/80 flex items-center justify-between text-[10px] font-mono text-slate-400">
                <span className="text-slate-500">Live Firebase Engine</span>
                <button
                  onClick={() => {
                    setShowNotifications(false);
                    setIsNotificationCenterOpen(true);
                  }}
                  className="text-amber-400 hover:underline"
                >
                  Deadlines & Invoices
                </button>
              </div>

              <div className="max-h-80 overflow-y-auto divide-y divide-slate-800/60">
                {notifications.length === 0 ? (
                  <div className="p-6 text-center text-xs text-slate-500">
                    No active notifications
                  </div>
                ) : (
                  notifications.map((notif) => (
                    <div
                      key={notif.id}
                      onClick={() => {
                        markNotificationRead(notif.id);
                        if (notif.linkAction) {
                          setActiveTab(notif.linkAction);
                          setShowNotifications(false);
                        }
                      }}
                      className={`p-3 text-xs transition-colors cursor-pointer hover:bg-slate-800/50 ${
                        notif.isRead ? 'opacity-65 bg-slate-900' : 'bg-slate-850 border-l-2 border-indigo-500'
                      }`}
                    >
                      <div className="flex items-center justify-between font-medium text-slate-200 mb-1">
                        <span className="truncate">{notif.title}</span>
                        <span className="text-[10px] text-slate-500 font-mono">
                          {new Date(notif.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-slate-400 text-[11px] line-clamp-2 leading-relaxed">
                        {notif.message}
                      </p>
                    </div>
                  ))
                )}
              </div>

              {/* Bottom footer */}
              <div className="p-2 bg-slate-950 border-t border-slate-800 flex items-center justify-center">
                <button
                  onClick={() => {
                    setShowNotifications(false);
                    setIsNotificationCenterOpen(true);
                  }}
                  className="w-full py-1 text-center text-xs font-mono text-indigo-400 hover:text-indigo-300 font-semibold"
                >
                  View All Real-time Deadlines & Payments →
                </button>
              </div>
            </div>
          )}
        </div>

        {/* User Role Switcher Dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center gap-2 p-1.5 sm:px-2.5 sm:py-1.5 bg-slate-900 hover:bg-slate-850 border border-slate-800 transition-colors text-left"
          >
            <img
              src={currentUser.avatarUrl}
              alt={currentUser.name}
              className="w-6 h-6 object-cover border border-slate-700"
            />
            <div className="hidden sm:block text-left">
              <div className="text-xs font-semibold text-slate-200 leading-none">{currentUser.name}</div>
              <div className="text-[10px] text-slate-400 font-mono capitalize mt-0.5">
                {currentUser.role.replace('_', ' ')}
              </div>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
          </button>

          {showUserMenu && (
            <div className="absolute right-0 mt-2 w-72 bg-slate-900 border border-slate-700 shadow-2xl z-50 p-2">
              <div className="px-3 py-2 border-b border-slate-800 mb-2">
                <div className="text-xs font-bold text-slate-200">{currentUser.name}</div>
                <div className="text-[11px] text-slate-400 font-mono">{currentUser.email}</div>
                <div className={`mt-1.5 inline-block px-2 py-0.5 text-[10px] font-mono uppercase border ${roleBadgeStyles[currentUser.role]}`}>
                  Role: {currentUser.role.replace('_', ' ')}
                </div>
              </div>

              <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider px-3 py-1">
                Switch Test Role (RBAC Simulation):
              </div>
              <div className="space-y-1 mt-1">
                {allTeamMembers.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => {
                      switchUser(m.id);
                      setShowUserMenu(false);
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2 text-xs transition-colors ${
                      m.id === currentUser.id ? 'bg-indigo-600/20 text-indigo-300 font-semibold' : 'text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <img src={m.avatarUrl} alt="" className="w-5 h-5 rounded-none border border-slate-700" />
                      <div className="truncate text-left">
                        <div className="truncate">{m.name}</div>
                        <div className="text-[10px] text-slate-500 capitalize">{m.role.replace('_', ' ')}</div>
                      </div>
                    </div>
                    {m.id === currentUser.id && <Check className="w-3.5 h-3.5 text-indigo-400 shrink-0" />}
                  </button>
                ))}
              </div>

              <div className="pt-2 border-t border-slate-800 mt-2 space-y-1">
                <button
                  onClick={() => {
                    setActiveTab('team');
                    setShowUserMenu(false);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-800 transition-colors text-left"
                >
                  <Shield className="w-3.5 h-3.5 text-indigo-400" />
                  <span>My Profile & Social Accounts</span>
                </button>

                <button
                  onClick={() => {
                    setActiveTab('settings');
                    setShowUserMenu(false);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-1.5 text-xs text-amber-300 hover:text-amber-200 hover:bg-slate-800 transition-colors text-left font-semibold"
                >
                  <Crown className="w-3.5 h-3.5 text-amber-400" />
                  <span>Super Admin & Admin Portal</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* GitHub Repository Push & Export Modal */}
      <GitPushModal
        isOpen={showGitPushModal}
        onClose={() => setShowGitPushModal(false)}
      />
    </header>
  );
};
