import React from 'react';
import { useApp } from '../../context/AppContext';
import { 
  LayoutDashboard, 
  Users, 
  FolderKanban, 
  CheckSquare, 
  Receipt, 
  Calendar,
  MoreHorizontal,
  Bot
} from 'lucide-react';

interface MobileNavProps {
  onOpenMore: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({ onOpenMore }) => {
  const { activeTab, setActiveTab } = useApp();

  const PRIMARY_MOBILE_ITEMS = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'gemini', label: 'AI Copilot', icon: Bot },
    { id: 'tasks', label: 'Tasks', icon: CheckSquare },
    { id: 'invoices', label: 'Invoices', icon: Receipt },
    { id: 'calendar', label: 'Meet', icon: Calendar },
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-slate-950/95 backdrop-blur-lg border-t border-slate-800 px-2 py-1 flex items-center justify-around">
      {PRIMARY_MOBILE_ITEMS.map((item) => {
        const Icon = item.icon;
        const isActive = activeTab === item.id;
        return (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`flex flex-col items-center justify-center py-1.5 px-3 transition-colors ${
              isActive ? 'text-indigo-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Icon className="w-4 h-4 mb-0.5" />
            <span className="text-[10px] tracking-tight">{item.label}</span>
          </button>
        );
      })}

      <button
        onClick={onOpenMore}
        className="flex flex-col items-center justify-center py-1.5 px-3 text-slate-400 hover:text-slate-200"
      >
        <MoreHorizontal className="w-4 h-4 mb-0.5" />
        <span className="text-[10px] tracking-tight">More</span>
      </button>
    </div>
  );
};
