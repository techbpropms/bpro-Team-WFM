import React, { useState } from 'react';
import { 
  GitBranch, 
  UploadCloud, 
  Download, 
  ExternalLink, 
  CheckCircle2, 
  AlertTriangle, 
  X, 
  Copy, 
  Check, 
  Key, 
  Terminal,
  ShieldCheck,
  FolderArchive
} from 'lucide-react';
import { triggerConfetti } from '../../utils/confetti';

interface GitPushModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GitPushModal: React.FC<GitPushModalProps> = ({ isOpen, onClose }) => {
  const [token, setToken] = useState('');
  const [repoUrl, setRepoUrl] = useState('https://github.com/techbpropms/bpro-Team-WFM.git');
  const [branch, setBranch] = useState('main');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<{ success: boolean; message: string; output?: string } | null>(null);
  const [copiedCmd, setCopiedCmd] = useState(false);

  if (!isOpen) return null;

  const handlePush = async () => {
    if (!token.trim()) return;
    setIsLoading(true);
    setResult(null);

    try {
      const res = await fetch('/api/git-push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: token.trim(), repoUrl, branch })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setResult({
          success: true,
          message: data.message || 'Successfully pushed to GitHub repository!',
          output: data.output
        });
        triggerConfetti(0.6, 0.4);
      } else {
        setResult({
          success: false,
          message: data.error || 'Push failed. Please verify your token permissions.',
          output: data.details
        });
      }
    } catch (err: any) {
      setResult({
        success: false,
        message: err.message || 'Network request failed'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownloadZip = () => {
    window.location.href = '/bpro-team-wfm.zip';
    triggerConfetti(0.3, 0.3);
  };

  const handleDownloadBundle = () => {
    window.location.href = '/bpro-team-wfm.bundle';
  };

  const copyCliCommand = () => {
    const cmd = `git remote set-url origin ${repoUrl}\ngit push -u origin main`;
    navigator.clipboard.writeText(cmd);
    setCopiedCmd(true);
    setTimeout(() => setCopiedCmd(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-700 shadow-2xl p-6 space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
              <GitBranch className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wider font-sans">
                GitHub Repository Push & Export
              </h3>
              <p className="text-[11px] text-slate-400 font-mono">
                {repoUrl}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-200"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Option 1: Instant 1-Click Push via GitHub Token */}
        <div className="p-4 bg-slate-950 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-indigo-300 font-mono uppercase flex items-center gap-1.5">
              <UploadCloud className="w-4 h-4 text-indigo-400" />
              1. Push Directly to GitHub
            </span>
            <a
              href="https://github.com/settings/tokens/new?scopes=repo&description=Bpro-Team-WFM"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[10px] font-mono text-indigo-400 hover:text-indigo-300 flex items-center gap-1 underline"
            >
              Generate GitHub Token ↗
            </a>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            Enter your GitHub Personal Access Token (classic token with <strong className="text-slate-300 font-mono">repo</strong> scope, or fine-grained with write access to <strong className="text-slate-300 font-mono">techbpropms/bpro-Team-WFM</strong>).
          </p>

          <div className="space-y-2">
            <div>
              <label className="block text-[11px] font-mono text-slate-400 mb-1">
                GitHub Personal Access Token (PAT)
              </label>
              <div className="relative">
                <Key className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="password"
                  value={token}
                  onChange={(e) => setToken(e.target.value)}
                  placeholder="ghp_xxxxxxxxxxxxxxxxxxxx or github_pat_xxxxxxxx"
                  className="w-full pl-9 pr-3 py-2 bg-slate-900 border border-slate-700 text-xs text-slate-100 placeholder-slate-500 font-mono focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-between gap-3 pt-1">
              <div className="text-[10px] font-mono text-slate-500">
                Target: <span className="text-slate-300">origin/{branch}</span>
              </div>
              <button
                disabled={isLoading || !token.trim()}
                onClick={handlePush}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white text-xs font-mono font-bold flex items-center gap-2 transition-colors shadow-sm"
              >
                {isLoading ? (
                  <>
                    <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Pushing to GitHub...</span>
                  </>
                ) : (
                  <>
                    <UploadCloud className="w-4 h-4" />
                    <span>Push Code to GitHub</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {result && (
            <div className={`p-3 border text-xs font-mono ${
              result.success 
                ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-300' 
                : 'bg-rose-950/30 border-rose-500/40 text-rose-300'
            }`}>
              <div className="flex items-center gap-2 font-bold mb-1">
                {result.success ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <AlertTriangle className="w-4 h-4 text-rose-400" />}
                <span>{result.message}</span>
              </div>
              {result.output && (
                <pre className="mt-2 p-2 bg-black/50 text-[10px] text-slate-300 overflow-x-auto whitespace-pre-wrap max-h-36">
                  {result.output}
                </pre>
              )}
            </div>
          )}
        </div>

        {/* Option 2: 1-Click Download Source Code ZIP */}
        <div className="p-4 bg-slate-950 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-400 font-mono uppercase flex items-center gap-1.5">
              <FolderArchive className="w-4 h-4 text-emerald-400" />
              2. Download Complete Project (.ZIP)
            </span>
            <span className="text-[10px] font-mono text-slate-500">197 KB</span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            Download the entire project source code as a pristine ZIP archive to your local computer. Extract and run <code className="text-indigo-300 font-mono">npm install && npm run dev</code>.
          </p>
          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={handleDownloadZip}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-mono font-bold flex items-center gap-2 transition-colors shadow-sm"
            >
              <Download className="w-4 h-4" />
              <span>Download bpro-team-wfm.zip</span>
            </button>
            <button
              onClick={handleDownloadBundle}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono flex items-center gap-1.5 transition-colors border border-slate-700"
            >
              <Download className="w-3.5 h-3.5 text-slate-400" />
              <span>Git Bundle (.bundle)</span>
            </button>
          </div>
        </div>

        {/* Option 3: Terminal Command */}
        <div className="p-3 bg-slate-950 border border-slate-800 text-xs font-mono space-y-1.5">
          <div className="flex items-center justify-between text-slate-400 text-[11px]">
            <span className="flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-slate-400" />
              3. Or Push from Your Computer Terminal:
            </span>
            <button
              onClick={copyCliCommand}
              className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
            >
              {copiedCmd ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              <span>{copiedCmd ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
          <div className="p-2 bg-black/60 border border-slate-850 text-slate-300 select-all overflow-x-auto text-[11px]">
            <code>git remote set-url origin {repoUrl} && git push -u origin main</code>
          </div>
        </div>
      </div>
    </div>
  );
};
