import React, { useState } from 'react';
import { Task } from '../../types';
import { Calendar, Clock, AlertTriangle, X, ShieldAlert, ArrowRight } from 'lucide-react';

interface PushDeadlineModalProps {
  task: Task;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (taskId: string, newDate: string, reason: string) => void;
}

export const PushDeadlineModal: React.FC<PushDeadlineModalProps> = ({
  task,
  isOpen,
  onClose,
  onConfirm,
}) => {
  if (!isOpen) return null;

  // Compute next day by default
  const getNextDay = (dateStr: string) => {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return new Date().toISOString().substring(0, 10);
    d.setDate(d.getDate() + 1);
    return d.toISOString().substring(0, 10);
  };

  const [newDate, setNewDate] = useState<string>(getNextDay(task.dueDate));
  const [reason, setReason] = useState<string>('');
  const [error, setError] = useState<string>('');

  const REASON_PRESETS = [
    'Awaiting mandatory client approvals / feedback',
    'Third-party API dependency rate-limit or downtime',
    'Scope amendment requested by client stakeholder',
    'Technical architectural blocker requiring escalation',
    'Unexpected compliance / security verification delay',
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) {
      setError('A valid business justification is strictly required to push deadlines.');
      return;
    }
    if (newDate <= task.dueDate) {
      setError('The new deadline must be later than the current due date.');
      return;
    }
    onConfirm(task.id, newDate, reason.trim());
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-lg shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-slate-100">Amend & Reschedule Deadline</h2>
              <p className="text-xs text-slate-400">Compliance logged into immutable project audit trail</p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="text-slate-400 hover:text-slate-200 p-1 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div className="bg-slate-800/60 border border-slate-700/60 p-3.5 space-y-2">
            <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Target Task</div>
            <div className="text-sm font-medium text-slate-100">{task.title}</div>
            
            <div className="flex items-center gap-3 pt-2 text-xs">
              <div className="flex items-center gap-1.5 text-slate-400">
                <Calendar className="w-3.5 h-3.5 text-slate-500" />
                <span>Current Deadline:</span>
                <span className="font-mono text-slate-200 font-semibold">{task.dueDate}</span>
              </div>
              <ArrowRight className="w-3.5 h-3.5 text-amber-400" />
              <div className="flex items-center gap-1.5 text-amber-300 font-mono font-semibold">
                <span>New: {newDate}</span>
              </div>
            </div>
          </div>

          {/* Date Picker */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase tracking-wider">
              New Due Date
            </label>
            <div className="grid grid-cols-3 gap-2 mb-2">
              <button
                type="button"
                onClick={() => {
                  const d = new Date(task.dueDate);
                  d.setDate(d.getDate() + 1);
                  setNewDate(d.toISOString().substring(0, 10));
                }}
                className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 border border-slate-700 font-medium transition-colors"
              >
                +1 Day (Next Day)
              </button>
              <button
                type="button"
                onClick={() => {
                  const d = new Date(task.dueDate);
                  d.setDate(d.getDate() + 3);
                  setNewDate(d.toISOString().substring(0, 10));
                }}
                className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 border border-slate-700 font-medium transition-colors"
              >
                +3 Days
              </button>
              <button
                type="button"
                onClick={() => {
                  const d = new Date(task.dueDate);
                  d.setDate(d.getDate() + 7);
                  setNewDate(d.toISOString().substring(0, 10));
                }}
                className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 border border-slate-700 font-medium transition-colors"
              >
                +1 Week
              </button>
            </div>
            <input
              type="date"
              value={newDate}
              onChange={(e) => setNewDate(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-indigo-500 font-mono"
              required
            />
          </div>

          {/* Reason Input */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase tracking-wider">
              Mandatory Business Justification <span className="text-rose-400">*</span>
            </label>
            <textarea
              value={reason}
              onChange={(e) => {
                setReason(e.target.value);
                setError('');
              }}
              rows={3}
              placeholder="State clear operational reason for postponement (e.g., waiting for client asset approval, blocker in review)..."
              className="w-full bg-slate-950 border border-slate-700 p-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              required
            />

            {/* Quick Reason Presets */}
            <div className="mt-2 space-y-1">
              <span className="text-[11px] text-slate-400 font-medium">Quick reason presets:</span>
              <div className="flex flex-wrap gap-1.5">
                {REASON_PRESETS.map((p, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setReason(p);
                      setError('');
                    }}
                    className="text-[11px] px-2 py-0.5 bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-slate-700/80 transition-colors text-left"
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {error && (
            <div className="flex items-center gap-2 p-2.5 bg-rose-950/40 border border-rose-800/60 text-xs text-rose-300">
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{error}</span>
            </div>
          )}

          {/* Audit Note */}
          <div className="flex items-start gap-2 p-2.5 bg-indigo-950/30 border border-indigo-800/40 text-[11px] text-indigo-300">
            <ShieldAlert className="w-4 h-4 shrink-0 text-indigo-400 mt-0.5" />
            <span>
              This postponement will be permanently stamped with your user ID and notified to project stakeholders via Slack and in-app feeds.
            </span>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-slate-200 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold bg-amber-600 hover:bg-amber-500 text-white transition-colors flex items-center gap-1.5 shadow-lg shadow-amber-900/20"
            >
              <Clock className="w-3.5 h-3.5" />
              Confirm & Log Postponement
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
