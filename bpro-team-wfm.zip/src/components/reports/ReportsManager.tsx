import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  FileBarChart2, 
  Download, 
  FileSpreadsheet, 
  Calendar, 
  TrendingUp, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  DollarSign, 
  Briefcase, 
  Users, 
  ChevronRight,
  Filter 
} from 'lucide-react';
import { generateMonthlyReportPdf, generateExpenseAuditPdf } from '../../services/pdfGenerator';
import { exportToCsv } from '../../services/csvExport';

export const ReportsManager: React.FC = () => {
  const { clients, projects, tasks, invoices, expenses, allTeamMembers, formatCurrency } = useApp();

  const [activeReportTab, setActiveReportTab] = useState<'monthly' | 'weekly' | 'daily' | 'exports'>('monthly');
  const [selectedClientFilter, setSelectedClientFilter] = useState<string>('all');
  const [selectedProjectFilter, setSelectedProjectFilter] = useState<string>('all');

  // Filtered datasets for drill-down
  const filteredTasks = tasks.filter(t => {
    if (selectedClientFilter !== 'all' && t.clientId !== selectedClientFilter) return false;
    if (selectedProjectFilter !== 'all' && t.projectId !== selectedProjectFilter) return false;
    return true;
  });

  const filteredInvoices = invoices.filter(i => {
    if (selectedClientFilter !== 'all' && i.clientId !== selectedClientFilter) return false;
    if (selectedProjectFilter !== 'all' && i.projectId !== selectedProjectFilter) return false;
    return true;
  });

  const filteredExpenses = expenses.filter(e => {
    if (selectedClientFilter !== 'all' && e.clientId !== selectedClientFilter) return false;
    if (selectedProjectFilter !== 'all' && e.projectId !== selectedProjectFilter) return false;
    return true;
  });

  // Monthly stats
  const totalRevenue = filteredInvoices.filter(i => i.status === 'paid').reduce((acc, i) => acc + i.total, 0);
  const totalExpenses = filteredExpenses.reduce((acc, e) => acc + e.amount, 0);
  const netMargin = totalRevenue - totalExpenses;
  const billableHours = filteredTasks.reduce((acc, t) => acc + t.actualHours, 0);
  const completedTasks = filteredTasks.filter(t => t.status === 'completed').length;
  const postponedTasks = filteredTasks.filter(t => t.amendments.length > 0);
  const onTimeRate = filteredTasks.length > 0 ? Math.round(((filteredTasks.length - postponedTasks.length) / filteredTasks.length) * 100) : 100;

  // Breakdown tables
  const clientBreakdown = clients.map(c => {
    const cTasks = tasks.filter(t => t.clientId === c.id);
    const cInvoices = invoices.filter(i => i.clientId === c.id && i.status === 'paid');
    const cProjects = projects.filter(p => p.clientId === c.id);
    return {
      name: c.company || c.name,
      hours: cTasks.reduce((acc, t) => acc + t.actualHours, 0),
      revenue: cInvoices.reduce((acc, i) => acc + i.total, 0),
      projects: cProjects.length,
    };
  });

  const teamBreakdown = allTeamMembers.map(m => {
    const mTasks = tasks.filter(t => t.assignedToId === m.id);
    return {
      name: m.name,
      role: m.role.replace('_', ' ').toUpperCase(),
      hours: mTasks.reduce((acc, t) => acc + t.actualHours, 0),
      rate: m.hourlyRate || 3500,
    };
  });

  const handleDownloadMonthlyPdf = () => {
    generateMonthlyReportPdf({
      monthName: 'October',
      year: 2026,
      totalRevenue,
      totalExpenses,
      netMargin,
      billableHours,
      completedTasks,
      totalTasks: filteredTasks.length,
      onTimeRate,
      postponedCount: postponedTasks.length,
      clientBreakdown,
      teamBreakdown,
    });
  };

  // CSV Export Handlers
  const handleExportTasksCsv = () => {
    const rows = tasks.map(t => {
      const proj = projects.find(p => p.id === t.projectId);
      const assignee = allTeamMembers.find(m => m.id === t.assignedToId);
      return {
        'Task ID': t.id,
        'Title': t.title,
        'Project': proj?.code || '',
        'Assignee': assignee?.name || '',
        'Status': t.status.toUpperCase(),
        'Priority': t.priority.toUpperCase(),
        'Due Date': t.dueDate,
        'Est Hours': t.estimatedHours,
        'Actual Hours': t.actualHours,
        'Postponement Count': t.amendments.length,
      };
    });
    exportToCsv(`BproPMS_Tasks_Audit_Export_${new Date().toISOString().substring(0, 10)}`, rows);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-slate-900 border border-slate-800">
        <div>
          <h1 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <FileBarChart2 className="w-5 h-5 text-indigo-400" />
            <span>Robust Reporting, Analytics & Audits</span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Daily summaries, weekly velocity, monthly performance trends & executive branded PDF exports
          </p>
        </div>

        <button
          onClick={handleDownloadMonthlyPdf}
          className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Download Executive PDF Report</span>
        </button>
      </div>

      {/* Drill-down Interactive Filters */}
      <div className="p-3 bg-slate-900/60 border border-slate-800 flex flex-wrap items-center gap-3 text-xs">
        <div className="flex items-center gap-1.5 text-slate-400">
          <Filter className="w-3.5 h-3.5 text-indigo-400" />
          <span>Drill-down Scope:</span>
        </div>

        <select
          value={selectedClientFilter}
          onChange={(e) => setSelectedClientFilter(e.target.value)}
          className="bg-slate-950 border border-slate-800 text-slate-300 px-2.5 py-1 focus:outline-none focus:border-indigo-500 font-medium"
        >
          <option value="all">All Clients (Consolidated)</option>
          {clients.map(c => (
            <option key={c.id} value={c.id}>{c.company || c.name}</option>
          ))}
        </select>

        <select
          value={selectedProjectFilter}
          onChange={(e) => setSelectedProjectFilter(e.target.value)}
          className="bg-slate-950 border border-slate-800 text-slate-300 px-2.5 py-1 focus:outline-none focus:border-indigo-500 font-medium"
        >
          <option value="all">All Projects</option>
          {projects.map(p => (
            <option key={p.id} value={p.id}>{p.code} - {p.title}</option>
          ))}
        </select>

        {/* Report Nav Tabs */}
        <div className="ml-auto flex items-center border border-slate-800 bg-slate-950 p-0.5">
          <button
            onClick={() => setActiveReportTab('monthly')}
            className={`px-3 py-1 font-mono text-xs uppercase font-medium transition-colors ${
              activeReportTab === 'monthly' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Monthly Trends
          </button>
          <button
            onClick={() => setActiveReportTab('weekly')}
            className={`px-3 py-1 font-mono text-xs uppercase font-medium transition-colors ${
              activeReportTab === 'weekly' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Weekly Velocity
          </button>
          <button
            onClick={() => setActiveReportTab('daily')}
            className={`px-3 py-1 font-mono text-xs uppercase font-medium transition-colors ${
              activeReportTab === 'daily' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Daily Summaries
          </button>
          <button
            onClick={() => setActiveReportTab('exports')}
            className={`px-3 py-1 font-mono text-xs uppercase font-medium transition-colors ${
              activeReportTab === 'exports' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Data Exports
          </button>
        </div>
      </div>

      {/* Tab 1: Monthly Trends */}
      {activeReportTab === 'monthly' && (
        <div className="space-y-6">
          {/* KPI Summary Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 bg-slate-900 border border-slate-800 space-y-1">
              <span className="text-[11px] font-mono uppercase text-slate-400">Total Billed Revenue</span>
              <div className="text-xl font-bold font-mono text-indigo-400">{formatCurrency(totalRevenue)}</div>
            </div>
            <div className="p-4 bg-slate-900 border border-slate-800 space-y-1">
              <span className="text-[11px] font-mono uppercase text-slate-400">Operating Expenses</span>
              <div className="text-xl font-bold font-mono text-rose-400">{formatCurrency(totalExpenses)}</div>
            </div>
            <div className="p-4 bg-slate-900 border border-slate-800 space-y-1">
              <span className="text-[11px] font-mono uppercase text-slate-400">Net Operating Margin</span>
              <div className="text-xl font-bold font-mono text-emerald-400">{formatCurrency(netMargin)}</div>
            </div>
            <div className="p-4 bg-slate-900 border border-slate-800 space-y-1">
              <span className="text-[11px] font-mono uppercase text-slate-400">SLA On-Time Completion</span>
              <div className="text-xl font-bold font-mono text-slate-100">{onTimeRate}%</div>
            </div>
          </div>

          {/* Client Breakdown Table */}
          <div className="bg-slate-900 border border-slate-800 overflow-hidden">
            <div className="px-5 py-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                Client Portfolio Performance Breakdown
              </span>
              <span className="text-[11px] font-mono text-slate-500">October 2026 Audit Cycle</span>
            </div>

            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-950/70 border-b border-slate-800 text-slate-400 font-mono text-[11px]">
                  <th className="p-3.5">CLIENT NAME</th>
                  <th className="p-3.5">PROJECTS</th>
                  <th className="p-3.5">BILLABLE HOURS</th>
                  <th className="p-3.5 text-right">REVENUE REALIZED</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-200 font-mono">
                {clientBreakdown.map((c, i) => (
                  <tr key={i} className="hover:bg-slate-850/50">
                    <td className="p-3.5 font-sans font-semibold text-slate-100">{c.name}</td>
                    <td className="p-3.5">{c.projects} active</td>
                    <td className="p-3.5">{c.hours} hrs</td>
                    <td className="p-3.5 text-right text-emerald-400 font-bold">{formatCurrency(c.revenue)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: Weekly Velocity */}
      {activeReportTab === 'weekly' && (
        <div className="bg-slate-900 border border-slate-800 p-6 space-y-5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h2 className="text-sm font-bold text-slate-100">Weekly Sprint Velocity & Deliverables Meeting</h2>
              <p className="text-xs text-slate-400">Current cycle: Week 41 (Oct 05 - Oct 11, 2026)</p>
            </div>
            <span className="px-2.5 py-1 bg-emerald-950/80 text-emerald-400 border border-emerald-800 text-xs font-mono font-bold">
              SPRINT CADENCE: OPTIMAL
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-slate-950 border border-slate-800 space-y-2">
              <span className="text-xs text-slate-400 font-medium">Fulfilled Deliverables</span>
              <div className="text-2xl font-bold font-mono text-emerald-400">{completedTasks}</div>
              <p className="text-[11px] text-slate-500">Shipped on or ahead of scheduled milestones</p>
            </div>
            <div className="p-4 bg-slate-950 border border-slate-800 space-y-2">
              <span className="text-xs text-slate-400 font-medium">In-Flight / Under Review</span>
              <div className="text-2xl font-bold font-mono text-indigo-400">
                {filteredTasks.filter(t => t.status === 'in_progress' || t.status === 'in_review').length}
              </div>
              <p className="text-[11px] text-slate-500">Active engineering & client review phase</p>
            </div>
            <div className="p-4 bg-slate-950 border border-slate-800 space-y-2">
              <span className="text-xs text-slate-400 font-medium">Postponed with Justification</span>
              <div className="text-2xl font-bold font-mono text-amber-400">{postponedTasks.length}</div>
              <p className="text-[11px] text-slate-500">Formally rescheduled with stakeholder reasons</p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Daily Operational Log */}
      {activeReportTab === 'daily' && (
        <div className="bg-slate-900 border border-slate-800 p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h2 className="text-sm font-bold text-slate-100">Daily Standup & Operations Summary (Today)</h2>
            <span className="text-xs font-mono text-slate-400">{new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</span>
          </div>

          <div className="space-y-3">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Recent Deadline Postponements & Amendments
            </h3>
            {tasks.flatMap(t => t.amendments).length === 0 ? (
              <div className="text-xs text-slate-500">No deadline amendments logged today.</div>
            ) : (
              tasks.flatMap(t => t.amendments).map((amend) => (
                <div key={amend.id} className="p-3 bg-slate-950 border border-slate-800 text-xs space-y-1">
                  <div className="flex items-center justify-between font-mono text-[11px]">
                    <span className="text-amber-400 font-bold">
                      Rescheduled from {amend.previousDeadline} to {amend.newDeadline} (+{amend.pushedDays}d)
                    </span>
                    <span className="text-slate-500">{new Date(amend.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <div className="text-slate-300">
                    <strong>Reason Log:</strong> "{amend.reason}"
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono">
                    Authorized By: {amend.amendedByName}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Tab 4: Data Exports & Accounting */}
      {activeReportTab === 'exports' && (
        <div className="bg-slate-900 border border-slate-800 p-6 space-y-4">
          <div className="border-b border-slate-800 pb-3">
            <h2 className="text-sm font-bold text-slate-100">Accounting & Audit Export Engine</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Generate structured CSV spreadsheets for QuickBooks, Xero, NetSuite, and tax accounting reconciliation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
            <div className="p-4 bg-slate-950 border border-slate-800 space-y-3 flex flex-col justify-between">
              <div>
                <h3 className="text-xs font-bold text-slate-200 uppercase">Tasks & Work Ledger</h3>
                <p className="text-[11px] text-slate-400 mt-1">
                  Full dataset of estimated vs actual billable hours, project codes, deadlines, and amendment counts.
                </p>
              </div>
              <button
                onClick={handleExportTasksCsv}
                className="w-full px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
                <span>Export Tasks CSV</span>
              </button>
            </div>

            <div className="p-4 bg-slate-950 border border-slate-800 space-y-3 flex flex-col justify-between">
              <div>
                <h3 className="text-xs font-bold text-slate-200 uppercase">Invoices & Receivables Ledger</h3>
                <p className="text-[11px] text-slate-400 mt-1">
                  Subtotals, tax calculations, discounts, settled amounts, and client billing addresses.
                </p>
              </div>
              <button
                onClick={() => {
                  const rows = invoices.map(i => ({
                    'Invoice #': i.invoiceNumber,
                    'Client ID': i.clientId,
                    'Date': i.issueDate,
                    'Due Date': i.dueDate,
                    'Subtotal': i.subtotal,
                    'Tax': i.taxAmount,
                    'Total': i.total,
                    'Status': i.status,
                  }));
                  exportToCsv('Invoices_Ledger_Export', rows);
                }}
                className="w-full px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-indigo-400" />
                <span>Export Invoices CSV</span>
              </button>
            </div>

            <div className="p-4 bg-slate-950 border border-slate-800 space-y-3 flex flex-col justify-between">
              <div>
                <h3 className="text-xs font-bold text-slate-200 uppercase">Expenses & Receipts Audit</h3>
                <p className="text-[11px] text-slate-400 mt-1">
                  Itemized expenses, billable designations, approval dates, and submitter names.
                </p>
              </div>
              <button
                onClick={() => {
                  const rows = expenses.map(e => ({
                    'Expense ID': e.id,
                    'Date': e.date,
                    'Category': e.category,
                    'Amount': e.amount,
                    'Billable': e.isBillable ? 'YES' : 'NO',
                    'Status': e.status,
                    'Submitted By': e.submittedByName,
                  }));
                  exportToCsv('Expenses_Ledger_Export', rows);
                }}
                className="w-full px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-amber-400" />
                <span>Export Expenses CSV</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
