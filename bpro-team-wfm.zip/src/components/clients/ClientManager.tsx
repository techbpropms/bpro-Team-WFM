import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Client } from '../../types';
import { 
  Users, 
  Plus, 
  Mail, 
  Phone, 
  MapPin, 
  DollarSign, 
  Briefcase, 
  Receipt, 
  ExternalLink, 
  X,
  FileText
} from 'lucide-react';

export const ClientManager: React.FC = () => {
  const { clients, projects, invoices, currentUser, addClient, updateClient, searchQuery, formatCurrency } = useApp();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [selectedClientDetail, setSelectedClientDetail] = useState<Client | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [company, setCompany] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [taxId, setTaxId] = useState('');
  const [defaultHourlyRate, setDefaultHourlyRate] = useState(4500);
  const [notes, setNotes] = useState('');

  const filteredClients = clients.filter(c => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        c.name.toLowerCase().includes(q) ||
        c.company.toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleAddClient = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim()) return;

    addClient({
      name: name.trim(),
      company: company.trim() || name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      address: address.trim(),
      taxId: taxId.trim(),
      currency: 'INR',
      defaultHourlyRate: Number(defaultHourlyRate) || 4500,
      status: 'active',
      notes: notes.trim(),
    });

    setIsAddOpen(false);
    setName('');
    setCompany('');
    setEmail('');
    setPhone('');
    setAddress('');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-slate-900 border border-slate-800">
        <div>
          <h1 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <Users className="w-5 h-5 text-indigo-400" />
            <span>Clients & Account Management CRM</span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Manage enterprise client accounts, contractual billing terms, and linked project engagements
          </p>
        </div>

        {currentUser.permissions.canManageClients && (
          <button
            onClick={() => setIsAddOpen(true)}
            className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Client Account</span>
          </button>
        )}
      </div>

      {/* Clients Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filteredClients.map((client) => {
          const clientProjects = projects.filter(p => p.clientId === client.id);
          const clientInvoices = invoices.filter(i => i.clientId === client.id);
          const totalInvoiced = clientInvoices.reduce((acc, i) => acc + i.total, 0);
          const totalPaid = clientInvoices.filter(i => i.status === 'paid').reduce((acc, i) => acc + i.total, 0);

          return (
            <div
              key={client.id}
              className="bg-slate-900 border border-slate-800 p-5 space-y-4 hover:border-slate-700 transition-colors flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h2 className="text-sm font-bold text-slate-100">{client.company}</h2>
                    <div className="text-xs text-slate-400 font-medium">Contact: {client.name}</div>
                  </div>
                  <span className="px-2 py-0.5 text-[10px] font-mono bg-emerald-950/60 text-emerald-400 border border-emerald-800 uppercase font-semibold">
                    {client.status}
                  </span>
                </div>

                <div className="space-y-1.5 text-xs text-slate-400">
                  <div className="flex items-center gap-2 text-slate-300">
                    <Mail className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                    <span className="truncate">{client.email}</span>
                  </div>
                  {client.phone && (
                    <div className="flex items-center gap-2 text-slate-400">
                      <Phone className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                      <span>{client.phone}</span>
                    </div>
                  )}
                  {client.address && (
                    <div className="flex items-start gap-2 text-slate-400">
                      <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-0.5" />
                      <span className="line-clamp-1">{client.address}</span>
                    </div>
                  )}
                </div>

                {client.taxId && (
                  <div className="text-[10px] font-mono text-slate-500">
                    TAX / VAT: <span className="text-slate-400">{client.taxId}</span>
                  </div>
                )}
              </div>

              {/* Financial Stats Bar */}
              <div className="pt-3 border-t border-slate-800/80 space-y-2">
                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  <div className="bg-slate-950 p-2 border border-slate-800">
                    <div className="text-[10px] text-slate-500 uppercase">Hourly Baseline</div>
                    <div className="text-slate-200 font-bold">{formatCurrency(client.defaultHourlyRate)}/hr</div>
                  </div>
                  <div className="bg-slate-950 p-2 border border-slate-800">
                    <div className="text-[10px] text-slate-500 uppercase">Active Engagements</div>
                    <div className="text-slate-200 font-bold">{clientProjects.length} Projects</div>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-1">
                  <span>Total Settled:</span>
                  <span className="text-emerald-400 font-bold">{formatCurrency(totalPaid)}</span>
                </div>

                <button
                  onClick={() => setSelectedClientDetail(client)}
                  className="w-full mt-2 px-3 py-1.5 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 text-xs font-medium transition-colors"
                >
                  View Client Profile & History
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Client Modal */}
      {isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-lg shadow-2xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <Users className="w-4 h-4 text-indigo-400" />
                <span>Add Enterprise Client Account</span>
              </h2>
              <button onClick={() => setIsAddOpen(false)} className="text-slate-400 hover:text-slate-200">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddClient} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Company / Organization *</label>
                  <input
                    type="text"
                    value={company}
                    onChange={(e) => setCompany(e.target.value)}
                    placeholder="e.g. Apex BioTech Inc."
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 focus:outline-none focus:border-indigo-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Primary Contact Name *</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Dr. Robert Chen"
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 focus:outline-none focus:border-indigo-500"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Email Address *</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="billing@apexbio.org"
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 focus:outline-none focus:border-indigo-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Phone Number</label>
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+1 (555) 234-5678"
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 focus:outline-none focus:border-indigo-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Corporate Billing Address</label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Street, Suite, City, State, Country"
                  className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Tax / VAT ID</label>
                  <input
                    type="text"
                    value={taxId}
                    onChange={(e) => setTaxId(e.target.value)}
                    placeholder="US-EIN-XX-XXXXXXX"
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 focus:outline-none focus:border-indigo-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Standard Hourly Rate ($)</label>
                  <input
                    type="number"
                    value={defaultHourlyRate}
                    onChange={(e) => setDefaultHourlyRate(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 focus:outline-none focus:border-indigo-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Account Notes & Compliance Requirements</label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                  placeholder="e.g. Strict NDA, weekly status cadence, SLA requirements..."
                  className="w-full bg-slate-950 border border-slate-700 p-2.5 text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold transition-colors shadow-sm"
                >
                  Save Client Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Client Detail Drawer */}
      {selectedClientDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-2xl shadow-2xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h2 className="text-base font-bold text-slate-100">{selectedClientDetail.company}</h2>
                <div className="text-xs text-slate-400 font-mono mt-0.5">Account ID: {selectedClientDetail.id}</div>
              </div>
              <button onClick={() => setSelectedClientDetail(null)} className="text-slate-400 hover:text-slate-200">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="p-3 bg-slate-950 border border-slate-800 grid grid-cols-2 gap-3">
                <div>
                  <span className="text-slate-500 font-mono text-[10px] uppercase">Primary Contact</span>
                  <div className="text-slate-200 font-medium">{selectedClientDetail.name}</div>
                </div>
                <div>
                  <span className="text-slate-500 font-mono text-[10px] uppercase">Email</span>
                  <div className="text-slate-200 font-mono">{selectedClientDetail.email}</div>
                </div>
                <div>
                  <span className="text-slate-500 font-mono text-[10px] uppercase">Address</span>
                  <div className="text-slate-200">{selectedClientDetail.address || '-'}</div>
                </div>
                <div>
                  <span className="text-slate-500 font-mono text-[10px] uppercase">Tax ID</span>
                  <div className="text-slate-200 font-mono">{selectedClientDetail.taxId || '-'}</div>
                </div>
              </div>

              {/* Linked Projects */}
              <div>
                <h3 className="font-bold text-slate-200 mb-2 uppercase text-[11px] tracking-wider">
                  Associated Projects ({projects.filter(p => p.clientId === selectedClientDetail.id).length})
                </h3>
                <div className="space-y-2">
                  {projects.filter(p => p.clientId === selectedClientDetail.id).map(p => (
                    <div key={p.id} className="p-3 bg-slate-950 border border-slate-800 flex items-center justify-between">
                      <div>
                        <div className="font-semibold text-slate-200">{p.title}</div>
                        <div className="text-[11px] text-slate-400 font-mono">{p.code} &bull; Deadline: {p.targetDeadline}</div>
                      </div>
                      <div className="text-right font-mono">
                        <div className="text-slate-200 font-bold">{formatCurrency(p.budget)}</div>
                        <div className="text-[10px] text-slate-500">{p.totalLoggedHours} hrs logged</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Invoices */}
              <div>
                <h3 className="font-bold text-slate-200 mb-2 uppercase text-[11px] tracking-wider">
                  Billing History ({invoices.filter(i => i.clientId === selectedClientDetail.id).length})
                </h3>
                <div className="space-y-2">
                  {invoices.filter(i => i.clientId === selectedClientDetail.id).map(i => (
                    <div key={i.id} className="p-3 bg-slate-950 border border-slate-800 flex items-center justify-between">
                      <div>
                        <div className="font-semibold text-slate-200 font-mono">#{i.invoiceNumber}</div>
                        <div className="text-[11px] text-slate-400 font-mono">Due: {i.dueDate}</div>
                      </div>
                      <div className="text-right font-mono">
                        <div className="text-slate-200 font-bold">{formatCurrency(i.total, true)}</div>
                        <div className="text-[10px] text-slate-400 uppercase font-semibold">{i.status}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-3 border-t border-slate-800">
              <button
                onClick={() => setSelectedClientDetail(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
              >
                Close Profile
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
