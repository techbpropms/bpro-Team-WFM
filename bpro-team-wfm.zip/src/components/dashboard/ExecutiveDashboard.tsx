import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  TrendingUp, 
  Clock, 
  IndianRupee, 
  CheckCircle2, 
  AlertTriangle, 
  Video, 
  Calendar, 
  Plus, 
  ArrowUpRight, 
  ShieldAlert, 
  Receipt,
  CreditCard,
  Briefcase,
  ChevronRight,
  ExternalLink
} from 'lucide-react';
import { PushDeadlineModal } from '../modals/PushDeadlineModal';
import { Task } from '../../types';

interface ExecutiveDashboardProps {
  onNewTask: () => void;
  onNewInvoice: () => void;
  onNewMeeting: () => void;
  onNewExpense: () => void;
}

export const ExecutiveDashboard: React.FC<ExecutiveDashboardProps> = ({
  onNewTask,
  onNewInvoice,
  onNewMeeting,
  onNewExpense,
}) => {
  const { 
    clients, 
    projects, 
    tasks, 
    invoices, 
    expenses, 
    meetings, 
    currentUser, 
    setActiveTab,
    pushTaskDeadline,
    updateTaskStatus,
    formatCurrency
  } = useApp();

  const [selectedTaskForPush, setSelectedTaskForPush] = useState<Task | null>(null);

  // Financial Calculations
  const totalInvoiced = invoices.reduce((acc, i) => acc + i.total, 0);
  const paidRevenue = invoices.filter(i => i.status === 'paid').reduce((acc, i) => acc + i.total, 0);
  const pendingInvoiced = invoices.filter(i => i.status === 'sent' || i.status === 'overdue').reduce((acc, i) => acc + i.total, 0);
  const totalExpenses = expenses.reduce((acc, e) => acc + e.amount, 0);

  // Task Velocity & Metrics
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(t => t.status === 'completed').length;
  const inProgressTasks = tasks.filter(t => t.status === 'in_progress').length;
  const blockedTasks = tasks.filter(t => t.status === 'blocked').length;
  const tasksWithAmendments = tasks.filter(t => t.amendments.length > 0);

  const totalEstimatedHours = tasks.reduce((acc, t) => acc + t.estimatedHours, 0);
  const totalActualHours = tasks.reduce((acc, t) => acc + t.actualHours, 0);
  const onTimeRate = totalTasks > 0 ? Math.round(((totalTasks - tasksWithAmendments.length) / totalTasks) * 100) : 100;

  // Urgent Deadlines (due within 3 days or overdue)
  const todayStr = new Date().toISOString().substring(0, 10);
  const urgentTasks = tasks.filter(t => t.status !== 'completed' && t.dueDate <= todayStr);
  const upcomingTasks = tasks.filter(t => t.status !== 'completed' && t.dueDate > todayStr).slice(0, 4);

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Top Banner / Welcome & Quick Action Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950/40 border border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-100">Executive Operations Center</h1>
            <span className="px-2 py-0.5 text-[10px] font-mono bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Q4 LIVE
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Logged in as <strong className="text-slate-200">{currentUser.name}</strong> ({currentUser.role.replace('_', ' ')}) &bull; Enterprise SLA Compliance: 99.8%
          </p>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {currentUser.permissions.canEditDeadlines && (
            <button
              onClick={onNewTask}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Task</span>
            </button>
          )}

          {currentUser.permissions.canCreateInvoices && (
            <button
              onClick={onNewInvoice}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <Receipt className="w-3.5 h-3.5 text-emerald-400" />
              <span>Draft Invoice</span>
            </button>
          )}

          <button
            onClick={onNewMeeting}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Video className="w-3.5 h-3.5 text-sky-400" />
            <span>Google Meet</span>
          </button>

          <button
            onClick={onNewExpense}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <CreditCard className="w-3.5 h-3.5 text-amber-400" />
            <span>Log Expense</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Paid Revenue */}
        <div className="p-4 bg-slate-900 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-mono uppercase tracking-wider font-semibold">Realized Revenue</span>
            <IndianRupee className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-slate-100">
            {formatCurrency(paidRevenue)}
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
            <span>Outstanding Pending:</span>
            <span className="font-mono text-indigo-400">{formatCurrency(pendingInvoiced)}</span>
          </div>
        </div>

        {/* Productivity Hours */}
        <div className="p-4 bg-slate-900 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-mono uppercase tracking-wider font-semibold">Billable Productivity</span>
            <Clock className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-slate-100">
            {totalActualHours} <span className="text-xs text-slate-400 font-sans font-normal">hrs</span>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
            <span>Estimated Baseline:</span>
            <span className="font-mono text-slate-300">{totalEstimatedHours} hrs</span>
          </div>
        </div>

        {/* On-Time Delivery Rate */}
        <div className="p-4 bg-slate-900 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-mono uppercase tracking-wider font-semibold">On-Time Delivery</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-slate-100">
            {onTimeRate}%
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
            <span>Amended Deadlines:</span>
            <span className="font-mono text-amber-400">{tasksWithAmendments.length} logged</span>
          </div>
        </div>

        {/* Expense Burn */}
        <div className="p-4 bg-slate-900 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-mono uppercase tracking-wider font-semibold">Operating Expenses</span>
            <CreditCard className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-slate-100">
            {formatCurrency(totalExpenses)}
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
            <span>Pending Review:</span>
            <span className="font-mono text-amber-400">
              {expenses.filter(e => e.status === 'pending').length} items
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid: Urgent Attention & Project Workload */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Urgent Attention & Tasks */}
        <div className="lg:col-span-2 space-y-6">
          {/* Urgent / Overdue Tasks Box with 1-click Push Deadline */}
          <div className="bg-slate-900 border border-slate-800 overflow-hidden">
            <div className="px-5 py-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-400" />
                <h2 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                  Critical Work & Overdue Watch ({urgentTasks.length})
                </h2>
              </div>
              <button
                onClick={() => setActiveTab('tasks')}
                className="text-xs text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1"
              >
                <span>View all tasks</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="divide-y divide-slate-800/60">
              {urgentTasks.length === 0 ? (
                <div className="p-6 text-center text-xs text-emerald-400 flex items-center justify-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>All tasks are within acceptable timeline thresholds.</span>
                </div>
              ) : (
                urgentTasks.map((task) => {
                  const proj = projects.find(p => p.id === task.projectId);
                  return (
                    <div key={task.id} className="p-4 hover:bg-slate-850/40 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-mono px-1.5 py-0.5 bg-rose-950/60 text-rose-400 border border-rose-800/50 uppercase">
                            Due {task.dueDate}
                          </span>
                          <span className="text-[11px] font-mono text-slate-400">{proj?.code}</span>
                        </div>
                        <h3 className="text-xs font-semibold text-slate-100">{task.title}</h3>
                        <p className="text-[11px] text-slate-400 line-clamp-1">{task.description}</p>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => setSelectedTaskForPush(task)}
                          className="px-2.5 py-1 bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-600/40 text-xs font-medium flex items-center gap-1 transition-colors"
                          title="Push deadline to next day with valid business justification"
                        >
                          <Clock className="w-3 h-3 text-amber-400" />
                          <span>Push +1 Day</span>
                        </button>
                        <button
                          onClick={() => updateTaskStatus(task.id, 'completed')}
                          className="px-2.5 py-1 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-600/40 text-xs font-medium flex items-center gap-1 transition-colors"
                        >
                          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                          <span>Mark Done</span>
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Project Health & Budget Utilization */}
          <div className="bg-slate-900 border border-slate-800 overflow-hidden">
            <div className="px-5 py-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-indigo-400" />
                <h2 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                  Active Projects & Budget Health
                </h2>
              </div>
              <button
                onClick={() => setActiveTab('projects')}
                className="text-xs text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1"
              >
                <span>Project details</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              {projects.map((proj) => {
                const client = clients.find(c => c.id === proj.clientId);
                const projTasks = tasks.filter(t => t.projectId === proj.id);
                const doneCount = projTasks.filter(t => t.status === 'completed').length;
                const progressPct = projTasks.length > 0 ? Math.round((doneCount / projTasks.length) * 100) : 0;
                
                // Estimated billed vs budget
                const spentAmount = proj.totalLoggedHours * proj.hourlyRate;
                const budgetBurnPct = Math.min(100, Math.round((spentAmount / proj.budget) * 100));

                return (
                  <div key={proj.id} className="p-3.5 bg-slate-950/70 border border-slate-800/80 space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-xs text-slate-100">{proj.title}</span>
                          <span className="text-[10px] font-mono px-1 py-0.2 bg-slate-800 text-slate-300 border border-slate-700">
                            {proj.code}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400 mt-0.5">
                          Client: <strong className="text-slate-300">{client?.company || client?.name}</strong> &bull; Deadline: <span className="font-mono">{proj.targetDeadline}</span>
                        </div>
                      </div>

                      <div className="text-right font-mono shrink-0">
                        <div className="text-xs font-bold text-slate-200">
                          {formatCurrency(spentAmount)} <span className="text-slate-500 font-normal">/ {formatCurrency(proj.budget)}</span>
                        </div>
                        <div className="text-[10px] text-slate-400">{budgetBurnPct}% budget burn</div>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-[10px] text-slate-400">
                        <span>Work Tasks: {doneCount} of {projTasks.length} fulfilled ({progressPct}%)</span>
                        <span className="font-mono text-slate-300">{proj.totalLoggedHours} billable hrs logged</span>
                      </div>
                      <div className="w-full bg-slate-800 h-1.5 overflow-hidden">
                        <div
                          className="bg-indigo-500 h-full transition-all duration-300"
                          style={{ width: `${progressPct}%` }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Col: Google Meet & Scheduled Calendar Sessions + Fast Links */}
        <div className="space-y-6">
          {/* Upcoming Google Meet / Calendar Sessions */}
          <div className="bg-slate-900 border border-slate-800 overflow-hidden">
            <div className="px-5 py-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Video className="w-4 h-4 text-sky-400" />
                <h2 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                  Upcoming Google Meet Sessions
                </h2>
              </div>
              <button
                onClick={() => setActiveTab('calendar')}
                className="text-xs text-sky-400 hover:text-sky-300 font-medium"
              >
                Calendar
              </button>
            </div>

            <div className="p-4 space-y-3">
              {meetings.length === 0 ? (
                <div className="text-xs text-slate-500 text-center py-4">
                  No upcoming meetings scheduled
                </div>
              ) : (
                meetings.map((meet) => {
                  const client = clients.find(c => c.id === meet.clientId);
                  return (
                    <div key={meet.id} className="p-3 bg-slate-950 border border-slate-800/80 space-y-2">
                      <div className="text-xs font-semibold text-slate-200">{meet.title}</div>
                      <div className="text-[11px] text-slate-400">
                        Client: <span className="text-slate-300">{client?.company || client?.name}</span>
                      </div>
                      <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-1 border-t border-slate-800">
                        <span>{new Date(meet.startTime).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
                        <a
                          href={meet.googleMeetLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-2 py-0.5 bg-sky-600 hover:bg-sky-500 text-white text-[11px] font-medium flex items-center gap-1 transition-colors"
                        >
                          <Video className="w-3 h-3" />
                          <span>Join Meet</span>
                        </a>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Quick Reports & Accounting Exports */}
          <div className="p-5 bg-slate-900 border border-slate-800 space-y-3">
            <h2 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
              <Receipt className="w-4 h-4 text-emerald-400" />
              <span>Accounting & Document Exports</span>
            </h2>
            <p className="text-xs text-slate-400 leading-relaxed">
              Export executive branded PDFs and audit-ready CSV ledgers for financial reconciliation and stakeholder reporting.
            </p>
            <div className="space-y-2 pt-1">
              <button
                onClick={() => setActiveTab('reports')}
                className="w-full px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium flex items-center justify-between transition-colors"
              >
                <span>Generate Monthly Performance PDF</span>
                <ArrowUpRight className="w-3.5 h-3.5 text-slate-400" />
              </button>
              <button
                onClick={() => setActiveTab('invoices')}
                className="w-full px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium flex items-center justify-between transition-colors"
              >
                <span>View & Download Invoices</span>
                <ArrowUpRight className="w-3.5 h-3.5 text-slate-400" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Push Deadline Modal */}
      {selectedTaskForPush && (
        <PushDeadlineModal
          task={selectedTaskForPush}
          isOpen={!!selectedTaskForPush}
          onClose={() => setSelectedTaskForPush(null)}
          onConfirm={(taskId, newDate, reason) => {
            pushTaskDeadline(taskId, newDate, reason);
            setSelectedTaskForPush(null);
          }}
        />
      )}
    </div>
  );
};
