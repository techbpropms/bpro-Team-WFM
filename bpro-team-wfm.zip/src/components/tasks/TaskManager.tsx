import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Task, TaskStatus, TaskPriority, TeamMember, Project, Client } from '../../types';
import { 
  CheckSquare, 
  Plus, 
  Clock, 
  Calendar, 
  User, 
  Filter, 
  LayoutGrid, 
  List, 
  AlertTriangle, 
  CheckCircle2, 
  Video, 
  ChevronRight, 
  History, 
  ArrowRight,
  MoreVertical,
  X,
  ExternalLink
} from 'lucide-react';
import { PushDeadlineModal } from '../modals/PushDeadlineModal';
import { generateMeetCode } from '../../services/googleCalendar';

export const TaskManager: React.FC = () => {
  const { 
    tasks, 
    projects, 
    clients, 
    allTeamMembers, 
    currentUser, 
    addTask, 
    updateTask, 
    updateTaskStatus, 
    pushTaskDeadline, 
    deleteTask,
    searchQuery 
  } = useApp();

  const [viewMode, setViewMode] = useState<'kanban' | 'list'>('kanban');
  const [filterProject, setFilterProject] = useState<string>('all');
  const [filterAssignee, setFilterAssignee] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Modals state
  const [isNewTaskOpen, setIsNewTaskOpen] = useState(false);
  const [selectedTaskForPush, setSelectedTaskForPush] = useState<Task | null>(null);
  const [viewingAmendmentsTask, setViewingAmendmentsTask] = useState<Task | null>(null);

  // New Task Form
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newProjectId, setNewProjectId] = useState(projects[0]?.id || '');
  const [newAssigneeId, setNewAssigneeId] = useState(allTeamMembers[0]?.id || '');
  const [newPriority, setNewPriority] = useState<TaskPriority>('medium');
  const [newDueDate, setNewDueDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 3);
    return d.toISOString().substring(0, 10);
  });
  const [newEstHours, setNewEstHours] = useState(16);
  const [newTags, setNewTags] = useState('Frontend, API');
  const [createMeetLink, setCreateMeetLink] = useState(true);

  // Filter tasks
  const filteredTasks = tasks.filter((t) => {
    if (filterProject !== 'all' && t.projectId !== filterProject) return false;
    if (filterAssignee !== 'all' && t.assignedToId !== filterAssignee) return false;
    if (filterStatus !== 'all' && t.status !== filterStatus) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        t.title.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        t.tags.some(tag => tag.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newProjectId) return;

    const proj = projects.find(p => p.id === newProjectId);
    const meetLink = createMeetLink ? generateMeetCode(proj ? proj.code.toLowerCase().substring(0, 4) : 'task') : undefined;

    addTask({
      title: newTitle.trim(),
      description: newDesc.trim(),
      projectId: newProjectId,
      clientId: proj?.clientId || clients[0]?.id || '',
      status: 'backlog',
      priority: newPriority,
      assignedToId: newAssigneeId,
      createdBy: currentUser.id,
      dueDate: newDueDate,
      estimatedHours: Number(newEstHours) || 8,
      actualHours: 0,
      tags: newTags.split(',').map(s => s.trim()).filter(Boolean),
      googleMeetLink: meetLink,
    });

    setIsNewTaskOpen(false);
    setNewTitle('');
    setNewDesc('');
  };

  const priorityColors: Record<TaskPriority, string> = {
    low: 'text-slate-400 bg-slate-800/80 border-slate-700',
    medium: 'text-sky-300 bg-sky-950/60 border-sky-800/60',
    high: 'text-amber-300 bg-amber-950/60 border-amber-800/60',
    urgent: 'text-rose-300 bg-rose-950/60 border-rose-800/60',
  };

  const statusColumns: Array<{ id: TaskStatus; label: string; color: string }> = [
    { id: 'backlog', label: 'Backlog / Staged', color: 'border-slate-700' },
    { id: 'in_progress', label: 'In Progress', color: 'border-indigo-600' },
    { id: 'in_review', label: 'In Review / QA', color: 'border-sky-500' },
    { id: 'blocked', label: 'Blocked / Needs Action', color: 'border-rose-600' },
    { id: 'completed', label: 'Completed', color: 'border-emerald-600' },
  ];

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Top Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-slate-900 border border-slate-800">
        <div>
          <h1 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <CheckSquare className="w-5 h-5 text-indigo-400" />
            <span>Work Tracking & Assignments</span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time status updates, deadline amendment auditing & Google Meet synchronization
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* View toggle */}
          <div className="flex items-center border border-slate-700 bg-slate-950 p-0.5">
            <button
              onClick={() => setViewMode('kanban')}
              className={`px-2.5 py-1 text-xs font-medium flex items-center gap-1.5 transition-colors ${
                viewMode === 'kanban' ? 'bg-indigo-600 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>Kanban</span>
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`px-2.5 py-1 text-xs font-medium flex items-center gap-1.5 transition-colors ${
                viewMode === 'list' ? 'bg-indigo-600 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>List</span>
            </button>
          </div>

          {currentUser.permissions.canAssignTasks && (
            <button
              onClick={() => setIsNewTaskOpen(true)}
              className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create Task</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="p-3 bg-slate-900/60 border border-slate-800 flex flex-wrap items-center gap-3 text-xs">
        <div className="flex items-center gap-1.5 text-slate-400">
          <Filter className="w-3.5 h-3.5 text-indigo-400" />
          <span>Filters:</span>
        </div>

        {/* Project Filter */}
        <select
          value={filterProject}
          onChange={(e) => setFilterProject(e.target.value)}
          className="bg-slate-950 border border-slate-800 text-slate-300 px-2.5 py-1 focus:outline-none focus:border-indigo-500 font-medium"
        >
          <option value="all">All Projects</option>
          {projects.map((p) => (
            <option key={p.id} value={p.id}>{p.code} - {p.title.substring(0, 24)}...</option>
          ))}
        </select>

        {/* Assignee Filter */}
        <select
          value={filterAssignee}
          onChange={(e) => setFilterAssignee(e.target.value)}
          className="bg-slate-950 border border-slate-800 text-slate-300 px-2.5 py-1 focus:outline-none focus:border-indigo-500 font-medium"
        >
          <option value="all">All Assignees (Team & Consultants)</option>
          {allTeamMembers.map((m) => (
            <option key={m.id} value={m.id}>
              {m.name} ({m.isExternal ? 'Consultant' : m.role})
            </option>
          ))}
        </select>

        {/* Status Filter */}
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="bg-slate-950 border border-slate-800 text-slate-300 px-2.5 py-1 focus:outline-none focus:border-indigo-500 font-medium"
        >
          <option value="all">All Statuses</option>
          <option value="backlog">Backlog</option>
          <option value="in_progress">In Progress</option>
          <option value="in_review">In Review</option>
          <option value="blocked">Blocked</option>
          <option value="completed">Completed</option>
        </select>

        <span className="text-slate-500 ml-auto font-mono text-[11px]">
          Showing {filteredTasks.length} of {tasks.length} tasks
        </span>
      </div>

      {/* Kanban Board View */}
      {viewMode === 'kanban' ? (
        <div className="grid grid-cols-1 md:grid-cols-3 xl:grid-cols-5 gap-3.5">
          {statusColumns.map((col) => {
            const colTasks = filteredTasks.filter(t => t.status === col.id);
            return (
              <div key={col.id} className="bg-slate-900 border border-slate-800 flex flex-col min-h-[500px]">
                {/* Column Header */}
                <div className={`p-3 bg-slate-950 border-b border-t-2 ${col.color} border-slate-800 flex items-center justify-between`}>
                  <span className="text-xs font-bold text-slate-200 tracking-wide uppercase">
                    {col.label}
                  </span>
                  <span className="text-[11px] font-mono px-1.5 py-0.2 bg-slate-800 text-slate-300 font-bold">
                    {colTasks.length}
                  </span>
                </div>

                {/* Column Cards */}
                <div className="p-2.5 space-y-2.5 flex-1 overflow-y-auto">
                  {colTasks.length === 0 ? (
                    <div className="text-center py-8 text-[11px] text-slate-600 border border-dashed border-slate-800/80 p-4">
                      No tasks
                    </div>
                  ) : (
                    colTasks.map((task) => {
                      const proj = projects.find(p => p.id === task.projectId);
                      const assignee = allTeamMembers.find(m => m.id === task.assignedToId);
                      const hasAmendments = task.amendments.length > 0;

                      return (
                        <div
                          key={task.id}
                          className="p-3 bg-slate-950/80 hover:bg-slate-950 border border-slate-800/90 hover:border-slate-700 transition-all space-y-2.5 shadow-sm group"
                        >
                          {/* Code, Priority & History Indicator */}
                          <div className="flex items-center justify-between gap-1 text-[10px]">
                            <span className="font-mono text-slate-400 font-semibold">{proj?.code}</span>
                            <div className="flex items-center gap-1.5">
                              {hasAmendments && (
                                <button
                                  onClick={() => setViewingAmendmentsTask(task)}
                                  className="text-amber-400 hover:text-amber-300 flex items-center gap-0.5"
                                  title={`Pushed ${task.amendments.length} time(s). Click to view audit log.`}
                                >
                                  <History className="w-3 h-3" />
                                  <span className="font-mono">{task.amendments.length}</span>
                                </button>
                              )}
                              <span className={`px-1.5 py-0.2 border uppercase font-mono font-semibold ${priorityColors[task.priority]}`}>
                                {task.priority}
                              </span>
                            </div>
                          </div>

                          {/* Title & Desc */}
                          <div>
                            <h3 className="text-xs font-semibold text-slate-100 group-hover:text-indigo-300 transition-colors">
                              {task.title}
                            </h3>
                            <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                              {task.description}
                            </p>
                          </div>

                          {/* Tags */}
                          {task.tags.length > 0 && (
                            <div className="flex flex-wrap gap-1">
                              {task.tags.map((tag, i) => (
                                <span key={i} className="text-[9px] font-mono px-1 py-0.2 bg-slate-900 text-slate-400 border border-slate-800">
                                  #{tag}
                                </span>
                              ))}
                            </div>
                          )}

                          {/* Deadline & Meet Link */}
                          <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-900 font-mono">
                            <div className="flex items-center gap-1 text-slate-400">
                              <Calendar className="w-3 h-3 text-slate-500" />
                              <span className={task.dueDate <= new Date().toISOString().substring(0, 10) && task.status !== 'completed' ? 'text-rose-400 font-bold' : ''}>
                                {task.dueDate}
                              </span>
                            </div>

                            {task.googleMeetLink && (
                              <a
                                href={task.googleMeetLink}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-sky-400 hover:text-sky-300 flex items-center gap-0.5 text-[10px]"
                                title="Open Google Meet Session"
                              >
                                <Video className="w-3 h-3" />
                                <span>Meet</span>
                              </a>
                            )}
                          </div>

                          {/* Assignee & Action Buttons */}
                          <div className="flex items-center justify-between pt-1 border-t border-slate-900/60">
                            <div className="flex items-center gap-1.5 truncate">
                              {assignee?.avatarUrl ? (
                                <img src={assignee.avatarUrl} alt="" className="w-4 h-4 object-cover" />
                              ) : (
                                <User className="w-3.5 h-3.5 text-slate-500" />
                              )}
                              <span className="text-[10px] text-slate-400 truncate">
                                {assignee?.name} {assignee?.isExternal && '(Ext)'}
                              </span>
                            </div>

                            {/* Reschedule button */}
                            {currentUser.permissions.canEditDeadlines && task.status !== 'completed' && (
                              <button
                                onClick={() => setSelectedTaskForPush(task)}
                                className="px-2 py-0.5 text-[10px] bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-800/40 font-medium transition-colors"
                                title="Push deadline to next day with reason"
                              >
                                +1 Day
                              </button>
                            )}
                          </div>

                          {/* Quick Status Dropdown */}
                          <div className="pt-1">
                            <select
                              value={task.status}
                              onChange={(e) => updateTaskStatus(task.id, e.target.value as TaskStatus)}
                              className="w-full bg-slate-900 border border-slate-800 text-[10px] text-slate-300 px-1.5 py-1 focus:outline-none focus:border-indigo-500"
                            >
                              <option value="backlog">Move to: Backlog</option>
                              <option value="in_progress">Move to: In Progress</option>
                              <option value="in_review">Move to: In Review</option>
                              <option value="blocked">Move to: Blocked</option>
                              <option value="completed">Move to: Completed</option>
                            </select>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* List View */
        <div className="bg-slate-900 border border-slate-800 overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-950 border-b border-slate-800 text-slate-400 font-mono text-[11px]">
                <th className="p-3.5">TASK TITLE & PROJECT</th>
                <th className="p-3.5">ASSIGNEE</th>
                <th className="p-3.5">STATUS</th>
                <th className="p-3.5">PRIORITY</th>
                <th className="p-3.5">DUE DATE</th>
                <th className="p-3.5">HOURS</th>
                <th className="p-3.5 text-right">ACTIONS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {filteredTasks.map((task) => {
                const proj = projects.find(p => p.id === task.projectId);
                const assignee = allTeamMembers.find(m => m.id === task.assignedToId);
                const hasAmendments = task.amendments.length > 0;

                return (
                  <tr key={task.id} className="hover:bg-slate-850/50 transition-colors">
                    <td className="p-3.5">
                      <div className="font-semibold text-slate-100">{task.title}</div>
                      <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                        {proj?.code} &bull; {task.tags.join(', ')}
                      </div>
                    </td>
                    <td className="p-3.5">
                      <div className="flex items-center gap-2">
                        {assignee?.avatarUrl && (
                          <img src={assignee.avatarUrl} alt="" className="w-5 h-5 object-cover" />
                        )}
                        <div>
                          <div className="font-medium text-slate-200">{assignee?.name}</div>
                          <div className="text-[10px] text-slate-500 font-mono">
                            {assignee?.isExternal ? 'External Consultant' : assignee?.role}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="p-3.5">
                      <select
                        value={task.status}
                        onChange={(e) => updateTaskStatus(task.id, e.target.value as TaskStatus)}
                        className="bg-slate-950 border border-slate-800 text-xs text-slate-300 px-2 py-1 focus:outline-none focus:border-indigo-500 uppercase font-mono"
                      >
                        <option value="backlog">Backlog</option>
                        <option value="in_progress">In Progress</option>
                        <option value="in_review">In Review</option>
                        <option value="blocked">Blocked</option>
                        <option value="completed">Completed</option>
                      </select>
                    </td>
                    <td className="p-3.5">
                      <span className={`px-2 py-0.5 border text-[10px] uppercase font-mono font-semibold ${priorityColors[task.priority]}`}>
                        {task.priority}
                      </span>
                    </td>
                    <td className="p-3.5 font-mono">
                      <div className="flex items-center gap-1.5">
                        <span className={task.dueDate <= new Date().toISOString().substring(0, 10) && task.status !== 'completed' ? 'text-rose-400 font-bold' : 'text-slate-300'}>
                          {task.dueDate}
                        </span>
                        {hasAmendments && (
                          <button
                            onClick={() => setViewingAmendmentsTask(task)}
                            className="p-1 text-amber-400 hover:text-amber-300"
                            title={`Rescheduled ${task.amendments.length} time(s). Click to view audit log.`}
                          >
                            <History className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                    <td className="p-3.5 font-mono text-[11px] text-slate-400">
                      {task.actualHours} / {task.estimatedHours}h
                    </td>
                    <td className="p-3.5 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {task.googleMeetLink && (
                          <a
                            href={task.googleMeetLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1.5 bg-sky-950 text-sky-400 border border-sky-800 hover:bg-sky-900"
                            title="Join Google Meet"
                          >
                            <Video className="w-3.5 h-3.5" />
                          </a>
                        )}
                        {currentUser.permissions.canEditDeadlines && task.status !== 'completed' && (
                          <button
                            onClick={() => setSelectedTaskForPush(task)}
                            className="px-2 py-1 bg-amber-950/60 text-amber-300 border border-amber-800 text-xs font-medium hover:bg-amber-900/60"
                            title="Amend deadline"
                          >
                            Push Date
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Task Creation Modal */}
      {isNewTaskOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-xl shadow-2xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <CheckSquare className="w-4 h-4 text-indigo-400" />
                <span>Create Operational Task</span>
              </h2>
              <button onClick={() => setIsNewTaskOpen(false)} className="text-slate-400 hover:text-slate-200">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateTask} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Task Title *</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Implement Zero-knowledge encryption audit trail"
                  className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 focus:outline-none focus:border-indigo-500"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Description / Acceptance Criteria</label>
                <textarea
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  rows={3}
                  placeholder="Detailed deliverables, technical specs, security requirements..."
                  className="w-full bg-slate-950 border border-slate-700 p-2.5 text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Assigned Project *</label>
                  <select
                    value={newProjectId}
                    onChange={(e) => setNewProjectId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    {projects.map((p) => (
                      <option key={p.id} value={p.id}>{p.code} - {p.title}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Assignee (Team / Consultant) *</label>
                  <select
                    value={newAssigneeId}
                    onChange={(e) => setNewAssigneeId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    {allTeamMembers.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.name} ({m.isExternal ? 'External Consultant' : m.role})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Priority</label>
                  <select
                    value={newPriority}
                    onChange={(e) => setNewPriority(e.target.value as TaskPriority)}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="urgent">Urgent</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Due Date *</label>
                  <input
                    type="date"
                    value={newDueDate}
                    onChange={(e) => setNewDueDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500 font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Est. Hours</label>
                  <input
                    type="number"
                    value={newEstHours}
                    onChange={(e) => setNewEstHours(Number(e.target.value))}
                    min={1}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Tags (comma-separated)</label>
                <input
                  type="text"
                  value={newTags}
                  onChange={(e) => setNewTags(e.target.value)}
                  placeholder="Backend, Architecture, HIPAA"
                  className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="p-3 bg-slate-950 border border-slate-800 flex items-center gap-2">
                <input
                  type="checkbox"
                  id="meetCheckbox"
                  checked={createMeetLink}
                  onChange={(e) => setCreateMeetLink(e.target.checked)}
                  className="rounded-none bg-slate-900 border-slate-700 text-indigo-600 focus:ring-0"
                />
                <label htmlFor="meetCheckbox" className="text-slate-300 text-xs cursor-pointer flex items-center gap-1.5">
                  <Video className="w-3.5 h-3.5 text-sky-400" />
                  <span>Generate instant Google Meet link for task reviews</span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsNewTaskOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold transition-colors shadow-sm"
                >
                  Create & Schedule Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Deadline Amendment History Modal */}
      {viewingAmendmentsTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-lg shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <History className="w-4 h-4 text-amber-400" />
                <h2 className="text-sm font-bold text-slate-100">Deadline Amendment Audit Trail</h2>
              </div>
              <button onClick={() => setViewingAmendmentsTask(null)} className="text-slate-400 hover:text-slate-200">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="text-xs text-slate-300">
              <span className="font-semibold text-slate-100">{viewingAmendmentsTask.title}</span>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Every rescheduling action requires a mandatory business justification logged for client transparency.
              </p>
            </div>

            <div className="max-h-64 overflow-y-auto space-y-3">
              {viewingAmendmentsTask.amendments.length === 0 ? (
                <div className="text-xs text-slate-500 text-center py-4">No amendments recorded.</div>
              ) : (
                viewingAmendmentsTask.amendments.map((a) => (
                  <div key={a.id} className="p-3 bg-slate-950 border border-slate-800 space-y-2 text-xs">
                    <div className="flex items-center justify-between text-[11px]">
                      <div className="flex items-center gap-2 font-mono">
                        <span className="text-slate-400 line-through">{a.previousDeadline}</span>
                        <ArrowRight className="w-3 h-3 text-amber-400" />
                        <span className="text-amber-300 font-bold">{a.newDeadline}</span>
                        <span className="px-1.5 py-0.2 bg-amber-950/80 text-amber-400 border border-amber-800 text-[10px]">
                          +{a.pushedDays}d
                        </span>
                      </div>
                      <span className="text-slate-500 text-[10px] font-mono">
                        {new Date(a.timestamp).toLocaleDateString()}
                      </span>
                    </div>

                    <div className="bg-slate-900 p-2.5 border border-slate-800 text-slate-300 text-[11px] leading-relaxed">
                      <strong className="text-slate-400 block text-[10px] uppercase font-mono mb-0.5">Logged Justification:</strong>
                      "{a.reason}"
                    </div>

                    <div className="text-[10px] text-slate-500 font-mono">
                      Authorized by: <span className="text-slate-300">{a.amendedByName}</span>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="flex justify-end pt-2 border-t border-slate-800">
              <button
                onClick={() => setViewingAmendmentsTask(null)}
                className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
              >
                Close Audit Log
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Push Deadline Modal */}
      {selectedTaskForPush && (
        <PushDeadlineModal
          task={selectedTaskForPush}
          isOpen={!!selectedTaskForPush}
          onClose={() => setSelectedTaskForPush(null)}
          onConfirm={(taskId, newDate, reason) => {
            pushTaskDeadline(taskId, newDate, reason);
            setSelectedTaskForPush(null);
          }}
        />
      )}
    </div>
  );
};
