import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Invoice, InvoiceLineItem, InvoiceStatus, Client, Project } from '../../types';
import { 
  Receipt, 
  Plus, 
  Download, 
  FileSpreadsheet, 
  DollarSign, 
  Calendar, 
  CheckCircle2, 
  AlertCircle, 
  Send, 
  Trash2, 
  FileText, 
  X,
  ExternalLink,
  Sparkles
} from 'lucide-react';
import { generateInvoicePdf } from '../../services/pdfGenerator';
import { exportToCsv } from '../../services/csvExport';

export const InvoiceManager: React.FC = () => {
  const { 
    invoices, 
    clients, 
    projects, 
    expenses, 
    tasks, 
    currentUser, 
    createInvoice, 
    updateInvoice, 
    deleteInvoice,
    searchQuery,
    formatCurrency
  } = useApp();

  const [isNewInvoiceOpen, setIsNewInvoiceOpen] = useState(false);
  const [selectedClientId, setSelectedClientId] = useState(clients[0]?.id || '');
  const [selectedProjectId, setSelectedProjectId] = useState(projects[0]?.id || '');
  const [invoiceNumber, setInvoiceNumber] = useState(`INV-2026-${String(invoices.length + 104).padStart(4, '0')}`);
  const [issueDate, setIssueDate] = useState(new Date().toISOString().substring(0, 10));
  const [dueDate, setDueDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 30);
    return d.toISOString().substring(0, 10);
  });
  const [currency, setCurrency] = useState('INR');
  const [taxRate, setTaxRate] = useState(18);
  const [discountRate, setDiscountRate] = useState(0);
  const [paymentTerms, setPaymentTerms] = useState('Net 30');
  const [notes, setNotes] = useState('Thank you for your business. Remittance required within stated payment terms.');
  const [bankDetails, setBankDetails] = useState('HDFC Bank Ltd | A/c: 50200084920194 | IFSC: HDFC0001234 | UPI: bropms@hdfcbank');

  // Dynamic Line Items
  const [lineItems, setLineItems] = useState<InvoiceLineItem[]>([
    {
      id: 'item_1',
      description: 'Senior Software Architecture & Cloud Deliverables',
      quantity: 40,
      unitPrice: 4500,
      amount: 180000,
      type: 'hours',
    },
  ]);

  // Status Filter
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const filteredInvoices = invoices.filter((inv) => {
    if (statusFilter !== 'all' && inv.status !== statusFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const client = clients.find(c => c.id === inv.clientId);
      return (
        inv.invoiceNumber.toLowerCase().includes(q) ||
        (client?.company || '').toLowerCase().includes(q) ||
        (client?.name || '').toLowerCase().includes(q)
      );
    }
    return true;
  });

  // Calculate totals
  const totalInvoiced = invoices.reduce((acc, i) => acc + i.total, 0);
  const paidTotal = invoices.filter(i => i.status === 'paid').reduce((acc, i) => acc + i.total, 0);
  const outstandingTotal = invoices.filter(i => i.status === 'sent' || i.status === 'overdue').reduce((acc, i) => acc + i.total, 0);

  // Line Item Mutators
  const addLineItem = () => {
    setLineItems([
      ...lineItems,
      {
        id: `item_${Date.now()}`,
        description: 'Professional Services / Engineering Milestone',
        quantity: 1,
        unitPrice: 1500,
        amount: 1500,
        type: 'fixed_milestone',
      },
    ]);
  };

  const updateLineItem = (id: string, updates: Partial<InvoiceLineItem>) => {
    setLineItems(
      lineItems.map(item => {
        if (item.id === id) {
          const updated = { ...item, ...updates };
          updated.amount = updated.quantity * updated.unitPrice;
          return updated;
        }
        return item;
      })
    );
  };

  const removeLineItem = (id: string) => {
    if (lineItems.length === 1) return;
    setLineItems(lineItems.filter(i => i.id !== id));
  };

  // Automated pull from logged project hours and approved unbilled expenses
  const autoPopulateFromProject = (projectId: string) => {
    const proj = projects.find(p => p.id === projectId);
    if (!proj) return;

    setSelectedClientId(proj.clientId);
    const newItems: InvoiceLineItem[] = [];

    // Project billable hours
    if (proj.totalLoggedHours > 0) {
      newItems.push({
        id: `item_hrs_${Date.now()}`,
        description: `${proj.title} - Logged Engineering Hours (${proj.totalLoggedHours} hrs @ ₹${proj.hourlyRate}/hr)`,
        quantity: proj.totalLoggedHours,
        unitPrice: proj.hourlyRate,
        amount: proj.totalLoggedHours * proj.hourlyRate,
        type: 'hours',
      });
    }

    // Approved unbilled expenses
    const projExpenses = expenses.filter(e => e.projectId === projectId && e.status === 'approved' && e.isBillable);
    projExpenses.forEach(exp => {
      newItems.push({
        id: `item_exp_${exp.id}`,
        description: `Expense: ${exp.category.replace('_', ' ')} - ${exp.description}`,
        quantity: 1,
        unitPrice: exp.amount,
        amount: exp.amount,
        type: 'expense',
      });
    });

    if (newItems.length > 0) {
      setLineItems(newItems);
    }
  };

  // Form submit
  const handleCreateInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedClientId) return;

    const subtotal = lineItems.reduce((acc, i) => acc + i.amount, 0);
    const discountAmount = (subtotal * discountRate) / 100;
    const taxableAmount = subtotal - discountAmount;
    const taxAmount = (taxableAmount * taxRate) / 100;
    const total = taxableAmount + taxAmount;

    createInvoice({
      invoiceNumber,
      clientId: selectedClientId,
      projectId: selectedProjectId || undefined,
      issueDate,
      dueDate,
      status: 'draft',
      currency,
      items: lineItems,
      subtotal,
      taxRate,
      taxAmount,
      discountRate,
      discountAmount,
      total,
      notes,
      paymentTerms,
      bankDetails,
    });

    setIsNewInvoiceOpen(false);
  };

  // Export CSV
  const handleExportCsv = () => {
    const rows = invoices.map(i => {
      const client = clients.find(c => c.id === i.clientId);
      const proj = projects.find(p => p.id === i.projectId);
      return {
        'Invoice Number': i.invoiceNumber,
        'Client': client?.company || client?.name || '',
        'Project Code': proj?.code || '',
        'Status': i.status.toUpperCase(),
        'Issue Date': i.issueDate,
        'Due Date': i.dueDate,
        'Subtotal': i.subtotal,
        'Tax Rate %': i.taxRate,
        'Tax Amount': i.taxAmount,
        'Discount': i.discountAmount,
        'Total Due': i.total,
        'Currency': i.currency,
      };
    });
    exportToCsv(`BproPMS_Invoices_Accounting_Ledger_${new Date().toISOString().substring(0, 10)}`, rows);
  };

  const statusColors: Record<InvoiceStatus, string> = {
    draft: 'bg-slate-800 text-slate-300 border-slate-700',
    sent: 'bg-indigo-950/80 text-indigo-400 border-indigo-800/80',
    paid: 'bg-emerald-950/80 text-emerald-400 border-emerald-800/80',
    overdue: 'bg-rose-950/80 text-rose-400 border-rose-800/80',
    cancelled: 'bg-slate-900 text-slate-500 border-slate-800',
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-slate-900 border border-slate-800">
        <div>
          <h1 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <Receipt className="w-5 h-5 text-indigo-400" />
            <span>Automated Billing & Invoices</span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Auto-generate invoices from billable hours & expenses &bull; Executive branded PDF downloads &bull; CSV accounting exports
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            title="Download CSV for QuickBooks, Xero, or accounting audit"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </button>

          {currentUser.permissions.canCreateInvoices && (
            <button
              onClick={() => setIsNewInvoiceOpen(true)}
              className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create Invoice</span>
            </button>
          )}
        </div>
      </div>

      {/* KPI Financial Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 bg-slate-900 border border-slate-800 space-y-1">
          <span className="text-[11px] font-mono uppercase text-slate-400">Total Invoiced (Cumulative)</span>
          <div className="text-xl font-bold font-mono text-slate-100">{formatCurrency(totalInvoiced)}</div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 space-y-1">
          <span className="text-[11px] font-mono uppercase text-emerald-400">Settled / Collected</span>
          <div className="text-xl font-bold font-mono text-emerald-400">{formatCurrency(paidTotal)}</div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 space-y-1">
          <span className="text-[11px] font-mono uppercase text-indigo-400">Outstanding Receivables</span>
          <div className="text-xl font-bold font-mono text-indigo-400">{formatCurrency(outstandingTotal)}</div>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="p-3 bg-slate-900/60 border border-slate-800 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          <span className="text-slate-400">Filter Status:</span>
          <div className="flex items-center gap-1">
            {['all', 'draft', 'sent', 'paid', 'overdue'].map((status) => (
              <button
                key={status}
                onClick={() => setStatusFilter(status)}
                className={`px-2.5 py-1 uppercase font-mono text-[10px] transition-colors ${
                  statusFilter === status
                    ? 'bg-indigo-600 text-white font-bold'
                    : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {status}
              </button>
            ))}
          </div>
        </div>

        <span className="text-slate-500 font-mono text-[11px]">
          Showing {filteredInvoices.length} invoices
        </span>
      </div>

      {/* Invoices Table */}
      <div className="bg-slate-900 border border-slate-800 overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-slate-950 border-b border-slate-800 text-slate-400 font-mono text-[11px]">
              <th className="p-3.5">INVOICE #</th>
              <th className="p-3.5">CLIENT / COMPANY</th>
              <th className="p-3.5">PROJECT</th>
              <th className="p-3.5">ISSUE DATE</th>
              <th className="p-3.5">DUE DATE</th>
              <th className="p-3.5">STATUS</th>
              <th className="p-3.5 text-right">TOTAL DUE</th>
              <th className="p-3.5 text-right">ACTIONS</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-slate-200">
            {filteredInvoices.map((inv) => {
              const client = clients.find(c => c.id === inv.clientId);
              const project = projects.find(p => p.id === inv.projectId);

              return (
                <tr key={inv.id} className="hover:bg-slate-850/50 transition-colors">
                  <td className="p-3.5 font-mono font-bold text-slate-100">
                    #{inv.invoiceNumber}
                  </td>
                  <td className="p-3.5">
                    <div className="font-semibold text-slate-100">{client?.company || client?.name}</div>
                    <div className="text-[11px] text-slate-500 font-mono">{client?.email}</div>
                  </td>
                  <td className="p-3.5 font-mono text-slate-400">
                    {project ? `${project.code}` : 'General / Retainer'}
                  </td>
                  <td className="p-3.5 font-mono text-slate-400">{inv.issueDate}</td>
                  <td className="p-3.5 font-mono text-slate-300">{inv.dueDate}</td>
                  <td className="p-3.5">
                    <span className={`px-2 py-0.5 border text-[10px] uppercase font-mono font-bold ${statusColors[inv.status]}`}>
                      {inv.status}
                    </span>
                  </td>
                  <td className="p-3.5 text-right font-mono font-bold text-slate-100 text-sm">
                    {formatCurrency(inv.total, true)}
                  </td>
                  <td className="p-3.5 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      {/* Branded PDF Download */}
                      <button
                        onClick={() => generateInvoicePdf(inv, client || clients[0], project)}
                        className="px-2.5 py-1 bg-indigo-950/80 hover:bg-indigo-900 text-indigo-300 border border-indigo-700/60 text-xs font-semibold flex items-center gap-1 transition-colors"
                        title="Download official PDF invoice with company branding"
                      >
                        <Download className="w-3 h-3 text-indigo-400" />
                        <span>PDF</span>
                      </button>

                      {/* Status toggle for Admin / PM */}
                      {currentUser.permissions.canCreateInvoices && inv.status !== 'paid' && (
                        <button
                          onClick={() => updateInvoice(inv.id, { status: 'paid', paidAt: new Date().toISOString() })}
                          className="px-2 py-1 bg-emerald-950/60 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 text-xs font-medium transition-colors"
                          title="Mark invoice as paid"
                        >
                          Mark Paid
                        </button>
                      )}

                      {currentUser.permissions.canCreateInvoices && inv.status === 'draft' && (
                        <button
                          onClick={() => updateInvoice(inv.id, { status: 'sent' })}
                          className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors"
                          title="Mark as sent to client"
                        >
                          Send
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* New Invoice Creator Modal */}
      {isNewInvoiceOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-3xl shadow-2xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <Receipt className="w-4 h-4 text-indigo-400" />
                <span>Create & Configure Automated Invoice</span>
              </h2>
              <button onClick={() => setIsNewInvoiceOpen(false)} className="text-slate-400 hover:text-slate-200">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateInvoice} className="space-y-4 text-xs">
              {/* Client & Project Selectors */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Invoice Number</label>
                  <input
                    type="text"
                    value={invoiceNumber}
                    onChange={(e) => setInvoiceNumber(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Client *</label>
                  <select
                    value={selectedClientId}
                    onChange={(e) => setSelectedClientId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200"
                  >
                    {clients.map(c => (
                      <option key={c.id} value={c.id}>{c.company || c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Project Reference</label>
                  <select
                    value={selectedProjectId}
                    onChange={(e) => {
                      setSelectedProjectId(e.target.value);
                      if (e.target.value) autoPopulateFromProject(e.target.value);
                    }}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200"
                  >
                    <option value="">None / General Retainer</option>
                    {projects.map(p => (
                      <option key={p.id} value={p.id}>{p.code} - {p.title}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Dates & Terms */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Issue Date</label>
                  <input
                    type="date"
                    value={issueDate}
                    onChange={(e) => setIssueDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Due Date</label>
                  <input
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Payment Terms</label>
                  <input
                    type="text"
                    value={paymentTerms}
                    onChange={(e) => setPaymentTerms(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Tax Rate (%)</label>
                  <input
                    type="number"
                    value={taxRate}
                    onChange={(e) => setTaxRate(Number(e.target.value))}
                    step="0.01"
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200 font-mono"
                  />
                </div>
              </div>

              {/* Line Items Builder */}
              <div className="space-y-2 pt-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                    Invoice Line Items ({lineItems.length})
                  </span>
                  <div className="flex items-center gap-2">
                    {selectedProjectId && (
                      <button
                        type="button"
                        onClick={() => autoPopulateFromProject(selectedProjectId)}
                        className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
                      >
                        <Sparkles className="w-3 h-3" />
                        <span>Pull Project Hours & Expenses</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={addLineItem}
                      className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1"
                    >
                      <Plus className="w-3 h-3" />
                      <span>Add Item</span>
                    </button>
                  </div>
                </div>

                <div className="space-y-2">
                  {lineItems.map((item, idx) => (
                    <div key={item.id} className="p-3 bg-slate-950 border border-slate-800 grid grid-cols-12 gap-2 items-center">
                      <div className="col-span-5">
                        <input
                          type="text"
                          value={item.description}
                          onChange={(e) => updateLineItem(item.id, { description: e.target.value })}
                          placeholder="Item description..."
                          className="w-full bg-slate-900 border border-slate-700 px-2 py-1 text-slate-200 text-xs"
                        />
                      </div>
                      <div className="col-span-2">
                        <select
                          value={item.type}
                          onChange={(e) => updateLineItem(item.id, { type: e.target.value as any })}
                          className="w-full bg-slate-900 border border-slate-700 px-2 py-1 text-slate-200 text-xs"
                        >
                          <option value="hours">Hours</option>
                          <option value="fixed_milestone">Milestone</option>
                          <option value="expense">Expense</option>
                          <option value="retainer">Retainer</option>
                        </select>
                      </div>
                      <div className="col-span-2">
                        <input
                          type="number"
                          value={item.quantity}
                          onChange={(e) => updateLineItem(item.id, { quantity: Number(e.target.value) })}
                          min={1}
                          placeholder="Qty"
                          className="w-full bg-slate-900 border border-slate-700 px-2 py-1 text-slate-200 text-xs font-mono"
                        />
                      </div>
                      <div className="col-span-2">
                        <input
                          type="number"
                          value={item.unitPrice}
                          onChange={(e) => updateLineItem(item.id, { unitPrice: Number(e.target.value) })}
                          placeholder="Rate"
                          className="w-full bg-slate-900 border border-slate-700 px-2 py-1 text-slate-200 text-xs font-mono"
                        />
                      </div>
                      <div className="col-span-1 text-right">
                        <button
                          type="button"
                          onClick={() => removeLineItem(item.id)}
                          className="text-slate-500 hover:text-rose-400 p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Remittance & Bank Notes */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Notes / Instructions</label>
                  <textarea
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    rows={2}
                    className="w-full bg-slate-950 border border-slate-700 p-2 text-slate-200"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Bank Remittance / Wire Info</label>
                  <textarea
                    value={bankDetails}
                    onChange={(e) => setBankDetails(e.target.value)}
                    rows={2}
                    className="w-full bg-slate-950 border border-slate-700 p-2 text-slate-200 font-mono text-[11px]"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsNewInvoiceOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold transition-colors shadow-sm"
                >
                  Generate Invoice
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
