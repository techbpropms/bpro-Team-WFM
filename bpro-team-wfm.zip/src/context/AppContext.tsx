import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { User } from 'firebase/auth';
import { 
  Client, 
  Project, 
  Task, 
  TaskStatus, 
  Invoice, 
  Expense, 
  TeamMember, 
  MeetingSchedule, 
  SlackWebhookConfig, 
  SystemNotification, 
  AuditLogEntry, 
  UserRole,
  OrgSettings,
  StickyNote,
  GamificationProfile,
  UploadedDocument,
  NotificationCategory,
  NotificationUrgency
} from '../types';
import { storageService } from '../services/storage';
import { sendSlackNotification } from '../services/slackIntegration';
import { initAuth, googleSignIn, logout as firebaseLogout } from '../services/firebaseAuth';
import { testFirestoreConnection, firestoreService } from '../services/firebase';
import { triggerConfetti } from '../utils/confetti';
import { soundManager } from '../utils/sound';

interface AppContextType {
  // Auth & Roles
  currentUser: TeamMember;
  allTeamMembers: TeamMember[];
  switchUser: (userId: string) => void;
  googleUser: User | null;
  googleToken: string | null;
  signInWithGoogle: () => Promise<void>;
  signOutGoogle: () => Promise<void>;
  isOffline: boolean;
  isFirestoreConnected: boolean;
  syncWithFirestore: () => Promise<void>;
  
  // Navigation
  activeTab: string;
  setActiveTab: (tab: string) => void;

  // Data & Mutators
  clients: Client[];
  addClient: (client: Omit<Client, 'id' | 'createdAt'>) => void;
  updateClient: (id: string, updates: Partial<Client>) => void;
  deleteClient: (id: string) => void;

  projects: Project[];
  addProject: (project: Omit<Project, 'id' | 'totalLoggedHours'>) => void;
  updateProject: (id: string, updates: Partial<Project>) => void;
  deleteProject: (id: string) => void;

  tasks: Task[];
  addTask: (task: Omit<Task, 'id' | 'createdAt' | 'updatedAt' | 'amendments'>) => void;
  updateTask: (id: string, updates: Partial<Task>) => void;
  updateTaskStatus: (id: string, status: TaskStatus) => void;
  pushTaskDeadline: (taskId: string, newDate: string, reason: string) => void;
  deleteTask: (id: string) => void;

  invoices: Invoice[];
  createInvoice: (inv: Omit<Invoice, 'id' | 'createdAt'>) => void;
  updateInvoice: (id: string, updates: Partial<Invoice>) => void;
  deleteInvoice: (id: string) => void;

  expenses: Expense[];
  submitExpense: (exp: Omit<Expense, 'id' | 'createdAt' | 'status'>) => void;
  approveExpense: (id: string) => void;
  rejectExpense: (id: string, reason: string) => void;

  meetings: MeetingSchedule[];
  scheduleMeeting: (meeting: Omit<MeetingSchedule, 'id' | 'createdAt'>) => void;

  slackConfig: SlackWebhookConfig;
  updateSlackConfig: (cfg: SlackWebhookConfig) => void;

  notifications: SystemNotification[];
  markNotificationRead: (id: string) => void;
  clearAllNotifications: () => void;

  auditLogs: AuditLogEntry[];
  logAudit: (
    action: string, 
    entityType: AuditLogEntry['entityType'], 
    entityId: string, 
    details: string,
    severity?: 'info' | 'warning' | 'critical' | 'security',
    metadata?: Record<string, any>
  ) => void;
  clearAuditLogs: () => void;
  inviteTeamMember: (member: Omit<TeamMember, 'id' | 'joinedDate'>) => void;
  updateTeamMember: (id: string, updates: Partial<TeamMember>) => void;
  updateMemberProfile: (id: string, updates: Partial<TeamMember>) => void;

  // Settings & Currency
  orgSettings: OrgSettings;
  updateOrgSettings: (settings: Partial<OrgSettings>) => void;
  formatCurrency: (amount: number, showDecimals?: boolean) => string;
  isSuperAdmin: boolean;

  // Sticky Notes & Scratchpad
  stickyNotes: StickyNote[];
  addStickyNote: (note: Omit<StickyNote, 'id' | 'createdAt' | 'updatedAt' | 'authorId' | 'authorName'>) => void;
  updateStickyNote: (id: string, updates: Partial<StickyNote>) => void;
  deleteStickyNote: (id: string) => void;
  toggleStickyChecklistItem: (noteId: string, itemId: string) => void;

  // Gamification & Recognition
  gamificationProfiles: GamificationProfile[];
  awardKudos: (toUserId: string, reason: string, stars: number) => void;
  addXp: (userId: string, xp: number, reason?: string) => void;
  triggerCelebration: () => void;

  // Uploaded Documents & Ingestion
  documents: UploadedDocument[];
  addDocument: (doc: Omit<UploadedDocument, 'id' | 'uploadedAt' | 'uploadedBy' | 'uploadedByName'>) => void;
  deleteDocument: (id: string) => void;

  // Floating Tools & Drawers
  isStickyDrawerOpen: boolean;
  setIsStickyDrawerOpen: (open: boolean) => void;
  isUploadModalOpen: boolean;
  setIsUploadModalOpen: (open: boolean) => void;
  isNotificationCenterOpen: boolean;
  setIsNotificationCenterOpen: (open: boolean) => void;

  // Search & Filter
  searchQuery: string;
  setSearchQuery: (q: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isOffline, setIsOffline] = useState<boolean>(!navigator.onLine);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Firebase Google Auth State
  const [googleUser, setGoogleUser] = useState<User | null>(null);
  const [googleToken, setGoogleToken] = useState<string | null>(null);

  // Core Data
  const [team, setTeam] = useState<TeamMember[]>(() => storageService.getTeam());
  const [currentUserId, setCurrentUserId] = useState<string>(() => storageService.getCurrentUserId());
  const [clients, setClients] = useState<Client[]>(() => storageService.getClients());
  const [projects, setProjects] = useState<Project[]>(() => storageService.getProjects());
  const [tasks, setTasks] = useState<Task[]>(() => storageService.getTasks());
  const [invoices, setInvoices] = useState<Invoice[]>(() => storageService.getInvoices());
  const [expenses, setExpenses] = useState<Expense[]>(() => storageService.getExpenses());
  const [meetings, setMeetings] = useState<MeetingSchedule[]>(() => storageService.getMeetings());
  const [slackConfig, setSlackConfig] = useState<SlackWebhookConfig>(() => storageService.getSlackConfig());
  const [notifications, setNotifications] = useState<SystemNotification[]>(() => storageService.getNotifications());
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(() => storageService.getAuditLogs());
  const [orgSettings, setOrgSettings] = useState<OrgSettings>(() => storageService.getOrgSettings());
  const [stickyNotes, setStickyNotes] = useState<StickyNote[]>(() => storageService.getStickyNotes());
  const [gamificationProfiles, setGamificationProfiles] = useState<GamificationProfile[]>(() => storageService.getGamification());
  const [documents, setDocuments] = useState<UploadedDocument[]>(() => storageService.getDocuments());
  const [isStickyDrawerOpen, setIsStickyDrawerOpen] = useState(false);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [isNotificationCenterOpen, setIsNotificationCenterOpen] = useState(false);
  const [isFirestoreConnected, setIsFirestoreConnected] = useState<boolean>(true);

  // Current active user
  const currentUser = team.find(m => m.id === currentUserId) || team[0];
  const isSuperAdmin = currentUser.role === 'super_admin' || ['drbabukollam@gmail.com', 'drbabukoillam@gmail.com', 'tech@bropms.com'].includes(currentUser.email.toLowerCase());

  const formatCurrency = (amount: number, showDecimals: boolean = false): string => {
    if (amount === undefined || amount === null || isNaN(amount)) return '₹0';
    if (showDecimals) {
      return '₹' + Number(amount).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }
    return '₹' + Math.round(amount).toLocaleString('en-IN');
  };

  // Online / Offline Listeners & Firebase Initializers
  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Verify Firestore connection per Firebase skill guidelines
    testFirestoreConnection().then(ok => {
      setIsFirestoreConnected(ok);
    });

    // Real-time Firestore onSnapshot listeners for tasks, invoices & notifications
    let unsubTasks: (() => void) | undefined;
    let unsubInvoices: (() => void) | undefined;
    let unsubNotifs: (() => void) | undefined;

    try {
      unsubTasks = firestoreService.subscribeToCollection<Task>('tasks', (remoteTasks) => {
        if (remoteTasks && remoteTasks.length > 0) {
          setTasks(remoteTasks);
          storageService.saveTasks(remoteTasks);
        }
      });
    } catch (e) {
      console.warn('[Firebase Realtime] Tasks subscription notice:', e);
    }

    try {
      unsubInvoices = firestoreService.subscribeToCollection<Invoice>('invoices', (remoteInvoices) => {
        if (remoteInvoices && remoteInvoices.length > 0) {
          setInvoices(remoteInvoices);
          storageService.saveInvoices(remoteInvoices);
        }
      });
    } catch (e) {
      console.warn('[Firebase Realtime] Invoices subscription notice:', e);
    }

    try {
      unsubNotifs = firestoreService.subscribeToNotifications((remoteNotifs) => {
        if (remoteNotifs && remoteNotifs.length > 0) {
          setNotifications(prev => {
            const idMap = new Map<string, SystemNotification>();
            prev.forEach(p => idMap.set(p.id, p));
            remoteNotifs.forEach((r: any) => idMap.set(r.id, r));
            const merged = Array.from(idMap.values()).sort(
              (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
            );
            storageService.saveNotifications(merged);
            return merged;
          });
        }
      });
    } catch (e) {
      console.warn('[Firebase Realtime] Notifications subscription notice:', e);
    }

    // Init Firebase Auth Listener
    const unsubscribe = initAuth(
      (user, token) => {
        setGoogleUser(user);
        setGoogleToken(token);
      },
      () => {
        setGoogleUser(null);
        setGoogleToken(null);
      }
    );

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      if (unsubTasks) unsubTasks();
      if (unsubInvoices) unsubInvoices();
      if (unsubNotifs) unsubNotifs();
      unsubscribe();
    };
  }, []);

  const switchUser = useCallback((userId: string) => {
    setCurrentUserId(userId);
    storageService.saveCurrentUserId(userId);
  }, []);

  const syncWithFirestore = useCallback(async () => {
    try {
      await firestoreService.saveCollection('clients', clients);
      await firestoreService.saveCollection('projects', projects);
      await firestoreService.saveCollection('tasks', tasks);
      await firestoreService.saveCollection('invoices', invoices);
      await firestoreService.saveCollection('expenses', expenses);
      await firestoreService.saveCollection('stickyNotes', stickyNotes);
      addNotification('Firestore Synchronized', 'All records persisted to Firebase Firestore Cloud database', 'success');
      triggerConfetti();
    } catch (err: any) {
      console.error('[Firebase] sync failed:', err);
    }
  }, [clients, projects, tasks, invoices, expenses, stickyNotes]);

  const signInWithGoogle = useCallback(async () => {
    try {
      const res = await googleSignIn();
      if (res) {
        setGoogleUser(res.user);
        setGoogleToken(res.accessToken);
        addNotification('Google Calendar Connected', `Signed in as ${res.user.email} with calendar access`, 'success');
      }
    } catch (err: any) {
      console.error('Google Sign In failed:', err);
    }
  }, []);

  const signOutGoogle = useCallback(async () => {
    await firebaseLogout();
    setGoogleUser(null);
    setGoogleToken(null);
  }, []);

  const addNotification = (
    title: string, 
    message: string, 
    type: 'info' | 'warning' | 'success' | 'alert' = 'info', 
    linkAction?: string,
    category?: NotificationCategory,
    urgency?: NotificationUrgency,
    entityId?: string,
    meta?: any
  ) => {
    const newNotif: SystemNotification = {
      id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      title,
      message,
      type,
      category: category || (linkAction === 'tasks' ? 'task' : linkAction === 'invoices' ? 'invoice' : 'system'),
      urgency: urgency || (type === 'alert' ? 'critical' : type === 'warning' ? 'high' : 'normal'),
      entityId,
      meta,
      timestamp: new Date().toISOString(),
      isRead: false,
      linkAction,
      source: 'firebase',
    };
    setNotifications(prev => {
      const updated = [newNotif, ...prev.slice(0, 49)];
      storageService.saveNotifications(updated);
      return updated;
    });

    // Broadcast to Firestore real-time collection
    firestoreService.pushNotification(newNotif).catch(() => {});

    // Sound chime trigger
    soundManager.playChime(category === 'deadline' ? 'deadline' : category === 'invoice' ? 'invoice' : category === 'task' ? 'task' : 'default');
  };

  const logAudit = (
    action: string, 
    entityType: AuditLogEntry['entityType'], 
    entityId: string, 
    details: string,
    severity: 'info' | 'warning' | 'critical' | 'security' = 'info',
    metadata?: Record<string, any>
  ) => {
    // Generate pseudo-SHA256 hex checksum
    const rawString = `${currentUser.id}:${action}:${entityId}:${Date.now()}`;
    let hashNum = 0;
    for (let i = 0; i < rawString.length; i++) {
      hashNum = ((hashNum << 5) - hashNum) + rawString.charCodeAt(i);
      hashNum |= 0;
    }
    const hash = `SHA256-${Math.abs(hashNum).toString(16).padStart(8, '0')}${Date.now().toString(16)}`;

    const newEntry: AuditLogEntry = {
      id: `audit_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      actorId: currentUser.id,
      actorName: currentUser.name,
      action,
      entityType,
      entityId,
      details,
      timestamp: new Date().toISOString(),
      severity,
      ipAddress: '10.240.14.82 (Corporate VPN / MFA Secured)',
      hash,
      metadata,
    };
    setAuditLogs(prev => {
      const updated = [newEntry, ...prev.slice(0, 199)];
      storageService.saveAuditLogs(updated);
      return updated;
    });
  };

  const clearAuditLogs = () => {
    setAuditLogs([]);
    storageService.saveAuditLogs([]);
  };

  // CLIENTS
  const addClient = (c: Omit<Client, 'id' | 'createdAt'>) => {
    const newClient: Client = {
      ...c,
      id: `client_${Date.now()}`,
      createdAt: new Date().toISOString().substring(0, 10),
    };
    const updated = [newClient, ...clients];
    setClients(updated);
    storageService.saveClients(updated);
    logAudit('CREATE_CLIENT', 'client', newClient.id, `Created client ${newClient.name} (${newClient.company})`);
  };

  const updateClient = (id: string, updates: Partial<Client>) => {
    const updated = clients.map(c => c.id === id ? { ...c, ...updates } : c);
    setClients(updated);
    storageService.saveClients(updated);
    logAudit('UPDATE_CLIENT', 'client', id, `Updated client details`);
  };

  const deleteClient = (id: string) => {
    const updated = clients.filter(c => c.id !== id);
    setClients(updated);
    storageService.saveClients(updated);
    logAudit('DELETE_CLIENT', 'client', id, `Deleted client record`);
  };

  // PROJECTS
  const addProject = (p: Omit<Project, 'id' | 'totalLoggedHours'>) => {
    const newProject: Project = {
      ...p,
      id: `proj_${Date.now()}`,
      totalLoggedHours: 0,
    };
    const updated = [newProject, ...projects];
    setProjects(updated);
    storageService.saveProjects(updated);
    logAudit('CREATE_PROJECT', 'project', newProject.id, `Created project ${newProject.title} [${newProject.code}]`);
  };

  const updateProject = (id: string, updates: Partial<Project>) => {
    const updated = projects.map(p => p.id === id ? { ...p, ...updates } : p);
    setProjects(updated);
    storageService.saveProjects(updated);
    logAudit('UPDATE_PROJECT', 'project', id, `Updated project status/details`);
  };

  const deleteProject = (id: string) => {
    const updated = projects.filter(p => p.id !== id);
    setProjects(updated);
    storageService.saveProjects(updated);
    logAudit('DELETE_PROJECT', 'project', id, `Deleted project record`);
  };

  // TASKS
  const addTask = (t: Omit<Task, 'id' | 'createdAt' | 'updatedAt' | 'amendments'>) => {
    const newTask: Task = {
      ...t,
      id: `task_${Date.now()}`,
      amendments: [],
      createdAt: new Date().toISOString().substring(0, 10),
      updatedAt: new Date().toISOString().substring(0, 10),
    };
    const updated = [newTask, ...tasks];
    setTasks(updated);
    storageService.saveTasks(updated);
    logAudit('CREATE_TASK', 'task', newTask.id, `Created task: ${newTask.title}`);
    addNotification(
      'New Sprint Task Created', 
      `Task "${newTask.title}" added (${newTask.priority.toUpperCase()}) - Target: ${newTask.dueDate}`, 
      newTask.priority === 'urgent' ? 'alert' : 'info', 
      'tasks',
      'task',
      newTask.priority === 'urgent' ? 'critical' : 'high',
      newTask.id,
      { taskTitle: newTask.title, dueDate: newTask.dueDate }
    );
  };

  const updateTask = (id: string, updates: Partial<Task>) => {
    const updated = tasks.map(t => t.id === id ? { ...t, ...updates, updatedAt: new Date().toISOString().substring(0, 10) } : t);
    setTasks(updated);
    storageService.saveTasks(updated);
  };

  const updateTaskStatus = (id: string, status: TaskStatus) => {
    const task = tasks.find(t => t.id === id);
    if (!task) return;

    const isCompleted = status === 'completed';
    const updated = tasks.map(t => {
      if (t.id === id) {
        return {
          ...t,
          status,
          completedAt: isCompleted ? new Date().toISOString() : undefined,
          updatedAt: new Date().toISOString().substring(0, 10),
        };
      }
      return t;
    });

    setTasks(updated);
    storageService.saveTasks(updated);
    logAudit('UPDATE_TASK_STATUS', 'task', id, `Changed status of "${task.title}" to ${status.toUpperCase()}`);

    if (isCompleted) {
      triggerConfetti(0.5, 0.4);
      addXp(task.assignedToId || currentUser.id, 50, `Completed task: ${task.title}`);
      addNotification('Milestone Achieved!', `Task "${task.title}" fulfilled (+50 XP)`, 'success', 'tasks', 'task', 'normal', id);
    }

    if (isCompleted && slackConfig.isEnabled && slackConfig.notifyOnTaskComplete) {
      sendSlackNotification(slackConfig, {
        title: `Task Completed: ${task.title}`,
        text: `Completed by ${currentUser.name}. Logged hours: ${task.actualHours}/${task.estimatedHours}h`,
        color: '#10b981',
      });
    }
  };

  // Push task deadline to next day with mandatory reason
  const pushTaskDeadline = (taskId: string, newDate: string, reason: string) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;

    const prevDate = task.dueDate;
    const prevTime = new Date(prevDate).getTime();
    const newTime = new Date(newDate).getTime();
    const diffDays = Math.max(1, Math.round((newTime - prevTime) / (1000 * 60 * 60 * 24)));

    const amendment = {
      id: `amend_${Date.now()}`,
      taskId,
      previousDeadline: prevDate,
      newDeadline: newDate,
      reason,
      amendedBy: currentUser.id,
      amendedByName: currentUser.name,
      timestamp: new Date().toISOString(),
      pushedDays: diffDays,
    };

    const updated = tasks.map(t => {
      if (t.id === taskId) {
        return {
          ...t,
          dueDate: newDate,
          amendments: [amendment, ...t.amendments],
          updatedAt: new Date().toISOString().substring(0, 10),
        };
      }
      return t;
    });

    setTasks(updated);
    storageService.saveTasks(updated);

    const logMsg = `Pushed deadline from ${prevDate} to ${newDate} (+${diffDays}d). Reason: ${reason}`;
    logAudit('AMEND_DEADLINE', 'task', taskId, logMsg);
    addNotification(
      'Deadline Postponed with Reason', 
      `Task "${task.title}" postponed to ${newDate}: ${reason}`, 
      'warning', 
      'tasks',
      'deadline',
      'high',
      taskId,
      { taskTitle: task.title, dueDate: newDate }
    );

    if (slackConfig.isEnabled && slackConfig.notifyOnDeadlinePush) {
      sendSlackNotification(slackConfig, {
        title: `Deadline Pushed: ${task.title}`,
        text: `New Target: ${newDate} (was ${prevDate})\nReason: ${reason}\nAmended by: ${currentUser.name}`,
        color: '#f59e0b',
        fields: [
          { title: 'Reason', value: reason, short: false },
          { title: 'Amended By', value: currentUser.name, short: true },
          { title: 'New Due Date', value: newDate, short: true },
        ],
      });
    }
  };

  const deleteTask = (id: string) => {
    const updated = tasks.filter(t => t.id !== id);
    setTasks(updated);
    storageService.saveTasks(updated);
    logAudit('DELETE_TASK', 'task', id, `Deleted task record`);
  };

  // INVOICES
  const createInvoice = (inv: Omit<Invoice, 'id' | 'createdAt'>) => {
    const newInvoice: Invoice = {
      ...inv,
      id: `inv_${Date.now()}`,
      createdAt: new Date().toISOString().substring(0, 10),
    };
    const updated = [newInvoice, ...invoices];
    setInvoices(updated);
    storageService.saveInvoices(updated);
    logAudit('CREATE_INVOICE', 'invoice', newInvoice.id, `Created invoice #${newInvoice.invoiceNumber} for ₹${Math.round(newInvoice.total).toLocaleString('en-IN')}`);
    addNotification(
      'Invoice Generated', 
      `Invoice #${newInvoice.invoiceNumber} prepared for ₹${Math.round(newInvoice.total).toLocaleString('en-IN')} ${newInvoice.currency}`, 
      'info', 
      'invoices',
      'invoice',
      'medium',
      newInvoice.id,
      { invoiceNumber: newInvoice.invoiceNumber, amount: newInvoice.total, dueDate: newInvoice.dueDate }
    );

    if (slackConfig.isEnabled && slackConfig.notifyOnInvoiceCreated) {
      sendSlackNotification(slackConfig, {
        title: `Invoice Generated #${newInvoice.invoiceNumber}`,
        text: `Total: ${newInvoice.currency} ₹${Math.round(newInvoice.total).toLocaleString('en-IN')} | Due: ${newInvoice.dueDate}`,
        color: '#6366f1',
      });
    }
  };

  const updateInvoice = (id: string, updates: Partial<Invoice>) => {
    const target = invoices.find(i => i.id === id);
    const updated = invoices.map(i => i.id === id ? { ...i, ...updates } : i);
    setInvoices(updated);
    storageService.saveInvoices(updated);
    logAudit('UPDATE_INVOICE', 'invoice', id, `Updated invoice record #${target?.invoiceNumber || id}`);

    if (updates.status === 'paid') {
      triggerConfetti(0.5, 0.35);
      addXp(currentUser.id, 150, `Settled invoice #${target?.invoiceNumber}`);
      addNotification(
        'Payment Settled & Realized!', 
        `Invoice #${target?.invoiceNumber || ''} marked paid (+150 XP)`, 
        'success', 
        'invoices',
        'invoice',
        'normal',
        id,
        { invoiceNumber: target?.invoiceNumber, amount: target?.total }
      );
    }
  };

  const deleteInvoice = (id: string) => {
    const updated = invoices.filter(i => i.id !== id);
    setInvoices(updated);
    storageService.saveInvoices(updated);
    logAudit('DELETE_INVOICE', 'invoice', id, `Deleted invoice record`);
  };

  // EXPENSES
  const submitExpense = (exp: Omit<Expense, 'id' | 'createdAt' | 'status'>) => {
    const newExpense: Expense = {
      ...exp,
      id: `exp_${Date.now()}`,
      status: 'pending',
      createdAt: new Date().toISOString().substring(0, 10),
    };
    const updated = [newExpense, ...expenses];
    setExpenses(updated);
    storageService.saveExpenses(updated);
    logAudit('SUBMIT_EXPENSE', 'expense', newExpense.id, `Submitted ${newExpense.category} expense: ₹${newExpense.amount.toLocaleString('en-IN')}`);
    addNotification('Expense Submitted', `${newExpense.submittedByName} submitted ₹${newExpense.amount.toLocaleString('en-IN')} for approval`, 'info', 'expenses');

    if (slackConfig.isEnabled && slackConfig.notifyOnExpenseSubmitted) {
      sendSlackNotification(slackConfig, {
        title: `Expense Submitted for Review: ₹${newExpense.amount.toLocaleString('en-IN')}`,
        text: `Category: ${newExpense.category} | Submitter: ${newExpense.submittedByName}`,
        color: '#f59e0b',
      });
    }
  };

  const approveExpense = (id: string) => {
    const exp = expenses.find(e => e.id === id);
    if (!exp) return;

    const updated = expenses.map(e => e.id === id ? {
      ...e,
      status: 'approved' as const,
      approvedById: currentUser.id,
      approvalDate: new Date().toISOString().substring(0, 10),
    } : e);

    setExpenses(updated);
    storageService.saveExpenses(updated);
    logAudit('APPROVE_EXPENSE', 'expense', id, `Approved expense of $${exp.amount.toFixed(2)}`);
    addNotification('Expense Approved', `Expense #${id.substring(4)} ($${exp.amount.toFixed(2)}) approved by ${currentUser.name}`, 'success', 'expenses');
  };

  const rejectExpense = (id: string, reason: string) => {
    const exp = expenses.find(e => e.id === id);
    if (!exp) return;

    const updated = expenses.map(e => e.id === id ? {
      ...e,
      status: 'rejected' as const,
      rejectionReason: reason,
    } : e);

    setExpenses(updated);
    storageService.saveExpenses(updated);
    logAudit('REJECT_EXPENSE', 'expense', id, `Rejected expense: ${reason}`);
    addNotification('Expense Rejected', `Expense of $${exp.amount.toFixed(2)} rejected: ${reason}`, 'alert', 'expenses');
  };

  // MEETINGS & CALENDAR
  const scheduleMeeting = (meeting: Omit<MeetingSchedule, 'id' | 'createdAt'>) => {
    const newMeet: MeetingSchedule = {
      ...meeting,
      id: `meet_${Date.now()}`,
      createdAt: new Date().toISOString().substring(0, 10),
    };
    const updated = [newMeet, ...meetings];
    setMeetings(updated);
    storageService.saveMeetings(updated);
    logAudit('SCHEDULE_MEETING', 'integration', newMeet.id, `Scheduled Google Meet & Calendar session: ${newMeet.title}`);
    addNotification('Meeting Scheduled', `Scheduled "${newMeet.title}" with Google Meet link`, 'success', 'calendar');
  };

  // SLACK
  const updateSlackConfig = (cfg: SlackWebhookConfig) => {
    setSlackConfig(cfg);
    storageService.saveSlackConfig(cfg);
    logAudit('UPDATE_SLACK', 'integration', 'slack', `Updated Slack webhook settings (${cfg.isEnabled ? 'Enabled' : 'Disabled'})`);
  };

  // TEAM & PERMISSIONS
  const inviteTeamMember = (member: Omit<TeamMember, 'id' | 'joinedDate'>) => {
    const newMember: TeamMember = {
      ...member,
      id: `user_${Date.now()}`,
      joinedDate: new Date().toISOString().substring(0, 10),
    };
    const updated = [...team, newMember];
    setTeam(updated);
    storageService.saveTeam(updated);
    logAudit('INVITE_MEMBER', 'client', newMember.id, `Invited ${newMember.name} as ${newMember.role} (${newMember.isExternal ? 'External Consultant' : 'Internal'})`);
    addNotification('Team Member Invited', `Invitation sent to ${newMember.email} with customized permissions`, 'info', 'team');
  };

  const updateTeamMember = (id: string, updates: Partial<TeamMember>) => {
    const updated = team.map(m => m.id === id ? { ...m, ...updates } : m);
    setTeam(updated);
    storageService.saveTeam(updated);
  };

  const updateMemberProfile = (id: string, updates: Partial<TeamMember>) => {
    const updated = team.map(m => m.id === id ? { ...m, ...updates } : m);
    setTeam(updated);
    storageService.saveTeam(updated);
    logAudit('UPDATE_PROFILE', 'team', id, `Updated profile and professional details for ${updates.name || 'member'}`, 'info');
    addNotification('Profile Saved', 'Personal & professional credentials updated', 'success', 'team');
  };

  const updateOrgSettings = (updates: Partial<OrgSettings>) => {
    const updated = { ...orgSettings, ...updates };
    setOrgSettings(updated);
    storageService.saveOrgSettings(updated);
    logAudit('UPDATE_SETTINGS', 'integration', 'org_settings', 'Super Admin modified enterprise organization settings', 'security');
    addNotification('Settings Saved', 'Super Admin enterprise configuration persisted', 'success', 'settings');
  };

  const markNotificationRead = (id: string) => {
    const updated = notifications.map(n => n.id === id ? { ...n, isRead: true } : n);
    setNotifications(updated);
    storageService.saveNotifications(updated);
  };

  const clearAllNotifications = () => {
    setNotifications([]);
    storageService.saveNotifications([]);
  };

  // STICKY NOTES
  const addStickyNote = (note: Omit<StickyNote, 'id' | 'createdAt' | 'updatedAt' | 'authorId' | 'authorName'>) => {
    const newNote: StickyNote = {
      ...note,
      id: `note_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorAvatar: currentUser.avatarUrl,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    const updated = [newNote, ...stickyNotes];
    setStickyNotes(updated);
    storageService.saveStickyNotes(updated);
    logAudit('CREATE_NOTE', 'team', newNote.id, `Created sticky note "${newNote.title}"`, 'info');
  };

  const updateStickyNote = (id: string, updates: Partial<StickyNote>) => {
    const updated = stickyNotes.map(n => n.id === id ? { ...n, ...updates, updatedAt: new Date().toISOString() } : n);
    setStickyNotes(updated);
    storageService.saveStickyNotes(updated);
  };

  const deleteStickyNote = (id: string) => {
    const updated = stickyNotes.filter(n => n.id !== id);
    setStickyNotes(updated);
    storageService.saveStickyNotes(updated);
  };

  const toggleStickyChecklistItem = (noteId: string, itemId: string) => {
    const updated = stickyNotes.map(n => {
      if (n.id === noteId) {
        const nextChecklist = n.checklist.map(item => item.id === itemId ? { ...item, completed: !item.completed } : item);
        return { ...n, checklist: nextChecklist, updatedAt: new Date().toISOString() };
      }
      return n;
    });
    setStickyNotes(updated);
    storageService.saveStickyNotes(updated);
  };

  // GAMIFICATION & RECOGNITION
  const addXp = (userId: string, xp: number, reason?: string) => {
    setGamificationProfiles(prev => {
      const existing = prev.find(p => p.userId === userId);
      let updated: GamificationProfile[];
      if (existing) {
        const nextXp = existing.currentXp + xp;
        const nextLevel = Math.floor(nextXp / 300) + 1;
        if (nextLevel > existing.level) {
          triggerConfetti(0.5, 0.3);
          addNotification('Level Up Unlocked!', `Promoted to Level ${nextLevel} in Bpro Performance!`, 'success');
        }
        updated = prev.map(p => p.userId === userId ? {
          ...p,
          currentXp: nextXp,
          level: Math.max(p.level, nextLevel),
        } : p);
      } else {
        updated = [
          ...prev,
          {
            userId,
            currentXp: xp,
            level: Math.floor(xp / 300) + 1,
            levelTitle: 'Contributor',
            streakDays: 1,
            achievements: [],
            kudosReceived: [],
          },
        ];
      }
      storageService.saveGamification(updated);
      return updated;
    });
  };

  const awardKudos = (toUserId: string, reason: string, stars: number) => {
    const toMember = team.find(m => m.id === toUserId);
    const newKudos = {
      id: `kudos_${Date.now()}`,
      fromId: currentUser.id,
      fromName: currentUser.name,
      toUserId,
      reason,
      stars,
      date: new Date().toISOString(),
    };

    setGamificationProfiles(prev => {
      const existing = prev.find(p => p.userId === toUserId);
      let updated: GamificationProfile[];
      if (existing) {
        const nextXp = existing.currentXp + stars * 50;
        const nextLevel = Math.floor(nextXp / 300) + 1;
        updated = prev.map(p => p.userId === toUserId ? {
          ...p,
          currentXp: nextXp,
          level: Math.max(p.level, nextLevel),
          kudosReceived: [newKudos, ...p.kudosReceived],
        } : p);
      } else {
        updated = [
          ...prev,
          {
            userId: toUserId,
            currentXp: stars * 50,
            level: 1,
            levelTitle: 'Contributor',
            streakDays: 1,
            achievements: [],
            kudosReceived: [newKudos],
          },
        ];
      }
      storageService.saveGamification(updated);
      return updated;
    });

    triggerConfetti(0.5, 0.35);
    logAudit('AWARD_KUDOS', 'team', toUserId, `Awarded ${stars} star Kudos to ${toMember?.name || 'Member'}: "${reason}"`, 'info');
    addNotification('Kudos Awarded!', `You recognized ${toMember?.name || 'Team Member'} with ${stars} stars (+${stars * 50} XP)`, 'success', 'team');
  };

  const triggerCelebration = () => {
    triggerConfetti(0.5, 0.35);
  };

  // UPLOADED DOCUMENTS & INGESTION
  const addDocument = (doc: Omit<UploadedDocument, 'id' | 'uploadedAt' | 'uploadedBy' | 'uploadedByName'>) => {
    const newDoc: UploadedDocument = {
      ...doc,
      id: `doc_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      uploadedBy: currentUser.id,
      uploadedByName: currentUser.name,
      uploadedAt: new Date().toISOString(),
    };
    const updated = [newDoc, ...documents];
    setDocuments(updated);
    storageService.saveDocuments(updated);
    logAudit('UPLOAD_FILE', 'integration', newDoc.id, `Uploaded ${newDoc.category} file: ${newDoc.name} (${Math.round(newDoc.size / 1024)} KB)`, 'info');
    addNotification('File Uploaded', `${newDoc.name} added to enterprise document vault`, 'success');
  };

  const deleteDocument = (id: string) => {
    const updated = documents.filter(d => d.id !== id);
    setDocuments(updated);
    storageService.saveDocuments(updated);
    logAudit('DELETE_FILE', 'integration', id, `Removed document from vault`, 'warning');
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        allTeamMembers: team,
        switchUser,
        googleUser,
        googleToken,
        signInWithGoogle,
        signOutGoogle,
        isOffline,
        activeTab,
        setActiveTab,
        clients,
        addClient,
        updateClient,
        deleteClient,
        projects,
        addProject,
        updateProject,
        deleteProject,
        tasks,
        addTask,
        updateTask,
        updateTaskStatus,
        pushTaskDeadline,
        deleteTask,
        invoices,
        createInvoice,
        updateInvoice,
        deleteInvoice,
        expenses,
        submitExpense,
        approveExpense,
        rejectExpense,
        meetings,
        scheduleMeeting,
        slackConfig,
        updateSlackConfig,
        notifications,
        markNotificationRead,
        clearAllNotifications,
        auditLogs,
        logAudit,
        clearAuditLogs,
        inviteTeamMember,
        updateTeamMember,
        updateMemberProfile,
        orgSettings,
        updateOrgSettings,
        formatCurrency,
        isSuperAdmin,
        stickyNotes,
        addStickyNote,
        updateStickyNote,
        deleteStickyNote,
        toggleStickyChecklistItem,
        gamificationProfiles,
        awardKudos,
        addXp,
        triggerCelebration,
        documents,
        addDocument,
        deleteDocument,
        isStickyDrawerOpen,
        setIsStickyDrawerOpen,
        isUploadModalOpen,
        setIsUploadModalOpen,
        isNotificationCenterOpen,
        setIsNotificationCenterOpen,
        isFirestoreConnected,
        syncWithFirestore,
        searchQuery,
        setSearchQuery,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
