import React, { useState } from 'react';
import { BarChart3, Clock, CheckCircle2, AlertTriangle, Layers, MousePointerClick } from 'lucide-react';
import { formatCompactCurrency } from './chartUtils';

export interface WeeklySummaryPoint {
  weekKey: string; // e.g. "2026-W41"
  weekLabel: string; // e.g. "W41"
  dateRange: string; // e.g. "Oct 05 - Oct 11"
  completedTasks: number;
  inProgressTasks: number;
  blockedTasks: number;
  amendedTasks: number;
  actualHours: number;
  estimatedHours: number;
  revenueBilled: number;
  taskIds: string[];
}

interface WeeklyVelocityBarChartProps {
  data: WeeklySummaryPoint[];
  formatCurrency: (amount: number) => string;
  onDrillDown: (point: WeeklySummaryPoint) => void;
  selectedWeekKey?: string | null;
}

export const WeeklyVelocityBarChart: React.FC<WeeklyVelocityBarChartProps> = ({
  data,
  formatCurrency,
  onDrillDown,
  selectedWeekKey,
}) => {
  const [viewMode, setViewMode] = useState<'tasks' | 'hours' | 'revenue'>('tasks');
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  if (!data || data.length === 0) {
    return (
      <div className="p-8 text-center bg-slate-900 border border-slate-800 text-slate-400 text-xs font-mono">
        No weekly sprint velocity data matching current filter scope.
      </div>
    );
  }

  const width = 840;
  const height = 300;
  const padding = { top: 25, right: 30, bottom: 45, left: 60 };
  const chartW = width - padding.left - padding.right;
  const chartH = height - padding.top - padding.bottom;

  // Maximum scale calculations based on viewMode
  let maxValue = 10;
  if (viewMode === 'tasks') {
    maxValue = Math.max(
      6,
      ...data.map(d => d.completedTasks + d.inProgressTasks + d.blockedTasks)
    ) * 1.25;
  } else if (viewMode === 'hours') {
    maxValue = Math.max(30, ...data.map(d => Math.max(d.actualHours, d.estimatedHours))) * 1.2;
  } else {
    maxValue = Math.max(100000, ...data.map(d => d.revenueBilled)) * 1.25;
  }

  const numBars = data.length;
  const slotWidth = chartW / numBars;
  const barWidth = Math.min(42, slotWidth * 0.58);

  const getY = (val: number): number => {
    const clamped = Math.max(0, val);
    return padding.top + chartH - (clamped / maxValue) * chartH;
  };

  const getH = (val: number): number => {
    return Math.max(0, (val / maxValue) * chartH);
  };

  const gridTicks = [0, 0.33, 0.66, 1];
  const activeHoverPoint = hoveredIndex !== null ? data[hoveredIndex] : null;

  return (
    <div className="bg-slate-900 border border-slate-800 p-5 space-y-4">
      {/* Header & Metric Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-1.5">
              <BarChart3 className="w-4 h-4 text-emerald-400" />
              <span>Weekly Velocity & Sprint Deliverables Breakdown</span>
            </h3>
            <span className="text-[10px] font-mono text-emerald-300 bg-emerald-950/70 border border-emerald-800/80 px-2 py-0.5">
              Cadence & Throughput
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Deliverables completed, in-flight workloads, engineering hours & weekly billings. Click any bar for drill-down.
          </p>
        </div>

        {/* View Mode Segmented Controls */}
        <div className="flex items-center border border-slate-800 bg-slate-950 p-0.5 text-xs font-mono">
          <button
            type="button"
            onClick={() => setViewMode('tasks')}
            className={`px-3 py-1 transition-colors ${
              viewMode === 'tasks' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Tasks Breakdown
          </button>
          <button
            type="button"
            onClick={() => setViewMode('hours')}
            className={`px-3 py-1 transition-colors ${
              viewMode === 'hours' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Logged Hours
          </button>
          <button
            type="button"
            onClick={() => setViewMode('revenue')}
            className={`px-3 py-1 transition-colors ${
              viewMode === 'revenue' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Weekly Invoiced
          </button>
        </div>
      </div>

      {/* SVG Bar Chart Canvas */}
      <div className="relative w-full overflow-hidden select-none">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto overflow-visible font-mono"
          preserveAspectRatio="xMidYMid meet"
        >
          {/* Horizontal Grid lines */}
          {gridTicks.map((tick, i) => {
            const yPos = padding.top + chartH * (1 - tick);
            const val = tick * maxValue;
            return (
              <g key={i}>
                <line
                  x1={padding.left}
                  y1={yPos}
                  x2={width - padding.right}
                  y2={yPos}
                  stroke="#1e293b"
                  strokeDasharray="4 4"
                  strokeWidth="1"
                />
                <text
                  x={padding.left - 8}
                  y={yPos + 3.5}
                  fill="#64748b"
                  fontSize="10"
                  textAnchor="end"
                >
                  {viewMode === 'revenue'
                    ? formatCompactCurrency(val)
                    : viewMode === 'hours'
                    ? `${Math.round(val)}h`
                    : Math.round(val)}
                </text>
              </g>
            );
          })}

          {/* Render Bars for each week */}
          {data.map((point, i) => {
            const slotCenterX = padding.left + i * slotWidth + slotWidth / 2;
            const barX = slotCenterX - barWidth / 2;
            const isHovered = hoveredIndex === i;
            const isSelected = selectedWeekKey === point.weekKey;

            return (
              <g
                key={point.weekKey}
                className="cursor-pointer transition-all duration-150"
                onClick={() => onDrillDown(point)}
                onMouseEnter={() => setHoveredIndex(i)}
                onMouseLeave={() => setHoveredIndex(null)}
              >
                {/* Invisible large click target */}
                <rect
                  x={padding.left + i * slotWidth}
                  y={padding.top}
                  width={slotWidth}
                  height={chartH + 35}
                  fill="transparent"
                />

                {/* Selected/Hovered Background Column */}
                {(isHovered || isSelected) && (
                  <rect
                    x={padding.left + i * slotWidth + 2}
                    y={padding.top}
                    width={slotWidth - 4}
                    height={chartH}
                    fill={isSelected ? '#6366f1' : '#334155'}
                    fillOpacity={isSelected ? 0.15 : 0.25}
                    stroke={isSelected ? '#6366f1' : 'none'}
                    strokeDasharray={isSelected ? '3 3' : 'none'}
                  />
                )}

                {/* MODE 1: STACKED TASKS (Completed on bottom, In Progress, Blocked on top) */}
                {viewMode === 'tasks' && (
                  <g>
                    {/* Completed Tasks (Emerald) */}
                    {point.completedTasks > 0 && (
                      <rect
                        x={barX}
                        y={getY(point.completedTasks)}
                        width={barWidth}
                        height={getH(point.completedTasks)}
                        fill="#10b981"
                        fillOpacity={isHovered ? 1 : 0.85}
                        rx="1"
                      />
                    )}

                    {/* In Progress Tasks (Indigo) */}
                    {point.inProgressTasks > 0 && (
                      <rect
                        x={barX}
                        y={getY(point.completedTasks + point.inProgressTasks)}
                        width={barWidth}
                        height={getH(point.inProgressTasks)}
                        fill="#6366f1"
                        fillOpacity={isHovered ? 1 : 0.85}
                        rx="1"
                      />
                    )}

                    {/* Blocked Tasks (Rose) */}
                    {point.blockedTasks > 0 && (
                      <rect
                        x={barX}
                        y={getY(point.completedTasks + point.inProgressTasks + point.blockedTasks)}
                        width={barWidth}
                        height={getH(point.blockedTasks)}
                        fill="#f43f5e"
                        fillOpacity={isHovered ? 1 : 0.85}
                        rx="1"
                      />
                    )}

                    {/* Count badge on top of bar */}
                    <text
                      x={slotCenterX}
                      y={getY(point.completedTasks + point.inProgressTasks + point.blockedTasks) - 5}
                      fill={isHovered ? '#ffffff' : '#94a3b8'}
                      fontSize="10"
                      fontWeight="bold"
                      textAnchor="middle"
                    >
                      {point.completedTasks + point.inProgressTasks + point.blockedTasks}
                    </text>
                  </g>
                )}

                {/* MODE 2: GROUPED HOURS (Actual vs Estimated) */}
                {viewMode === 'hours' && (
                  <g>
                    {/* Estimated Hours Bar (Subtle dark border/fill) */}
                    <rect
                      x={barX}
                      y={getY(point.estimatedHours)}
                      width={barWidth / 2 - 2}
                      height={getH(point.estimatedHours)}
                      fill="#475569"
                      fillOpacity={isHovered ? 0.9 : 0.6}
                      rx="1"
                    />
                    {/* Actual Hours Bar (Amber) */}
                    <rect
                      x={barX + barWidth / 2 + 1}
                      y={getY(point.actualHours)}
                      width={barWidth / 2 - 2}
                      height={getH(point.actualHours)}
                      fill="#f59e0b"
                      fillOpacity={isHovered ? 1 : 0.85}
                      rx="1"
                    />

                    <text
                      x={slotCenterX}
                      y={getY(Math.max(point.actualHours, point.estimatedHours)) - 5}
                      fill={isHovered ? '#fbbf24' : '#94a3b8'}
                      fontSize="10"
                      fontWeight="bold"
                      textAnchor="middle"
                    >
                      {point.actualHours}h
                    </text>
                  </g>
                )}

                {/* MODE 3: WEEKLY REVENUE BILLED */}
                {viewMode === 'revenue' && (
                  <g>
                    <rect
                      x={barX}
                      y={getY(point.revenueBilled)}
                      width={barWidth}
                      height={getH(point.revenueBilled)}
                      fill="#818cf8"
                      fillOpacity={isHovered ? 1 : 0.8}
                      rx="2"
                    />
                    <text
                      x={slotCenterX}
                      y={getY(point.revenueBilled) - 5}
                      fill={isHovered ? '#c7d2fe' : '#94a3b8'}
                      fontSize="9"
                      fontWeight="bold"
                      textAnchor="middle"
                    >
                      {point.revenueBilled > 0 ? formatCompactCurrency(point.revenueBilled) : '₹0'}
                    </text>
                  </g>
                )}

                {/* X-Axis Label */}
                <text
                  x={slotCenterX}
                  y={padding.top + chartH + 18}
                  fill={isSelected ? '#818cf8' : isHovered ? '#ffffff' : '#cbd5e1'}
                  fontSize={isSelected || isHovered ? '11' : '10'}
                  fontWeight={isSelected || isHovered ? 'bold' : 'normal'}
                  textAnchor="middle"
                >
                  {point.weekLabel}
                </text>
                <text
                  x={slotCenterX}
                  y={padding.top + chartH + 30}
                  fill="#64748b"
                  fontSize="8"
                  textAnchor="middle"
                >
                  {point.dateRange.split('-')[0].trim()}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Hover Tooltip */}
        {activeHoverPoint && hoveredIndex !== null && (
          <div
            className="absolute top-2 z-20 pointer-events-none bg-slate-950/95 border border-slate-700/80 shadow-2xl p-3 text-xs rounded-none backdrop-blur-md min-w-[220px]"
            style={{
              left: Math.min(
                Math.max(10, padding.left + hoveredIndex * slotWidth - 60),
                width - 240
              ),
            }}
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-1.5 mb-2">
              <div>
                <span className="font-bold text-slate-100">{activeHoverPoint.weekLabel}</span>
                <span className="text-[10px] text-slate-400 ml-1.5">({activeHoverPoint.dateRange})</span>
              </div>
              <span className="flex items-center gap-1 text-[10px] text-emerald-400 font-mono">
                <MousePointerClick className="w-3 h-3" />
                Click to inspect
              </span>
            </div>

            <div className="space-y-1 font-mono text-[11px]">
              <div className="flex items-center justify-between text-emerald-400">
                <span className="flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  Completed:
                </span>
                <span className="font-bold">{activeHoverPoint.completedTasks} tasks</span>
              </div>
              <div className="flex items-center justify-between text-indigo-300">
                <span className="flex items-center gap-1">
                  <Layers className="w-3 h-3 text-indigo-400" />
                  In Progress:
                </span>
                <span>{activeHoverPoint.inProgressTasks} tasks</span>
              </div>
              {activeHoverPoint.blockedTasks > 0 && (
                <div className="flex items-center justify-between text-rose-400">
                  <span className="flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3 text-rose-400" />
                    Blocked:
                  </span>
                  <span>{activeHoverPoint.blockedTasks} tasks</span>
                </div>
              )}
              <div className="flex items-center justify-between text-amber-300 border-t border-slate-850 pt-1 mt-1">
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3 text-amber-400" />
                  Hours Logged:
                </span>
                <span className="font-bold">{activeHoverPoint.actualHours} hrs (est. {activeHoverPoint.estimatedHours}h)</span>
              </div>
              {activeHoverPoint.revenueBilled > 0 && (
                <div className="flex items-center justify-between text-indigo-200">
                  <span>Weekly Invoiced:</span>
                  <span className="font-bold">{formatCurrency(activeHoverPoint.revenueBilled)}</span>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Legend & Legend Guide */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800 text-xs text-slate-400">
        <div className="flex items-center gap-4">
          {viewMode === 'tasks' && (
            <>
              <div className="flex items-center gap-1.5 font-mono text-[11px]">
                <span className="w-2.5 h-2.5 bg-emerald-500 rounded-none inline-block" />
                <span>Completed Tasks</span>
              </div>
              <div className="flex items-center gap-1.5 font-mono text-[11px]">
                <span className="w-2.5 h-2.5 bg-indigo-500 rounded-none inline-block" />
                <span>In-Progress Active</span>
              </div>
              <div className="flex items-center gap-1.5 font-mono text-[11px]">
                <span className="w-2.5 h-2.5 bg-rose-500 rounded-none inline-block" />
                <span>Blocked / Issues</span>
              </div>
            </>
          )}

          {viewMode === 'hours' && (
            <>
              <div className="flex items-center gap-1.5 font-mono text-[11px]">
                <span className="w-2.5 h-2.5 bg-amber-500 rounded-none inline-block" />
                <span>Actual Hours Logged</span>
              </div>
              <div className="flex items-center gap-1.5 font-mono text-[11px]">
                <span className="w-2.5 h-2.5 bg-slate-600 rounded-none inline-block" />
                <span>Estimated Hours Planned</span>
              </div>
            </>
          )}

          {viewMode === 'revenue' && (
            <div className="flex items-center gap-1.5 font-mono text-[11px]">
              <span className="w-2.5 h-2.5 bg-indigo-400 rounded-none inline-block" />
              <span>Revenue Invoiced in Sprint Week</span>
            </div>
          )}
        </div>

        <div className="text-[11px] font-mono text-slate-500">
          Tip: Click any bar to inspect itemized tasks & team velocity
        </div>
      </div>
    </div>
  );
};
