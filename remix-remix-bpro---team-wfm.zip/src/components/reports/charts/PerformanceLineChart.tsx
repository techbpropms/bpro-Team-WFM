import React, { useState } from 'react';
import { getSmoothBezierPath, getAreaPath, Point, formatCompactCurrency } from './chartUtils';
import { TrendingUp, MousePointerClick, Info, Eye, EyeOff } from 'lucide-react';

export interface MonthlyPerformancePoint {
  monthKey: string; // e.g. "2026-05"
  monthLabel: string; // e.g. "May 2026"
  shortLabel: string; // e.g. "May"
  revenue: number;
  expenses: number;
  netProfit: number;
  billableHours: number;
  completedTasks: number;
  invoiceCount: number;
  expenseCount: number;
}

interface PerformanceLineChartProps {
  data: MonthlyPerformancePoint[];
  formatCurrency: (amount: number) => string;
  onDrillDown: (point: MonthlyPerformancePoint) => void;
  selectedMonthKey?: string | null;
}

export const PerformanceLineChart: React.FC<PerformanceLineChartProps> = ({
  data,
  formatCurrency,
  onDrillDown,
  selectedMonthKey,
}) => {
  const [activeSeries, setActiveSeries] = useState({
    revenue: true,
    expenses: true,
    netProfit: true,
    hours: true,
  });

  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  if (!data || data.length === 0) {
    return (
      <div className="p-8 text-center bg-slate-900 border border-slate-800 text-slate-400 text-xs font-mono">
        No performance records matching current filter scope.
      </div>
    );
  }

  // Chart dimensions & coordinates
  const width = 840;
  const height = 320;
  const padding = { top: 30, right: 35, bottom: 45, left: 65 };
  const chartW = width - padding.left - padding.right;
  const chartH = height - padding.top - padding.bottom;

  // Maximum value for currency scaling (Revenue, Expenses, Net Profit)
  const maxCurrency = Math.max(
    100000,
    ...data.flatMap(d => [
      activeSeries.revenue ? d.revenue : 0,
      activeSeries.expenses ? d.expenses : 0,
      activeSeries.netProfit ? Math.max(0, d.netProfit) : 0,
    ])
  ) * 1.15; // 15% headroom

  // Maximum value for hours scaling (right axis concept)
  const maxHours = Math.max(20, ...data.map(d => d.billableHours)) * 1.25;

  // Coordinate mapping functions
  const getX = (index: number): number => {
    if (data.length === 1) return padding.left + chartW / 2;
    return padding.left + (index / (data.length - 1)) * chartW;
  };

  const getYCurrency = (val: number): number => {
    const clamped = Math.max(0, val);
    return padding.top + chartH - (clamped / maxCurrency) * chartH;
  };

  const getYHours = (val: number): number => {
    const clamped = Math.max(0, val);
    return padding.top + chartH - (clamped / maxHours) * chartH;
  };

  // Generate series point arrays
  const revenuePoints: Point[] = data.map((d, i) => ({ x: getX(i), y: getYCurrency(d.revenue) }));
  const expensePoints: Point[] = data.map((d, i) => ({ x: getX(i), y: getYCurrency(d.expenses) }));
  const profitPoints: Point[] = data.map((d, i) => ({ x: getX(i), y: getYCurrency(d.netProfit) }));
  const hoursPoints: Point[] = data.map((d, i) => ({ x: getX(i), y: getYHours(d.billableHours) }));

  // Horizontal Grid Lines (4 steps)
  const gridTicks = [0, 0.33, 0.66, 1];

  // Highlights and summary calculations
  const totalRevenue = data.reduce((acc, d) => acc + d.revenue, 0);
  const totalExpenses = data.reduce((acc, d) => acc + d.expenses, 0);
  const totalNet = totalRevenue - totalExpenses;
  const totalHours = data.reduce((acc, d) => acc + d.billableHours, 0);
  const avgMarginRate = totalRevenue > 0 ? Math.round((totalNet / totalRevenue) * 100) : 0;

  // Active point for tooltip
  const activeHoverPoint = hoveredIndex !== null ? data[hoveredIndex] : null;

  return (
    <div className="bg-slate-900 border border-slate-800 p-5 space-y-4">
      {/* Chart Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-indigo-400" />
              <span>Monthly Performance & Financial Trajectory</span>
            </h3>
            <span className="text-[10px] font-mono text-indigo-300 bg-indigo-950/70 border border-indigo-800/80 px-2 py-0.5">
              Interactive Trends
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Revenue realized vs. operational costs, net margin & billable delivery hours. Click any data point to drill down.
          </p>
        </div>

        {/* Series Toggles */}
        <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
          <button
            type="button"
            onClick={() => setActiveSeries(s => ({ ...s, revenue: !s.revenue }))}
            className={`flex items-center gap-1.5 px-2.5 py-1 border transition-colors ${
              activeSeries.revenue
                ? 'bg-indigo-950/80 border-indigo-600 text-indigo-200'
                : 'bg-slate-950 border-slate-800 text-slate-500 line-through'
            }`}
          >
            <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 inline-block" />
            <span>Revenue</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSeries(s => ({ ...s, expenses: !s.expenses }))}
            className={`flex items-center gap-1.5 px-2.5 py-1 border transition-colors ${
              activeSeries.expenses
                ? 'bg-rose-950/80 border-rose-600 text-rose-200'
                : 'bg-slate-950 border-slate-800 text-slate-500 line-through'
            }`}
          >
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block" />
            <span>Expenses</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSeries(s => ({ ...s, netProfit: !s.netProfit }))}
            className={`flex items-center gap-1.5 px-2.5 py-1 border transition-colors ${
              activeSeries.netProfit
                ? 'bg-emerald-950/80 border-emerald-600 text-emerald-200'
                : 'bg-slate-950 border-slate-800 text-slate-500 line-through'
            }`}
          >
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" />
            <span>Net Margin</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSeries(s => ({ ...s, hours: !s.hours }))}
            className={`flex items-center gap-1.5 px-2.5 py-1 border transition-colors ${
              activeSeries.hours
                ? 'bg-amber-950/80 border-amber-600 text-amber-200'
                : 'bg-slate-950 border-slate-800 text-slate-500 line-through'
            }`}
          >
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block" />
            <span>Hours</span>
          </button>
        </div>
      </div>

      {/* SVG Canvas Area */}
      <div className="relative w-full overflow-hidden select-none">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto overflow-visible font-mono"
          preserveAspectRatio="xMidYMid meet"
        >
          <defs>
            {/* Gradients for smooth area fills */}
            <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#6366f1" stopOpacity="0.35" />
              <stop offset="100%" stopColor="#6366f1" stopOpacity="0.0" />
            </linearGradient>
            <linearGradient id="profitGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#10b981" stopOpacity="0.25" />
              <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
            </linearGradient>
            <linearGradient id="expenseGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.2" />
              <stop offset="100%" stopColor="#f43f5e" stopOpacity="0.0" />
            </linearGradient>
          </defs>

          {/* Horizontal Grid Lines & Left Axis Labels */}
          {gridTicks.map((tick, i) => {
            const yPos = padding.top + chartH * (1 - tick);
            const val = tick * maxCurrency;
            return (
              <g key={i}>
                <line
                  x1={padding.left}
                  y1={yPos}
                  x2={width - padding.right}
                  y2={yPos}
                  stroke="#1e293b"
                  strokeDasharray="4 4"
                  strokeWidth="1"
                />
                <text
                  x={padding.left - 10}
                  y={yPos + 3.5}
                  fill="#64748b"
                  fontSize="10"
                  textAnchor="end"
                >
                  {formatCompactCurrency(val)}
                </text>
              </g>
            );
          })}

          {/* Right Axis Tick Labels for Billable Hours */}
          {activeSeries.hours && (
            <g>
              <text
                x={width - padding.right + 10}
                y={padding.top + 4}
                fill="#f59e0b"
                fontSize="10"
                textAnchor="start"
              >
                {Math.round(maxHours)}h
              </text>
              <text
                x={width - padding.right + 10}
                y={padding.top + chartH + 4}
                fill="#f59e0b"
                fontSize="10"
                textAnchor="start"
              >
                0h
              </text>
            </g>
          )}

          {/* Area Fills under curves */}
          {activeSeries.revenue && (
            <path
              d={getAreaPath(revenuePoints, padding.top + chartH)}
              fill="url(#revenueGradient)"
            />
          )}
          {activeSeries.netProfit && (
            <path
              d={getAreaPath(profitPoints, padding.top + chartH)}
              fill="url(#profitGradient)"
            />
          )}

          {/* Line Curves */}
          {activeSeries.revenue && (
            <path
              d={getSmoothBezierPath(revenuePoints)}
              fill="none"
              stroke="#6366f1"
              strokeWidth="2.5"
              strokeLinecap="round"
            />
          )}

          {activeSeries.expenses && (
            <path
              d={getSmoothBezierPath(expensePoints)}
              fill="none"
              stroke="#f43f5e"
              strokeWidth="2"
              strokeDasharray="5 3"
              strokeLinecap="round"
            />
          )}

          {activeSeries.netProfit && (
            <path
              d={getSmoothBezierPath(profitPoints)}
              fill="none"
              stroke="#10b981"
              strokeWidth="2.5"
              strokeLinecap="round"
            />
          )}

          {activeSeries.hours && (
            <path
              d={getSmoothBezierPath(hoursPoints)}
              fill="none"
              stroke="#fbbf24"
              strokeWidth="1.75"
              strokeDasharray="2 3"
              strokeLinecap="round"
            />
          )}

          {/* Active Hover Crosshair Line */}
          {hoveredIndex !== null && (
            <line
              x1={getX(hoveredIndex)}
              y1={padding.top}
              x2={getX(hoveredIndex)}
              y2={padding.top + chartH}
              stroke="#94a3b8"
              strokeWidth="1.5"
              strokeDasharray="3 3"
            />
          )}

          {/* Data Points and Click Targets for Drill Down */}
          {data.map((point, i) => {
            const x = getX(i);
            const isSelected = selectedMonthKey === point.monthKey;
            const isHovered = hoveredIndex === i;

            return (
              <g
                key={point.monthKey}
                className="cursor-pointer transition-transform"
                onClick={() => onDrillDown(point)}
                onMouseEnter={() => setHoveredIndex(i)}
                onMouseLeave={() => setHoveredIndex(null)}
              >
                {/* Invisible large click bar for easy tap / mouse hit target */}
                <rect
                  x={x - (chartW / (data.length * 2 || 1))}
                  y={padding.top}
                  width={chartW / (data.length || 1)}
                  height={chartH + 30}
                  fill="transparent"
                />

                {/* Selected month glow highlight column */}
                {isSelected && (
                  <rect
                    x={x - 18}
                    y={padding.top}
                    width={36}
                    height={chartH}
                    fill="#6366f1"
                    fillOpacity="0.1"
                    stroke="#6366f1"
                    strokeDasharray="2 2"
                  />
                )}

                {/* Revenue Circle */}
                {activeSeries.revenue && (
                  <circle
                    cx={x}
                    cy={getYCurrency(point.revenue)}
                    r={isHovered ? 6 : isSelected ? 5.5 : 4}
                    fill="#1e1b4b"
                    stroke="#818cf8"
                    strokeWidth={isHovered ? 2.5 : 2}
                  />
                )}

                {/* Net Profit Circle */}
                {activeSeries.netProfit && (
                  <circle
                    cx={x}
                    cy={getYCurrency(point.netProfit)}
                    r={isHovered ? 6 : isSelected ? 5.5 : 4}
                    fill="#064e3b"
                    stroke="#34d399"
                    strokeWidth={isHovered ? 2.5 : 2}
                  />
                )}

                {/* Expenses Circle */}
                {activeSeries.expenses && (
                  <circle
                    cx={x}
                    cy={getYCurrency(point.expenses)}
                    r={isHovered ? 5.5 : 3.5}
                    fill="#881337"
                    stroke="#fb7185"
                    strokeWidth={1.5}
                  />
                )}

                {/* Hours Circle */}
                {activeSeries.hours && (
                  <circle
                    cx={x}
                    cy={getYHours(point.billableHours)}
                    r={isHovered ? 5 : 3}
                    fill="#78350f"
                    stroke="#fde047"
                    strokeWidth={1.5}
                  />
                )}

                {/* X-Axis Month Label */}
                <text
                  x={x}
                  y={padding.top + chartH + 20}
                  fill={isSelected ? '#818cf8' : isHovered ? '#f8fafc' : '#94a3b8'}
                  fontSize={isSelected || isHovered ? '11' : '10'}
                  fontWeight={isSelected || isHovered ? 'bold' : 'normal'}
                  textAnchor="middle"
                >
                  {point.shortLabel}
                </text>
                <text
                  x={x}
                  y={padding.top + chartH + 32}
                  fill="#475569"
                  fontSize="8"
                  textAnchor="middle"
                >
                  {point.monthKey.substring(0, 4)}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Floating Detail Tooltip on Hover */}
        {activeHoverPoint && hoveredIndex !== null && (
          <div
            className="absolute top-2 z-20 pointer-events-none bg-slate-950/95 border border-slate-700/80 shadow-2xl p-3 text-xs rounded-none backdrop-blur-md min-w-[210px]"
            style={{
              left: Math.min(
                Math.max(10, getX(hoveredIndex) - 100),
                width - 230
              ),
            }}
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-1.5 mb-2">
              <span className="font-bold text-slate-100">{activeHoverPoint.monthLabel}</span>
              <span className="flex items-center gap-1 text-[10px] text-indigo-400 font-mono">
                <MousePointerClick className="w-3 h-3" />
                Click to drill down
              </span>
            </div>

            <div className="space-y-1 font-mono text-[11px]">
              <div className="flex items-center justify-between text-indigo-300">
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-indigo-500" />
                  Revenue:
                </span>
                <span className="font-bold">{formatCurrency(activeHoverPoint.revenue)}</span>
              </div>
              <div className="flex items-center justify-between text-rose-300">
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-rose-500" />
                  Expenses:
                </span>
                <span>{formatCurrency(activeHoverPoint.expenses)}</span>
              </div>
              <div className="flex items-center justify-between text-emerald-400 font-bold border-t border-slate-850 pt-1 mt-1">
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  Net Profit:
                </span>
                <span>{formatCurrency(activeHoverPoint.netProfit)}</span>
              </div>
              <div className="flex items-center justify-between text-amber-300 pt-0.5">
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-amber-400" />
                  Billable Hours:
                </span>
                <span>{activeHoverPoint.billableHours} hrs</span>
              </div>
              <div className="flex items-center justify-between text-slate-400 text-[10px] pt-1 border-t border-slate-850">
                <span>Invoices: {activeHoverPoint.invoiceCount}</span>
                <span>Receipts: {activeHoverPoint.expenseCount}</span>
                <span>Tasks: {activeHoverPoint.completedTasks}</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Trajectory Insights Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-2 border-t border-slate-800/80 text-xs">
        <div className="p-2.5 bg-slate-950 border border-slate-850 space-y-0.5">
          <span className="text-[10px] font-mono text-slate-400 uppercase">Period Total Revenue</span>
          <div className="text-sm font-bold font-mono text-indigo-400">{formatCurrency(totalRevenue)}</div>
        </div>
        <div className="p-2.5 bg-slate-950 border border-slate-850 space-y-0.5">
          <span className="text-[10px] font-mono text-slate-400 uppercase">Total Expenses</span>
          <div className="text-sm font-bold font-mono text-rose-400">{formatCurrency(totalExpenses)}</div>
        </div>
        <div className="p-2.5 bg-slate-950 border border-slate-850 space-y-0.5">
          <span className="text-[10px] font-mono text-slate-400 uppercase">Average Margin Rate</span>
          <div className="text-sm font-bold font-mono text-emerald-400">{avgMarginRate}% Profitability</div>
        </div>
        <div className="p-2.5 bg-slate-950 border border-slate-850 space-y-0.5">
          <span className="text-[10px] font-mono text-slate-400 uppercase">Total Billable Output</span>
          <div className="text-sm font-bold font-mono text-amber-400">{totalHours} Engineering Hrs</div>
        </div>
      </div>
    </div>
  );
};
