import React, { useState, useMemo } from 'react';
import { 
  X, 
  Search, 
  Download, 
  FileSpreadsheet, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Receipt, 
  Layers, 
  DollarSign, 
  Calendar, 
  User, 
  Briefcase,
  ExternalLink
} from 'lucide-react';
import { Task, Invoice, Expense, Project, Client, TeamMember } from '../../../types';
import { exportToCsv } from '../../../services/csvExport';

export interface DrillDownContext {
  type: 'month' | 'week' | 'category' | 'project' | 'team_member';
  title: string;
  subtitle: string;
  filterKey: string;
}

interface DrillDownModalProps {
  isOpen: boolean;
  onClose: () => void;
  context: DrillDownContext | null;
  tasks: Task[];
  invoices: Invoice[];
  expenses: Expense[];
  projects: Project[];
  clients: Client[];
  teamMembers: TeamMember[];
  formatCurrency: (amount: number) => string;
}

export const DrillDownModal: React.FC<DrillDownModalProps> = ({
  isOpen,
  onClose,
  context,
  tasks,
  invoices,
  expenses,
  projects,
  clients,
  teamMembers,
  formatCurrency,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'invoices' | 'expenses' | 'tasks'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  if (!isOpen || !context) return null;

  // Filter records matching drill-down context
  const filteredInvoices = useMemo(() => {
    return invoices.filter(inv => {
      if (context.type === 'month') {
        return inv.issueDate.startsWith(context.filterKey) || (inv.paidAt && inv.paidAt.startsWith(context.filterKey));
      }
      if (context.type === 'project') {
        return inv.projectId === context.filterKey;
      }
      if (context.type === 'category') {
        return false; // Invoices don't have expense categories
      }
      return true;
    });
  }, [invoices, context]);

  const filteredExpenses = useMemo(() => {
    return expenses.filter(exp => {
      if (context.type === 'month') {
        return exp.date.startsWith(context.filterKey);
      }
      if (context.type === 'category') {
        if (context.filterKey === 'billable') return exp.isBillable;
        if (context.filterKey === 'non_billable') return !exp.isBillable;
        return exp.category === context.filterKey;
      }
      if (context.type === 'project') {
        return exp.projectId === context.filterKey;
      }
      if (context.type === 'team_member') {
        return exp.submittedById === context.filterKey;
      }
      return true;
    });
  }, [expenses, context]);

  const filteredTasks = useMemo(() => {
    return tasks.filter(t => {
      if (context.type === 'month') {
        return t.dueDate.startsWith(context.filterKey) || t.createdAt.startsWith(context.filterKey);
      }
      if (context.type === 'week') {
        // Match week from task dueDate or createdAt
        return true; // Parent passes already week-scoped tasks
      }
      if (context.type === 'project') {
        return t.projectId === context.filterKey;
      }
      if (context.type === 'team_member') {
        return t.assignedToId === context.filterKey;
      }
      if (context.type === 'category') {
        return false;
      }
      return true;
    });
  }, [tasks, context]);

  // Apply search query across datasets
  const query = searchQuery.toLowerCase().trim();

  const searchedInvoices = filteredInvoices.filter(i => {
    if (!query) return true;
    const client = clients.find(c => c.id === i.clientId);
    return (
      i.invoiceNumber.toLowerCase().includes(query) ||
      (client?.name && client.name.toLowerCase().includes(query)) ||
      (client?.company && client.company.toLowerCase().includes(query)) ||
      i.status.toLowerCase().includes(query)
    );
  });

  const searchedExpenses = filteredExpenses.filter(e => {
    if (!query) return true;
    return (
      e.description.toLowerCase().includes(query) ||
      e.category.toLowerCase().includes(query) ||
      e.submittedByName.toLowerCase().includes(query) ||
      e.status.toLowerCase().includes(query)
    );
  });

  const searchedTasks = filteredTasks.filter(t => {
    if (!query) return true;
    const assignee = teamMembers.find(m => m.id === t.assignedToId);
    return (
      t.title.toLowerCase().includes(query) ||
      t.description.toLowerCase().includes(query) ||
      (assignee?.name && assignee.name.toLowerCase().includes(query)) ||
      t.status.toLowerCase().includes(query) ||
      t.priority.toLowerCase().includes(query)
    );
  });

  // Calculate totals
  const totalInvoiced = searchedInvoices.reduce((acc, i) => acc + i.total, 0);
  const totalExpenseVal = searchedExpenses.reduce((acc, e) => acc + e.amount, 0);
  const totalTaskHours = searchedTasks.reduce((acc, t) => acc + t.actualHours, 0);

  // Available tabs
  const hasInvoices = filteredInvoices.length > 0;
  const hasExpenses = filteredExpenses.length > 0;
  const hasTasks = filteredTasks.length > 0;

  // CSV Export for drilled subset
  const handleExportDrillDownCsv = () => {
    const filename = `BproPMS_DrillDown_${context.type}_${context.filterKey}_${new Date().toISOString().substring(0, 10)}`;

    if (activeTab === 'expenses' || (hasExpenses && !hasInvoices && !hasTasks)) {
      const rows = searchedExpenses.map(e => ({
        'Expense ID': e.id,
        'Date': e.date,
        'Category': e.category,
        'Description': e.description,
        'Amount': e.amount,
        'Currency': e.currency,
        'Billable': e.isBillable ? 'YES' : 'NO',
        'Status': e.status.toUpperCase(),
        'Submitted By': e.submittedByName,
        'Receipt Attached': e.receiptFileName || 'None',
      }));
      exportToCsv(filename, rows);
    } else if (activeTab === 'invoices' || (hasInvoices && !hasExpenses && !hasTasks)) {
      const rows = searchedInvoices.map(i => {
        const client = clients.find(c => c.id === i.clientId);
        return {
          'Invoice #': i.invoiceNumber,
          'Client': client?.company || client?.name || i.clientId,
          'Issue Date': i.issueDate,
          'Due Date': i.dueDate,
          'Status': i.status.toUpperCase(),
          'Subtotal': i.subtotal,
          'Tax (GST 18%)': i.taxAmount,
          'Total': i.total,
        };
      });
      exportToCsv(filename, rows);
    } else {
      const rows = searchedTasks.map(t => {
        const proj = projects.find(p => p.id === t.projectId);
        const assignee = teamMembers.find(m => m.id === t.assignedToId);
        return {
          'Task ID': t.id,
          'Title': t.title,
          'Project': proj?.code || '',
          'Assignee': assignee?.name || '',
          'Status': t.status.toUpperCase(),
          'Priority': t.priority.toUpperCase(),
          'Due Date': t.dueDate,
          'Actual Hours': t.actualHours,
          'Estimated Hours': t.estimatedHours,
          'Postponements': t.amendments.length,
        };
      });
      exportToCsv(filename, rows);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150">
        {/* Modal Top Header */}
        <div className="px-5 py-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="space-y-0.5">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono uppercase bg-indigo-950 text-indigo-300 border border-indigo-700/80 px-2 py-0.5">
                Drill-Down Inspection
              </span>
              <h2 className="text-base font-bold text-slate-100">{context.title}</h2>
            </div>
            <p className="text-xs text-slate-400">{context.subtitle}</p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleExportDrillDownCsv}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition-colors"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">Export CSV</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
              aria-label="Close Drill-Down"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Drill-down Summary Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-slate-950/60 border-b border-slate-800 text-xs">
          {hasInvoices && (
            <div className="p-2.5 bg-slate-900 border border-slate-800 space-y-0.5">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Invoiced Volume</span>
              <div className="text-sm font-bold font-mono text-indigo-400">{formatCurrency(totalInvoiced)}</div>
              <span className="text-[10px] text-slate-500 font-mono">{searchedInvoices.length} invoices</span>
            </div>
          )}

          {hasExpenses && (
            <div className="p-2.5 bg-slate-900 border border-slate-800 space-y-0.5">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Operating Expenses</span>
              <div className="text-sm font-bold font-mono text-rose-400">{formatCurrency(totalExpenseVal)}</div>
              <span className="text-[10px] text-slate-500 font-mono">{searchedExpenses.length} receipts</span>
            </div>
          )}

          {hasTasks && (
            <div className="p-2.5 bg-slate-900 border border-slate-800 space-y-0.5">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Logged Hours</span>
              <div className="text-sm font-bold font-mono text-amber-400">{totalTaskHours} hrs</div>
              <span className="text-[10px] text-slate-500 font-mono">{searchedTasks.length} tasks</span>
            </div>
          )}

          <div className="p-2.5 bg-slate-900 border border-slate-800 space-y-0.5">
            <span className="text-[10px] font-mono text-slate-400 uppercase">Audit Status</span>
            <div className="text-sm font-bold font-mono text-emerald-400 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              Reconciled
            </div>
            <span className="text-[10px] text-slate-500 font-mono">Real-time sync active</span>
          </div>
        </div>

        {/* Filter & Sub-tabs Bar */}
        <div className="p-3 bg-slate-900 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Sub-tabs */}
          <div className="flex items-center border border-slate-800 bg-slate-950 p-0.5 text-xs font-mono">
            <button
              type="button"
              onClick={() => setActiveTab('all')}
              className={`px-3 py-1 transition-colors ${
                activeTab === 'all' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All Records
            </button>
            {hasInvoices && (
              <button
                type="button"
                onClick={() => setActiveTab('invoices')}
                className={`px-3 py-1 transition-colors ${
                  activeTab === 'invoices' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Invoices ({filteredInvoices.length})
              </button>
            )}
            {hasExpenses && (
              <button
                type="button"
                onClick={() => setActiveTab('expenses')}
                className={`px-3 py-1 transition-colors ${
                  activeTab === 'expenses' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Expenses ({filteredExpenses.length})
              </button>
            )}
            {hasTasks && (
              <button
                type="button"
                onClick={() => setActiveTab('tasks')}
                className={`px-3 py-1 transition-colors ${
                  activeTab === 'tasks' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Tasks ({filteredTasks.length})
              </button>
            )}
          </div>

          {/* Search Input inside Drill-Down */}
          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter within drilled records..."
              className="w-full bg-slate-950 border border-slate-800 text-slate-200 pl-8 pr-3 py-1.5 text-xs placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Scrollable Records Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Section 1: Invoices Table */}
          {(activeTab === 'all' || activeTab === 'invoices') && hasInvoices && (
            <div className="border border-slate-800 bg-slate-950 overflow-hidden">
              <div className="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                  <DollarSign className="w-3.5 h-3.5 text-indigo-400" />
                  Invoices & Receivables ({searchedInvoices.length})
                </span>
                <span className="text-[11px] font-mono text-emerald-400 font-bold">
                  {formatCurrency(searchedInvoices.reduce((a, b) => a + b.total, 0))}
                </span>
              </div>

              {searchedInvoices.length === 0 ? (
                <div className="p-4 text-center text-xs text-slate-500 font-mono">
                  No invoices match your search.
                </div>
              ) : (
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-mono text-[11px]">
                      <th className="p-2.5">INVOICE #</th>
                      <th className="p-2.5">CLIENT</th>
                      <th className="p-2.5">ISSUE DATE</th>
                      <th className="p-2.5">STATUS</th>
                      <th className="p-2.5 text-right">TOTAL</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-850 text-slate-300 font-mono text-[11px]">
                    {searchedInvoices.map((inv) => {
                      const client = clients.find(c => c.id === inv.clientId);
                      return (
                        <tr key={inv.id} className="hover:bg-slate-900/60">
                          <td className="p-2.5 font-bold text-slate-100">{inv.invoiceNumber}</td>
                          <td className="p-2.5 font-sans font-medium text-slate-200">
                            {client?.company || client?.name || inv.clientId}
                          </td>
                          <td className="p-2.5 text-slate-400">{inv.issueDate}</td>
                          <td className="p-2.5">
                            <span
                              className={`text-[10px] px-2 py-0.5 font-bold ${
                                inv.status === 'paid'
                                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                                  : inv.status === 'sent'
                                  ? 'bg-indigo-950 text-indigo-400 border border-indigo-800'
                                  : 'bg-slate-800 text-slate-400'
                              }`}
                            >
                              {inv.status.toUpperCase()}
                            </span>
                          </td>
                          <td className="p-2.5 text-right font-bold text-slate-100">
                            {formatCurrency(inv.total)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>
          )}

          {/* Section 2: Expenses Table */}
          {(activeTab === 'all' || activeTab === 'expenses') && hasExpenses && (
            <div className="border border-slate-800 bg-slate-950 overflow-hidden">
              <div className="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                  <Receipt className="w-3.5 h-3.5 text-rose-400" />
                  Itemized Expenses & Vouchers ({searchedExpenses.length})
                </span>
                <span className="text-[11px] font-mono text-rose-400 font-bold">
                  {formatCurrency(searchedExpenses.reduce((a, b) => a + b.amount, 0))}
                </span>
              </div>

              {searchedExpenses.length === 0 ? (
                <div className="p-4 text-center text-xs text-slate-500 font-mono">
                  No expense records match your search.
                </div>
              ) : (
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-mono text-[11px]">
                      <th className="p-2.5">DATE</th>
                      <th className="p-2.5">CATEGORY</th>
                      <th className="p-2.5">DESCRIPTION</th>
                      <th className="p-2.5">SUBMITTED BY</th>
                      <th className="p-2.5">BILLABLE</th>
                      <th className="p-2.5">STATUS</th>
                      <th className="p-2.5 text-right">AMOUNT</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-850 text-slate-300 font-mono text-[11px]">
                    {searchedExpenses.map((exp) => (
                      <tr key={exp.id} className="hover:bg-slate-900/60">
                        <td className="p-2.5 text-slate-400">{exp.date}</td>
                        <td className="p-2.5 text-slate-300 font-sans font-medium">
                          {exp.category.replace('_', ' ').toUpperCase()}
                        </td>
                        <td className="p-2.5 font-sans text-slate-200 max-w-xs truncate" title={exp.description}>
                          {exp.description}
                        </td>
                        <td className="p-2.5 text-slate-300 font-sans">{exp.submittedByName}</td>
                        <td className="p-2.5">
                          {exp.isBillable ? (
                            <span className="text-[10px] text-emerald-400 font-bold">YES (Pass-thru)</span>
                          ) : (
                            <span className="text-[10px] text-slate-500">NO</span>
                          )}
                        </td>
                        <td className="p-2.5">
                          <span
                            className={`text-[10px] px-1.5 py-0.5 ${
                              exp.status === 'approved'
                                ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                                : 'bg-amber-950 text-amber-400 border border-amber-800'
                            }`}
                          >
                            {exp.status.toUpperCase()}
                          </span>
                        </td>
                        <td className="p-2.5 text-right font-bold text-rose-300">
                          {formatCurrency(exp.amount)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          )}

          {/* Section 3: Tasks Table */}
          {(activeTab === 'all' || activeTab === 'tasks') && hasTasks && (
            <div className="border border-slate-800 bg-slate-950 overflow-hidden">
              <div className="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-amber-400" />
                  Engineering & Operational Tasks ({searchedTasks.length})
                </span>
                <span className="text-[11px] font-mono text-amber-400 font-bold">
                  {searchedTasks.reduce((a, b) => a + b.actualHours, 0)} hours logged
                </span>
              </div>

              {searchedTasks.length === 0 ? (
                <div className="p-4 text-center text-xs text-slate-500 font-mono">
                  No tasks match your search.
                </div>
              ) : (
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-mono text-[11px]">
                      <th className="p-2.5">TASK TITLE</th>
                      <th className="p-2.5">PROJECT</th>
                      <th className="p-2.5">ASSIGNEE</th>
                      <th className="p-2.5">DUE DATE</th>
                      <th className="p-2.5">STATUS</th>
                      <th className="p-2.5 text-right">HOURS</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-850 text-slate-300 font-mono text-[11px]">
                    {searchedTasks.map((t) => {
                      const proj = projects.find(p => p.id === t.projectId);
                      const assignee = teamMembers.find(m => m.id === t.assignedToId);
                      return (
                        <tr key={t.id} className="hover:bg-slate-900/60">
                          <td className="p-2.5 font-sans font-medium text-slate-100 max-w-sm truncate" title={t.title}>
                            {t.title}
                            {t.amendments.length > 0 && (
                              <span className="ml-1.5 text-[9px] text-amber-400 font-mono">
                                (+{t.amendments.length} amendments)
                              </span>
                            )}
                          </td>
                          <td className="p-2.5 text-indigo-400 font-bold">{proj?.code || '-'}</td>
                          <td className="p-2.5 font-sans text-slate-300">{assignee?.name || '-'}</td>
                          <td className="p-2.5 text-slate-400">{t.dueDate}</td>
                          <td className="p-2.5">
                            <span
                              className={`text-[10px] px-1.5 py-0.5 ${
                                t.status === 'completed'
                                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                                  : t.status === 'in_progress'
                                  ? 'bg-indigo-950 text-indigo-400 border border-indigo-800'
                                  : t.status === 'blocked'
                                  ? 'bg-rose-950 text-rose-400 border border-rose-800'
                                  : 'bg-slate-800 text-slate-400'
                              }`}
                            >
                              {t.status.toUpperCase()}
                            </span>
                          </td>
                          <td className="p-2.5 text-right font-bold text-amber-300">
                            {t.actualHours}h / {t.estimatedHours}h
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>
          )}
        </div>

        {/* Modal Bottom Controls */}
        <div className="px-5 py-3 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs font-mono text-slate-400">
          <span>Drill-down filter: {context.filterKey}</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors"
          >
            Close Inspection
          </button>
        </div>
      </div>
    </div>
  );
};
