/**
 * Charting Math & Date Aggregation Utilities for Reporting Dashboard
 */

export interface Point {
  x: number;
  y: number;
}

/**
 * Computes a smooth SVG cubic Bezier curve path through an array of points
 */
export function getSmoothBezierPath(points: Point[]): string {
  if (points.length === 0) return '';
  if (points.length === 1) return `M ${points[0].x} ${points[0].y}`;
  if (points.length === 2) {
    return `M ${points[0].x} ${points[0].y} L ${points[1].x} ${points[1].y}`;
  }

  let path = `M ${points[0].x} ${points[0].y}`;

  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[Math.max(i - 1, 0)];
    const p1 = points[i];
    const p2 = points[i + 1];
    const p3 = points[Math.min(i + 2, points.length - 1)];

    // Catmull-Rom to Cubic Bezier control points calculation
    const tension = 0.2;
    const cp1x = p1.x + (p2.x - p0.x) * tension;
    const cp1y = p1.y + (p2.y - p0.y) * tension;
    const cp2x = p2.x - (p3.x - p1.x) * tension;
    const cp2y = p2.y - (p3.y - p1.y) * tension;

    path += ` C ${cp1x.toFixed(1)} ${cp1y.toFixed(1)}, ${cp2x.toFixed(1)} ${cp2y.toFixed(1)}, ${p2.x.toFixed(1)} ${p2.y.toFixed(1)}`;
  }

  return path;
}

/**
 * Generates closed area SVG path for gradient fill below line
 */
export function getAreaPath(points: Point[], baselineY: number): string {
  if (points.length < 2) return '';
  const linePath = getSmoothBezierPath(points);
  const last = points[points.length - 1];
  const first = points[0];
  return `${linePath} L ${last.x.toFixed(1)} ${baselineY.toFixed(1)} L ${first.x.toFixed(1)} ${baselineY.toFixed(1)} Z`;
}

/**
 * Polar to Cartesian coordinate converter
 */
export function polarToCartesian(centerX: number, centerY: number, radius: number, angleInDegrees: number) {
  const angleInRadians = ((angleInDegrees - 90) * Math.PI) / 180.0;
  return {
    x: centerX + radius * Math.cos(angleInRadians),
    y: centerY + radius * Math.sin(angleInRadians),
  };
}

/**
 * Computes SVG Path for a Donut/Pie Arc segment
 */
export function describeArc(
  x: number,
  y: number,
  radius: number,
  innerRadius: number,
  startAngle: number,
  endAngle: number
): string {
  // Clamp 360-degree full circle slightly so it doesn't self-close to zero
  const sweep = endAngle - startAngle;
  const isFullCircle = sweep >= 359.99;
  const safeEndAngle = isFullCircle ? startAngle + 359.99 : endAngle;

  const startOuter = polarToCartesian(x, y, radius, safeEndAngle);
  const endOuter = polarToCartesian(x, y, radius, startAngle);
  const startInner = polarToCartesian(x, y, innerRadius, startAngle);
  const endInner = polarToCartesian(x, y, innerRadius, safeEndAngle);

  const largeArcFlag = sweep <= 180 ? '0' : '1';

  if (innerRadius <= 0) {
    // Standard Pie slice
    return [
      'M', x, y,
      'L', endOuter.x, endOuter.y,
      'A', radius, radius, 0, largeArcFlag, 1, startOuter.x, startOuter.y,
      'Z',
    ].join(' ');
  }

  // Donut Arc
  return [
    'M', endOuter.x, endOuter.y,
    'A', radius, radius, 0, largeArcFlag, 1, startOuter.x, startOuter.y,
    'L', endInner.x, endInner.y,
    'A', innerRadius, innerRadius, 0, largeArcFlag, 0, startInner.x, startInner.y,
    'Z',
  ].join(' ');
}

/**
 * Get ISO Week number and human readable label
 */
export function getISOWeekInfo(dateInput: Date | string): {
  weekKey: string;
  label: string;
  startStr: string;
  endStr: string;
} {
  const date = typeof dateInput === 'string' ? new Date(dateInput) : new Date(dateInput.getTime());
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil(((d.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
  const year = d.getUTCFullYear();

  // Find start (Monday) and end (Sunday) of that week
  const curr = new Date(date);
  const currentDay = curr.getDay(); // 0 is Sunday
  const distanceToMonday = (currentDay + 6) % 7;
  const monday = new Date(curr);
  monday.setDate(curr.getDate() - distanceToMonday);
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);

  const startStr = monday.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  const endStr = sunday.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

  return {
    weekKey: `${year}-W${String(weekNo).padStart(2, '0')}`,
    label: `W${weekNo}`,
    startStr,
    endStr,
  };
}

/**
 * Compact Indian currency formatter (₹Lakhs, ₹Crores, or standard)
 */
export function formatCompactCurrency(amount: number): string {
  if (amount >= 10000000) {
    return `₹${(amount / 10000000).toFixed(2)} Cr`;
  }
  if (amount >= 100000) {
    return `₹${(amount / 100000).toFixed(1)} L`;
  }
  if (amount >= 1000) {
    return `₹${(amount / 1000).toFixed(0)}k`;
  }
  return `₹${Math.round(amount)}`;
}
