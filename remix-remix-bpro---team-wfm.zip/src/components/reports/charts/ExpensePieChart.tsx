import React, { useState } from 'react';
import { describeArc, formatCompactCurrency } from './chartUtils';
import { CreditCard, Receipt, MousePointerClick, CheckCircle2, ShieldCheck, Tag } from 'lucide-react';
import { ExpenseCategory } from '../../../types';

export interface ExpenseSliceData {
  key: string;
  label: string;
  amount: number;
  percentage: number;
  count: number;
  color: string;
  isBillableSplit?: boolean;
}

interface ExpensePieChartProps {
  slices: ExpenseSliceData[];
  totalExpenseAmount: number;
  billableAmount: number;
  nonBillableAmount: number;
  formatCurrency: (amount: number) => string;
  onDrillDown: (slice: ExpenseSliceData) => void;
  selectedCategoryKey?: string | null;
}

// Category palette mapping
export const EXPENSE_COLORS: Record<string, string> = {
  cloud_hosting: '#6366f1', // Indigo
  software_licenses: '#3b82f6', // Blue
  subcontractor: '#8b5cf6', // Violet
  travel: '#f59e0b', // Amber
  equipment: '#10b981', // Emerald
  meals_entertainment: '#ec4899', // Pink
  office_supplies: '#06b6d4', // Cyan
  other: '#94a3b8', // Slate
  billable: '#10b981', // Emerald
  non_billable: '#f43f5e', // Rose
};

export const ExpensePieChart: React.FC<ExpensePieChartProps> = ({
  slices,
  totalExpenseAmount,
  billableAmount,
  nonBillableAmount,
  formatCurrency,
  onDrillDown,
  selectedCategoryKey,
}) => {
  const [hoveredKey, setHoveredKey] = useState<string | null>(null);
  const [splitMode, setSplitMode] = useState<'category' | 'billable'>('category');

  // Compute billable slices if splitMode === 'billable'
  const activeSlices: ExpenseSliceData[] = splitMode === 'category' 
    ? slices 
    : [
        {
          key: 'billable',
          label: 'Client Billable (Reimbursable)',
          amount: billableAmount,
          percentage: totalExpenseAmount > 0 ? Math.round((billableAmount / totalExpenseAmount) * 100) : 0,
          count: 0,
          color: EXPENSE_COLORS.billable,
          isBillableSplit: true,
        },
        {
          key: 'non_billable',
          label: 'Non-Billable (Operating Overhead)',
          amount: nonBillableAmount,
          percentage: totalExpenseAmount > 0 ? Math.round((nonBillableAmount / totalExpenseAmount) * 100) : 0,
          count: 0,
          color: EXPENSE_COLORS.non_billable,
          isBillableSplit: true,
        },
      ];

  const total = activeSlices.reduce((acc, s) => acc + s.amount, 0);

  // Calculate arc angles
  let cumulativeAngle = 0;
  const arcsWithAngles = activeSlices.map((slice) => {
    const fraction = total > 0 ? slice.amount / total : 0;
    const sweep = fraction * 360;
    const startAngle = cumulativeAngle;
    const endAngle = cumulativeAngle + sweep;
    cumulativeAngle += sweep;
    return {
      ...slice,
      startAngle,
      endAngle,
      sweep,
    };
  });

  const hoveredSlice = activeSlices.find(s => s.key === hoveredKey) || null;

  const size = 260;
  const center = size / 2;
  const radius = 110;
  const innerRadius = 66;

  return (
    <div className="bg-slate-900 border border-slate-800 p-5 space-y-4">
      {/* Header & Toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-1.5">
              <Receipt className="w-4 h-4 text-amber-400" />
              <span>Operating Expense Analysis & Cost Allocation</span>
            </h3>
            <span className="text-[10px] font-mono text-amber-300 bg-amber-950/70 border border-amber-800/80 px-2 py-0.5">
              Interactive Donut
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Breakdown across cloud infrastructure, vendor licenses, contractor fees & travel. Click any slice to drill down.
          </p>
        </div>

        {/* Mode Toggle */}
        <div className="flex items-center border border-slate-800 bg-slate-950 p-0.5 text-xs font-mono">
          <button
            type="button"
            onClick={() => setSplitMode('category')}
            className={`px-3 py-1 transition-colors ${
              splitMode === 'category' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            By Category
          </button>
          <button
            type="button"
            onClick={() => setSplitMode('billable')}
            className={`px-3 py-1 transition-colors ${
              splitMode === 'billable' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Billable vs Overhead
          </button>
        </div>
      </div>

      {/* Main Content: Donut + Legend Layout */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
        {/* SVG Donut Container (Left) */}
        <div className="md:col-span-5 flex flex-col items-center justify-center relative select-none">
          <div className="relative w-[260px] h-[260px]">
            <svg
              viewBox={`0 0 ${size} ${size}`}
              className="w-full h-full transform -rotate-90 overflow-visible"
            >
              {arcsWithAngles.length === 0 || total === 0 ? (
                <circle
                  cx={center}
                  cy={center}
                  r={radius}
                  fill="none"
                  stroke="#1e293b"
                  strokeWidth="24"
                />
              ) : (
                arcsWithAngles.map((slice) => {
                  if (slice.sweep <= 0.05) return null;
                  const isHovered = hoveredKey === slice.key;
                  const isSelected = selectedCategoryKey === slice.key;
                  const currentRadius = isHovered || isSelected ? radius + 5 : radius;
                  const currentInner = isHovered || isSelected ? innerRadius - 2 : innerRadius;

                  const pathD = describeArc(
                    center,
                    center,
                    currentRadius,
                    currentInner,
                    slice.startAngle,
                    slice.endAngle
                  );

                  return (
                    <path
                      key={slice.key}
                      d={pathD}
                      fill={slice.color}
                      fillOpacity={isHovered || isSelected ? 1 : 0.82}
                      stroke="#020617"
                      strokeWidth="2"
                      className="cursor-pointer transition-all duration-200 ease-out hover:opacity-100"
                      onClick={() => onDrillDown(slice)}
                      onMouseEnter={() => setHoveredKey(slice.key)}
                      onMouseLeave={() => setHoveredKey(null)}
                    />
                  );
                })
              )}
            </svg>

            {/* Center Donut Label (HTML overlay for unrotated text) */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none p-4">
              {hoveredSlice ? (
                <div className="space-y-0.5 animate-in fade-in duration-150">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block truncate max-w-[120px]">
                    {hoveredSlice.label}
                  </span>
                  <div className="text-sm font-bold font-mono text-slate-100">
                    {formatCurrency(hoveredSlice.amount)}
                  </div>
                  <span className="text-[11px] font-mono text-indigo-400 font-bold block">
                    {hoveredSlice.percentage}% of total
                  </span>
                </div>
              ) : (
                <div className="space-y-0.5">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">
                    Total Expenses
                  </span>
                  <div className="text-sm font-bold font-mono text-slate-100">
                    {formatCurrency(totalExpenseAmount)}
                  </div>
                  <span className="text-[10px] font-mono text-slate-500 block">
                    {activeSlices.length} categories
                  </span>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-1.5 text-[11px] font-mono text-slate-400 mt-2">
            <MousePointerClick className="w-3.5 h-3.5 text-indigo-400" />
            <span>Click slice or legend item to drill down</span>
          </div>
        </div>

        {/* Legend / Category Breakdown Table (Right) */}
        <div className="md:col-span-7 space-y-2">
          <div className="border border-slate-800 bg-slate-950 overflow-hidden">
            <div className="px-3.5 py-2 bg-slate-900/80 border-b border-slate-800 flex items-center justify-between text-[11px] font-mono text-slate-400">
              <span>EXPENSE CATEGORY</span>
              <div className="flex items-center gap-6">
                <span>SHARE</span>
                <span className="w-24 text-right">AMOUNT (INR)</span>
              </div>
            </div>

            <div className="divide-y divide-slate-850/60 max-h-[260px] overflow-y-auto">
              {activeSlices.map((slice) => {
                const isHovered = hoveredKey === slice.key;
                const isSelected = selectedCategoryKey === slice.key;

                return (
                  <button
                    key={slice.key}
                    type="button"
                    onClick={() => onDrillDown(slice)}
                    onMouseEnter={() => setHoveredKey(slice.key)}
                    onMouseLeave={() => setHoveredKey(null)}
                    className={`w-full text-left px-3.5 py-2.5 flex items-center justify-between text-xs transition-colors ${
                      isSelected
                        ? 'bg-indigo-950/60 text-slate-100 border-l-2 border-indigo-500'
                        : isHovered
                        ? 'bg-slate-850/60 text-slate-100'
                        : 'text-slate-300 hover:bg-slate-900/50'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <span
                        className="w-2.5 h-2.5 shrink-0 rounded-none"
                        style={{ backgroundColor: slice.color }}
                      />
                      <span className="font-medium truncate">{slice.label}</span>
                      {slice.count > 0 && (
                        <span className="text-[10px] font-mono text-slate-500">
                          ({slice.count} receipts)
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-6 shrink-0 font-mono text-[11px]">
                      <span className="text-slate-400 w-10 text-right font-medium">
                        {slice.percentage}%
                      </span>
                      <span className="w-24 text-right font-bold text-slate-200">
                        {formatCurrency(slice.amount)}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Billable Recovery Metric Strip */}
          <div className="grid grid-cols-2 gap-3 pt-1">
            <div className="p-2.5 bg-slate-950 border border-slate-850 space-y-0.5">
              <span className="text-[10px] font-mono text-emerald-400 uppercase flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                Billable Client Pass-Through
              </span>
              <div className="text-xs font-bold font-mono text-slate-100">
                {formatCurrency(billableAmount)}
                <span className="text-[10px] text-slate-400 font-normal ml-1.5">
                  ({totalExpenseAmount > 0 ? Math.round((billableAmount / totalExpenseAmount) * 100) : 0}%)
                </span>
              </div>
            </div>

            <div className="p-2.5 bg-slate-950 border border-slate-850 space-y-0.5">
              <span className="text-[10px] font-mono text-rose-400 uppercase flex items-center gap-1">
                <Tag className="w-3 h-3 text-rose-400" />
                Internal Operational Overhead
              </span>
              <div className="text-xs font-bold font-mono text-slate-100">
                {formatCurrency(nonBillableAmount)}
                <span className="text-[10px] text-slate-400 font-normal ml-1.5">
                  ({totalExpenseAmount > 0 ? Math.round((nonBillableAmount / totalExpenseAmount) * 100) : 0}%)
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
