import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Project } from '../../types';
import { 
  FolderKanban, 
  Plus, 
  Calendar, 
  Clock, 
  DollarSign, 
  AlertTriangle, 
  CheckCircle2, 
  Users, 
  Activity,
  X 
} from 'lucide-react';

export const ProjectManager: React.FC = () => {
  const { projects, clients, allTeamMembers, tasks, currentUser, addProject, updateProject, searchQuery, formatCurrency } = useApp();
  const [isAddOpen, setIsAddOpen] = useState(false);

  // Form State
  const [title, setTitle] = useState('');
  const [code, setCode] = useState('');
  const [clientId, setClientId] = useState(clients[0]?.id || '');
  const [description, setDescription] = useState('');
  const [budget, setBudget] = useState(1500000);
  const [hourlyRate, setHourlyRate] = useState(4500);
  const [startDate, setStartDate] = useState(new Date().toISOString().substring(0, 10));
  const [targetDeadline, setTargetDeadline] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 60);
    return d.toISOString().substring(0, 10);
  });
  const [selectedMemberIds, setSelectedMemberIds] = useState<string[]>([currentUser.id]);

  const filteredProjects = projects.filter(p => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        p.title.toLowerCase().includes(q) ||
        p.code.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleAddProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !code.trim() || !clientId) return;

    addProject({
      title: title.trim(),
      code: code.trim().toUpperCase(),
      clientId,
      description: description.trim(),
      budget: Number(budget) || 1000000,
      hourlyRate: Number(hourlyRate) || 4500,
      startDate,
      targetDeadline,
      status: 'in_progress',
      healthScore: 'healthy',
      assignedMemberIds: selectedMemberIds,
      billingType: 'hourly',
    });

    setIsAddOpen(false);
    setTitle('');
    setCode('');
    setDescription('');
  };

  const healthColors: Record<string, string> = {
    healthy: 'bg-emerald-950/80 text-emerald-400 border-emerald-800',
    at_risk: 'bg-amber-950/80 text-amber-400 border-amber-800',
    critical: 'bg-rose-950/80 text-rose-400 border-rose-800',
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-slate-900 border border-slate-800">
        <div>
          <h1 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <FolderKanban className="w-5 h-5 text-indigo-400" />
            <span>Projects & Operations Timelines</span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Monitor deliverables, consultant assignments, budget burn rates and timeline SLAs
          </p>
        </div>

        {currentUser.permissions.canManageProjects && (
          <button
            onClick={() => setIsAddOpen(true)}
            className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Project</span>
          </button>
        )}
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {filteredProjects.map((proj) => {
          const client = clients.find(c => c.id === proj.clientId);
          const projTasks = tasks.filter(t => t.projectId === proj.id);
          const completedTasks = projTasks.filter(t => t.status === 'completed').length;
          const progressPct = projTasks.length > 0 ? Math.round((completedTasks / projTasks.length) * 100) : 0;
          const spent = proj.totalLoggedHours * proj.hourlyRate;
          const burnPct = Math.min(100, Math.round((spent / proj.budget) * 100));

          return (
            <div key={proj.id} className="bg-slate-900 border border-slate-800 p-5 space-y-4 hover:border-slate-700 transition-colors">
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono px-2 py-0.5 bg-indigo-950/80 text-indigo-300 border border-indigo-800/80 font-bold">
                      {proj.code}
                    </span>
                    <h2 className="text-sm font-bold text-slate-100">{proj.title}</h2>
                  </div>
                  <div className="text-xs text-slate-400">
                    Client: <strong className="text-slate-300">{client?.company || client?.name}</strong>
                  </div>
                </div>

                <span className={`px-2 py-0.5 text-[10px] uppercase font-mono font-bold border ${healthColors[proj.healthScore]}`}>
                  {proj.healthScore.replace('_', ' ')}
                </span>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed line-clamp-2">
                {proj.description}
              </p>

              {/* Budget & Timeline Stats */}
              <div className="grid grid-cols-3 gap-2 text-xs font-mono bg-slate-950 p-2.5 border border-slate-800">
                <div>
                  <div className="text-[10px] text-slate-500 uppercase">Target Deadline</div>
                  <div className="text-slate-200 font-bold">{proj.targetDeadline}</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500 uppercase">Budget Cap</div>
                  <div className="text-slate-200 font-bold">{formatCurrency(proj.budget)}</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500 uppercase">Logged Hours</div>
                  <div className="text-slate-200 font-bold">{proj.totalLoggedHours}h</div>
                </div>
              </div>

              {/* Budget Burn & Task Progress Bars */}
              <div className="space-y-2 pt-1">
                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>Task Velocity ({completedTasks}/{projTasks.length} Done)</span>
                    <span className="font-mono">{progressPct}%</span>
                  </div>
                  <div className="w-full bg-slate-800 h-1.5">
                    <div className="bg-indigo-500 h-full" style={{ width: `${progressPct}%` }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>Budget Consumed ({formatCurrency(spent)} of {formatCurrency(proj.budget)})</span>
                    <span className="font-mono">{burnPct}%</span>
                  </div>
                  <div className="w-full bg-slate-800 h-1.5">
                    <div className={burnPct > 90 ? 'bg-rose-500 h-full' : 'bg-emerald-500 h-full'} style={{ width: `${burnPct}%` }} />
                  </div>
                </div>
              </div>

              {/* Assigned Members & Consultants */}
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-slate-500" />
                  <span className="text-slate-400 text-[11px]">Assigned Team & Consultants:</span>
                </div>
                <div className="flex -space-x-1.5">
                  {proj.assignedMemberIds.map((memId) => {
                    const m = allTeamMembers.find(u => u.id === memId);
                    if (!m) return null;
                    return (
                      <img
                        key={m.id}
                        src={m.avatarUrl}
                        alt={m.name}
                        title={`${m.name} (${m.isExternal ? 'Consultant' : m.role})`}
                        className="w-5 h-5 rounded-none border border-slate-800 object-cover"
                      />
                    );
                  })}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Project Modal */}
      {isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-xl shadow-2xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <FolderKanban className="w-4 h-4 text-indigo-400" />
                <span>Initialize Project Workspace</span>
              </h2>
              <button onClick={() => setIsAddOpen(false)} className="text-slate-400 hover:text-slate-200">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddProject} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-slate-300 font-semibold mb-1">Project Title *</label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Distributed Telemetry Pipeline"
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 focus:outline-none focus:border-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Project Code *</label>
                  <input
                    type="text"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    placeholder="e.g. TEL-01"
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-100 uppercase font-mono focus:outline-none focus:border-indigo-500"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Client *</label>
                <select
                  value={clientId}
                  onChange={(e) => setClientId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                >
                  {clients.map(c => (
                    <option key={c.id} value={c.id}>{c.company || c.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Scope & Technical Objectives</label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={2}
                  className="w-full bg-slate-950 border border-slate-700 p-2 text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Budget Allocation (INR ₹)</label>
                  <input
                    type="number"
                    value={budget}
                    onChange={(e) => setBudget(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Hourly Billing Rate (INR ₹)</label>
                  <input
                    type="number"
                    value={hourlyRate}
                    onChange={(e) => setHourlyRate(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Start Date</label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Target Deadline</label>
                  <input
                    type="date"
                    value={targetDeadline}
                    onChange={(e) => setTargetDeadline(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 px-3 py-2 text-slate-200 font-mono"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold transition-colors shadow-sm"
                >
                  Initialize Project
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
