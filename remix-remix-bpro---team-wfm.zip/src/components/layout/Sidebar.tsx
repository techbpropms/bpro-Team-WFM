import React from 'react';
import { useApp } from '../../context/AppContext';
import { 
  LayoutDashboard, 
  Users, 
  FolderKanban, 
  CheckSquare, 
  Receipt, 
  CreditCard, 
  Calendar, 
  UserCheck, 
  FileBarChart2, 
  Sliders,
  ShieldCheck,
  ChevronRight,
  Trophy,
  Pin,
  Upload,
  Bot,
  Database,
  CloudCheck,
  Bell
} from 'lucide-react';
import { Tooltip } from '../common/Tooltip';

interface SidebarProps {
  onOpenIntegrations: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ onOpenIntegrations }) => {
  const { 
    activeTab, 
    setActiveTab, 
    currentUser, 
    tasks, 
    invoices, 
    expenses,
    gamificationProfiles,
    stickyNotes,
    notifications,
    setIsUploadModalOpen,
    isFirestoreConnected,
    syncWithFirestore
  } = useApp();

  const pendingTasksCount = tasks.filter(t => t.status !== 'completed').length;
  const overdueInvoicesCount = invoices.filter(i => i.status === 'sent' || i.status === 'overdue').length;
  const pendingExpensesCount = expenses.filter(e => e.status === 'pending').length;
  const unreadAlertsCount = notifications.filter(n => !n.isRead).length;
  const userProfile = gamificationProfiles.find(p => p.userId === currentUser.id);

  const NAV_ITEMS = [
    { id: 'dashboard', label: 'Executive Dashboard', icon: LayoutDashboard, iconColor: 'text-indigo-400' },
    { 
      id: 'notifications', 
      label: 'Notification Center', 
      icon: Bell, 
      iconColor: 'text-indigo-400',
      badge: unreadAlertsCount > 0 ? unreadAlertsCount : undefined,
      badgeColor: 'bg-indigo-600'
    },
    { 
      id: 'gemini', 
      label: 'Gemini AI Copilot & Maps', 
      icon: Bot, 
      iconColor: 'text-indigo-400',
      badge: 'AI',
      badgeColor: 'bg-indigo-600/30 text-indigo-300 border border-indigo-500/50'
    },
    { id: 'clients', label: 'Clients & CRM', icon: Users, iconColor: 'text-sky-400' },
    { id: 'projects', label: 'Projects & Timelines', icon: FolderKanban, iconColor: 'text-violet-400' },
    { 
      id: 'tasks', 
      label: 'Work & Tasks', 
      icon: CheckSquare,
      iconColor: 'text-emerald-400',
      badge: pendingTasksCount > 0 ? pendingTasksCount : undefined,
      badgeColor: 'bg-emerald-600'
    },
    { 
      id: 'invoices', 
      label: 'Billing & Invoices', 
      icon: Receipt,
      iconColor: 'text-amber-400',
      badge: overdueInvoicesCount > 0 ? overdueInvoicesCount : undefined,
      badgeColor: 'bg-indigo-600'
    },
    { 
      id: 'expenses', 
      label: 'Expenses & Budget', 
      icon: CreditCard,
      iconColor: 'text-rose-400',
      badge: pendingExpensesCount > 0 ? pendingExpensesCount : undefined,
      badgeColor: 'bg-amber-600'
    },
    { id: 'calendar', label: 'Calendar & Meet', icon: Calendar, iconColor: 'text-blue-400' },
    { 
      id: 'gamification', 
      label: 'Merit & Gamification', 
      icon: Trophy,
      iconColor: 'text-amber-400',
      badge: `LVL ${userProfile?.level || 1}`,
      badgeColor: 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
    },
    { 
      id: 'sticky', 
      label: 'Sticky Notes & Canvas', 
      icon: Pin,
      iconColor: 'text-pink-400',
      badge: stickyNotes.length > 0 ? stickyNotes.length : undefined,
      badgeColor: 'bg-pink-500/20 text-pink-300 border border-pink-500/40'
    },
    { id: 'team', label: 'Team & Consultants', icon: UserCheck, iconColor: 'text-teal-400' },
    { id: 'reports', label: 'Reports & Analytics', icon: FileBarChart2, iconColor: 'text-orange-400' },
    { id: 'audit', label: 'Audit Log & Security', icon: ShieldCheck, iconColor: 'text-cyan-400' },
    { id: 'settings', label: 'Super Admin & Settings', icon: Sliders, iconColor: 'text-yellow-400' },
  ];

  return (
    <aside className="w-64 bg-slate-950 border-r border-slate-800/80 flex flex-col shrink-0 min-h-[calc(100vh-50px)]">
      {/* Navigation Links */}
      <nav className="p-3 space-y-1 flex-1 overflow-y-auto">
        <div className="px-3 py-1.5 text-[10px] font-mono uppercase tracking-wider text-slate-400 font-semibold flex items-center justify-between border-b border-slate-900/80 pb-2 mb-2">
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse" />
            <span className="text-slate-200 font-bold">BPRO TEAM WFM</span>
          </div>
          <span className="text-[9px] text-slate-500 font-mono">v3.4 LIVE</span>
        </div>

        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <Tooltip key={item.id} content={item.label} position="right" delay={300} className="w-full">
              <button
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-indigo-600/20 text-indigo-200 border-l-2 border-indigo-500 font-semibold shadow-sm'
                    : 'text-slate-400 hover:text-slate-100 hover:bg-slate-900/70'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? item.iconColor : 'text-slate-500 group-hover:text-slate-400'}`} />
                  <span className="truncate">{item.label}</span>
                </div>
                {item.badge !== undefined && (
                  <span className={`text-[10px] font-mono px-1.5 py-0.5 text-white font-bold shrink-0 ${item.badgeColor || 'bg-slate-800 text-slate-300'}`}>
                    {item.badge}
                  </span>
                )}
              </button>
            </Tooltip>
          );
        })}
      </nav>

      {/* Enterprise Security Badge & Integrations Footer */}
      <div className="p-3 border-t border-slate-900 bg-slate-950/80 space-y-2">
        <button
          onClick={() => setIsUploadModalOpen(true)}
          className="w-full flex items-center justify-between px-3 py-2 bg-emerald-950/20 hover:bg-emerald-950/40 text-emerald-300 border border-emerald-500/30 text-xs font-medium transition-colors"
        >
          <div className="flex items-center gap-2">
            <Upload className="w-3.5 h-3.5 text-emerald-400" />
            <span className="font-mono text-[11px]">Format Upload & Vault</span>
          </div>
          <span className="text-[10px] font-mono bg-emerald-900/60 text-emerald-300 px-1 py-0.2">CSV/JSON</span>
        </button>

        <button
          onClick={syncWithFirestore}
          className="w-full flex items-center justify-between px-3 py-1.5 bg-amber-950/20 hover:bg-amber-950/40 text-amber-300 border border-amber-500/30 text-xs font-medium transition-colors"
        >
          <div className="flex items-center gap-2">
            <Database className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-mono text-[11px]">Firestore Cloud DB</span>
          </div>
          <span className="text-[10px] font-mono bg-amber-900/60 text-amber-300 px-1 py-0.2">
            {isFirestoreConnected ? 'ONLINE' : 'SYNC'}
          </span>
        </button>

        <button
          onClick={onOpenIntegrations}
          className="w-full flex items-center justify-between px-3 py-2 bg-slate-900/90 hover:bg-slate-850 text-slate-300 border border-slate-800 text-xs font-medium transition-colors"
        >
          <div className="flex items-center gap-2">
            <Sliders className="w-3.5 h-3.5 text-indigo-400" />
            <span>Integrations (Slack/Google/API)</span>
          </div>
          <ChevronRight className="w-3 h-3 text-slate-500" />
        </button>

        <div className="p-2.5 bg-slate-900/40 border border-slate-800 text-[10px] text-slate-400 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <div>
            <div className="text-slate-200 font-medium font-mono text-[11px]">AES-256 ENCRYPTED</div>
            <div className="text-[10px] text-slate-500">Zero-Trust Enterprise Compliance</div>
          </div>
        </div>
      </div>
    </aside>
  );
};
